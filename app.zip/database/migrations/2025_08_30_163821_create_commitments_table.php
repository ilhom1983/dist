<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('commitments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->foreignId('order_id')->nullable()->constrained()->onDelete('cascade');
            $table->decimal('amount', 10, 2); // total debt amount
            $table->decimal('paid_amount', 10, 2)->default(0); // how much has been paid
            $table->decimal('remaining_amount', 10, 2); // how much is still owed
            $table->date('due_date'); // when payment is due
            $table->string('status')->default('active'); // active, overdue, paid, written_off
            $table->text('notes')->nullable(); // reason for debt, payment terms
            $table->foreignId('created_by')->constrained('tenant_users')->onDelete('cascade');
            $table->timestamps();
            
            $table->index(['tenant_id', 'customer_id', 'status']);
            $table->index(['due_date', 'status']);
            $table->index('created_by');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('commitments');
    }
};
