<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('inventory_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->foreignId('product_id')->constrained();
            $table->string('transaction_type'); // sale, purchase, transfer, adjustment, damage, loss
            $table->integer('quantity');
            $table->string('reference_type')->nullable(); // order, manual, etc.
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('created_by')->constrained('tenant_users')->onDelete('cascade');
            $table->timestamps();
            
            $table->index(['tenant_id', 'product_id', 'transaction_type'], 'inv_trans_tenant_prod_type_idx');
            $table->index(['reference_type', 'reference_id'], 'inv_trans_ref_idx');
            $table->index('created_by', 'inv_trans_created_by_idx');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('inventory_transactions');
    }
};
