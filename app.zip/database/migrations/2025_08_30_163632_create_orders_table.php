<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('order_number')->unique();
            $table->foreignId('customer_id')->constrained();
            $table->foreignId('sales_user_id')->nullable()->constrained('tenant_users')->onDelete('set null');
            $table->foreignId('warehouse_user_id')->nullable()->constrained('tenant_users')->onDelete('set null');
            $table->foreignId('delivery_user_id')->nullable()->constrained('tenant_users')->onDelete('set null');
            $table->foreignId('order_status_id')->constrained('order_statuses');
            $table->foreignId('payment_status_id')->constrained('payment_statuses');
            $table->decimal('total_amount', 10, 2);
            $table->decimal('paid_amount', 10, 2)->default(0);
            $table->decimal('remaining_amount', 10, 2)->default(0);
            $table->decimal('tax_amount', 10, 2)->default(0);
            $table->decimal('discount_amount', 10, 2)->default(0);
            $table->decimal('shipping_amount', 10, 2)->default(0);
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('order_date');
            $table->timestamp('delivery_date')->nullable();
            $table->timestamps();
            
            $table->unique(['tenant_id', 'order_number']);
            $table->index(['tenant_id', 'order_status_id', 'payment_status_id']);
            $table->index(['order_date', 'delivery_date']);
            $table->index(['latitude', 'longitude']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
