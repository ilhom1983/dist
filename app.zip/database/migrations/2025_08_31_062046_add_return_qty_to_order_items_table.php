<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->integer('return_qty')->default(0)->after('quantity');
            $table->foreignId('return_reason_id')->nullable()->after('return_qty');
            $table->text('return_notes')->nullable()->after('return_reason_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->dropColumn(['return_qty', 'return_reason_id', 'return_notes']);
        });
    }
};
