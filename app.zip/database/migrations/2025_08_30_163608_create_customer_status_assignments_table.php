<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customer_status_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->string('status'); // active, inactive, blocked, etc.
            $table->text('notes')->nullable();
            $table->foreignId('changed_by')->constrained('tenant_users')->onDelete('cascade');
            $table->timestamps();
            
            $table->index(['customer_id', 'status']);
            $table->index('changed_by');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customer_status_assignments');
    }
};
