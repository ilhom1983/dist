<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Tenant;
use App\Models\TenantUser;
use App\Models\Superuser;
use App\Models\ApiIntegration;
use Illuminate\Support\Facades\Hash;

class TestDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Ixasales tenant
        $ixasalesTenant = Tenant::updateOrCreate(
            ['domain' => 'ixasales'],
            [
                'name' => 'Ixasales',
                'settings' => [
                    'company_name' => 'Ixasales Distribution',
                    'address' => '123 Business Street',
                    'phone' => '+1234567890',
                    'email' => 'info@ixasales.com',
                ],
                'is_active' => true,
            ]
        );

        // Create Telegram API integration for Ixasales
        ApiIntegration::updateOrCreate(
            [
                'tenant_id' => $ixasalesTenant->id,
                'provider' => 'telegram',
            ],
            [
                'api_key' => '8445692030:AAFpASCkoZ-eFytSC0wvu7khYCQUX3r2cnc',
                'is_active' => true,
                'settings' => [
                    'bot_username' => 'ixasales_bot',
                    'webhook_url' => null,
                ],
            ]
        );

        // Create Yandex Maps API integration
        ApiIntegration::updateOrCreate(
            [
                'tenant_id' => $ixasalesTenant->id,
                'provider' => 'yandex',
            ],
            [
                'api_key' => '2cd5ef26-0ba6-4088-86a8-f3aa9cf6c5c6', // JavaScript API и HTTP Геокодер
                'is_active' => true,
                'settings' => [
                    'static_api_key' => '51b1d00e-cf24-4867-835e-0b9fb790aba7',
                    'locator_api_key' => 'dab2c001-31c6-4060-8aed-20c9de102228',
                ],
            ]
        );

        // Create test users for Ixasales
        $users = [
            [
                'name' => 'Admin User',
                'email' => 'admin@ixasales.com',
                'password' => 'password123',
                'role' => 'admin',
            ],
            [
                'name' => 'Sales User',
                'email' => 'sales@ixasales.com',
                'password' => 'password123',
                'role' => 'sales',
            ],
            [
                'name' => 'Warehouse User',
                'email' => 'warehouse@ixasales.com',
                'password' => 'password123',
                'role' => 'warehouse',
            ],
            [
                'name' => 'Delivery User',
                'email' => 'delivery@ixasales.com',
                'password' => 'password123',
                'role' => 'delivery',
            ],
            [
                'name' => 'Manager User',
                'email' => 'manager@ixasales.com',
                'password' => 'password123',
                'role' => 'manager',
            ],
        ];

        foreach ($users as $userData) {
            TenantUser::updateOrCreate(
                [
                    'tenant_id' => $ixasalesTenant->id,
                    'email' => $userData['email'],
                ],
                [
                    'name' => $userData['name'],
                    'password' => Hash::make($userData['password']),
                    'role' => $userData['role'],
                    'is_active' => true,
                ]
            );
        }

        // Create superuser
        Superuser::updateOrCreate(
            ['email' => 'superadmin@distribution.com'],
            [
                'name' => 'Super Admin',
                'password' => Hash::make('password123'),
                'is_active' => true,
                'permissions' => ['*'],
            ]
        );

        $this->command->info('Test data seeded successfully!');
        $this->command->info('Ixasales tenant created with Telegram bot token.');
        $this->command->info('Test users created with password: password123');
    }
}
