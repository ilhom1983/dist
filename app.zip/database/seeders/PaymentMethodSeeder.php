<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\PaymentMethod;

class PaymentMethodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $methods = [
            [
                'name' => 'cash',
                'description' => 'Cash payment',
            ],
            [
                'name' => 'card',
                'description' => 'Credit/Debit card payment',
            ],
            [
                'name' => 'bank_transfer',
                'description' => 'Bank transfer payment',
            ],
            [
                'name' => 'mobile_money',
                'description' => 'Mobile money payment',
            ],
        ];

        foreach ($methods as $method) {
            PaymentMethod::updateOrCreate(
                ['name' => $method['name']],
                $method
            );
        }
    }
}
