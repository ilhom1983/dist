<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UserRoleSeeder::class,
            OrderStatusSeeder::class,
            PaymentStatusSeeder::class,
            PaymentMethodSeeder::class,
            ReturnReasonSeeder::class,
            TestDataSeeder::class,
            BusinessDataSeeder::class,
        ]);
    }
}
