<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\UserRole;

class UserRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [
            [
                'name' => 'superadmin',
                'description' => 'Super Administrator with full system access',
                'permissions' => ['*'], // All permissions
            ],
            [
                'name' => 'admin',
                'description' => 'Administrator with tenant management access',
                'permissions' => [
                    'manage_users', 'manage_products', 'manage_customers', 
                    'manage_orders', 'view_reports', 'manage_settings'
                ],
            ],
            [
                'name' => 'operator',
                'description' => 'Operator with order processing access',
                'permissions' => [
                    'view_orders', 'update_order_status', 'manage_payments',
                    'view_customers', 'view_products'
                ],
            ],
            [
                'name' => 'manager',
                'description' => 'Manager with team oversight access',
                'permissions' => [
                    'view_orders', 'approve_orders', 'view_reports',
                    'manage_team', 'view_customers'
                ],
            ],
            [
                'name' => 'sales',
                'description' => 'Sales representative with order creation access',
                'permissions' => [
                    'create_orders', 'view_customers', 'view_products',
                    'update_customer_info'
                ],
            ],
            [
                'name' => 'warehouse',
                'description' => 'Warehouse staff with inventory management access',
                'permissions' => [
                    'view_orders', 'update_inventory', 'load_orders',
                    'view_products'
                ],
            ],
            [
                'name' => 'delivery',
                'description' => 'Delivery staff with delivery management access',
                'permissions' => [
                    'view_orders', 'update_delivery_status', 'view_customers',
                    'view_routes'
                ],
            ],
        ];

        foreach ($roles as $role) {
            UserRole::updateOrCreate(
                ['name' => $role['name']],
                $role
            );
        }
    }
}
