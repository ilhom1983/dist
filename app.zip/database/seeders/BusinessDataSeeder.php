<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Tenant;
use App\Models\CustomerStatusAssignment;
use App\Models\CustomerGroup;
use App\Models\Customer;
use App\Models\ProductBrand;
use App\Models\ProductCategory;
use App\Models\Product;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\PaymentStatus;
use App\Models\TenantUser;
use Illuminate\Support\Facades\Hash;

class BusinessDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get the Ixasales tenant
        $tenant = Tenant::where('domain', 'ixasales')->first();
        
        if (!$tenant) {
            $this->command->error('Ixasales tenant not found. Please run TestDataSeeder first.');
            return;
        }

        $this->command->info('Seeding business data for Ixasales tenant...');

        // 1. Create Customer Statuses
        $this->createCustomerStatuses($tenant);

        // 2. Create Customer Groups
        $this->createCustomerGroups($tenant);

        // 3. Create Brands
        $this->createBrands($tenant);

        // 4. Create Categories
        $this->createCategories($tenant);

        // 5. Create Products
        $this->createProducts($tenant);

        // 6. Create Customers
        $this->createCustomers($tenant);

        // 7. Create Orders
        $this->createOrders($tenant);

        $this->command->info('Business data seeded successfully!');
    }

    private function createCustomerStatuses($tenant)
    {
        // Customer statuses are handled through assignments, not a separate model
        // We'll create status assignments when creating customers
        $this->command->info('Customer statuses will be assigned during customer creation.');
    }

    private function createCustomerGroups($tenant)
    {
        $groups = [
            ['name' => 'Розничные магазины', 'description' => 'Небольшие розничные магазины'],
            ['name' => 'Супермаркеты', 'description' => 'Крупные супермаркеты'],
            ['name' => 'Рестораны', 'description' => 'Рестораны и кафе'],
            ['name' => 'Оптовые клиенты', 'description' => 'Оптовые покупатели'],
            ['name' => 'Интернет-магазины', 'description' => 'Онлайн торговля'],
        ];

        foreach ($groups as $group) {
            CustomerGroup::updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'name' => $group['name'],
                ],
                [
                    'description' => $group['description'],
                    'is_active' => true,
                ]
            );
        }

        $this->command->info('Customer groups created.');
    }

    private function createBrands($tenant)
    {
        $brands = [
            ['name' => 'Nestlé', 'description' => 'Международная компания по производству продуктов питания'],
            ['name' => 'Coca-Cola', 'description' => 'Производитель безалкогольных напитков'],
            ['name' => 'PepsiCo', 'description' => 'Компания по производству напитков и закусок'],
            ['name' => 'Unilever', 'description' => 'Многонациональная компания по производству товаров для дома'],
            ['name' => 'Mars', 'description' => 'Производитель кондитерских изделий'],
            ['name' => 'Kraft Heinz', 'description' => 'Производитель продуктов питания'],
            ['name' => 'Danone', 'description' => 'Производитель молочных продуктов'],
            ['name' => 'Ferrero', 'description' => 'Производитель шоколада и кондитерских изделий'],
        ];

        foreach ($brands as $brand) {
            ProductBrand::updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'name' => $brand['name'],
                ],
                [
                    'description' => $brand['description'],
                    'is_active' => true,
                ]
            );
        }

        $this->command->info('Brands created.');
    }

    private function createCategories($tenant)
    {
        $categories = [
            ['name' => 'Напитки', 'description' => 'Безалкогольные напитки и соки'],
            ['name' => 'Молочные продукты', 'description' => 'Молоко, йогурт, сыр'],
            ['name' => 'Кондитерские изделия', 'description' => 'Шоколад, конфеты, печенье'],
            ['name' => 'Зерновые продукты', 'description' => 'Хлеб, крупы, макароны'],
            ['name' => 'Замороженные продукты', 'description' => 'Замороженные овощи и готовые блюда'],
            ['name' => 'Консервы', 'description' => 'Консервированные овощи и фрукты'],
            ['name' => 'Снэки', 'description' => 'Чипсы, орехи, сухофрукты'],
            ['name' => 'Соусы и приправы', 'description' => 'Кетчуп, майонез, специи'],
        ];

        foreach ($categories as $category) {
            ProductCategory::updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'name' => $category['name'],
                ],
                [
                    'description' => $category['description'],
                    'is_active' => true,
                ]
            );
        }

        $this->command->info('Categories created.');
    }

    private function createProducts($tenant)
    {
        $brands = ProductBrand::where('tenant_id', $tenant->id)->get();
        $categories = ProductCategory::where('tenant_id', $tenant->id)->get();

        $products = [
            // Напитки
            ['name' => 'Coca-Cola 0.5л', 'category' => 'Напитки', 'brand' => 'Coca-Cola', 'price' => 120, 'stock' => 500],
            ['name' => 'Pepsi 1л', 'category' => 'Напитки', 'brand' => 'PepsiCo', 'price' => 180, 'stock' => 300],
            ['name' => 'Fanta 0.5л', 'category' => 'Напитки', 'brand' => 'Coca-Cola', 'price' => 110, 'stock' => 400],
            ['name' => 'Sprite 0.5л', 'category' => 'Напитки', 'brand' => 'Coca-Cola', 'price' => 110, 'stock' => 350],
            
            // Молочные продукты
            ['name' => 'Молоко 3.2% 1л', 'category' => 'Молочные продукты', 'brand' => 'Danone', 'price' => 85, 'stock' => 200],
            ['name' => 'Йогурт натуральный 400г', 'category' => 'Молочные продукты', 'brand' => 'Danone', 'price' => 95, 'stock' => 150],
            ['name' => 'Сыр Российский 45% 200г', 'category' => 'Молочные продукты', 'brand' => 'Danone', 'price' => 180, 'stock' => 100],
            
            // Кондитерские изделия
            ['name' => 'Шоколад Snickers 50г', 'category' => 'Кондитерские изделия', 'brand' => 'Mars', 'price' => 65, 'stock' => 800],
            ['name' => 'Шоколад Twix 50г', 'category' => 'Кондитерские изделия', 'brand' => 'Mars', 'price' => 60, 'stock' => 750],
            ['name' => 'Шоколад KitKat 41г', 'category' => 'Кондитерские изделия', 'brand' => 'Nestlé', 'price' => 70, 'stock' => 600],
            ['name' => 'Шоколад Kinder Bueno 43г', 'category' => 'Кондитерские изделия', 'brand' => 'Ferrero', 'price' => 85, 'stock' => 400],
            
            // Зерновые продукты
            ['name' => 'Хлеб белый 500г', 'category' => 'Зерновые продукты', 'brand' => 'Kraft Heinz', 'price' => 45, 'stock' => 300],
            ['name' => 'Макароны 500г', 'category' => 'Зерновые продукты', 'brand' => 'Kraft Heinz', 'price' => 75, 'stock' => 250],
            
            // Снэки
            ['name' => 'Чипсы Lays 100г', 'category' => 'Снэки', 'brand' => 'PepsiCo', 'price' => 120, 'stock' => 400],
            ['name' => 'Орехи микс 200г', 'category' => 'Снэки', 'brand' => 'Unilever', 'price' => 250, 'stock' => 150],
            
            // Соусы
            ['name' => 'Кетчуп Heinz 460г', 'category' => 'Соусы и приправы', 'brand' => 'Kraft Heinz', 'price' => 180, 'stock' => 200],
            ['name' => 'Майонез 400г', 'category' => 'Соусы и приправы', 'brand' => 'Unilever', 'price' => 95, 'stock' => 180],
        ];

        foreach ($products as $productData) {
            $category = $categories->where('name', $productData['category'])->first();
            $brand = $brands->where('name', $productData['brand'])->first();

            if ($category && $brand) {
                Product::updateOrCreate(
                    [
                        'tenant_id' => $tenant->id,
                        'name' => $productData['name'],
                    ],
                    [
                        'category_id' => $category->id,
                        'brand_id' => $brand->id,
                        'sku' => 'SKU-' . strtoupper(substr(md5($productData['name']), 0, 8)),
                        'description' => $productData['name'] . ' - качественный продукт',
                        'price' => $productData['price'],
                        'stock_quantity' => $productData['stock'],
                        'is_active' => true,
                    ]
                );
            }
        }

        $this->command->info('Products created.');
    }

    private function createCustomers($tenant)
    {
        $customerGroups = CustomerGroup::where('tenant_id', $tenant->id)->get();

        $customers = [
            // Розничные магазины
            ['name' => 'Магазин "У дома"', 'phone' => '+7 (701) 123-45-67', 'email' => 'udoma@example.com', 'address' => 'ул. Абая, 15, Алматы', 'city' => 'Алматы', 'group' => 'Розничные магазины'],
            ['name' => 'Магазин "Продукты 24"', 'phone' => '+7 (702) 234-56-78', 'email' => 'prod24@example.com', 'address' => 'ул. Достык, 45, Алматы', 'city' => 'Алматы', 'group' => 'Розничные магазины'],
            ['name' => 'Магазин "Свежий"', 'phone' => '+7 (703) 345-67-89', 'email' => 'svezhiy@example.com', 'address' => 'ул. Толе би, 78, Алматы', 'city' => 'Алматы', 'group' => 'Розничные магазины'],
            
            // Супермаркеты
            ['name' => 'Супермаркет "Мега"', 'phone' => '+7 (704) 456-78-90', 'email' => 'mega@example.com', 'address' => 'пр. Республики, 123, Алматы', 'city' => 'Алматы', 'group' => 'Супермаркеты'],
            ['name' => 'ТЦ "Астана"', 'phone' => '+7 (705) 567-89-01', 'email' => 'astana@example.com', 'address' => 'ул. Сатпаева, 90, Алматы', 'city' => 'Алматы', 'group' => 'Супермаркеты'],
            
            // Рестораны
            ['name' => 'Ресторан "Восток"', 'phone' => '+7 (706) 678-90-12', 'email' => 'vostok@example.com', 'address' => 'ул. Фурманова, 56, Алматы', 'city' => 'Алматы', 'group' => 'Рестораны'],
            ['name' => 'Кафе "Уют"', 'phone' => '+7 (707) 789-01-23', 'email' => 'uyut@example.com', 'address' => 'ул. Гоголя, 34, Алматы', 'city' => 'Алматы', 'group' => 'Рестораны'],
            
            // Оптовые клиенты
            ['name' => 'ООО "ОптТорг"', 'phone' => '+7 (708) 890-12-34', 'email' => 'opttorg@example.com', 'address' => 'ул. Розыбакиева, 200, Алматы', 'city' => 'Алматы', 'group' => 'Оптовые клиенты'],
            ['name' => 'ИП "Быстрый"', 'phone' => '+7 (709) 901-23-45', 'email' => 'bystriy@example.com', 'address' => 'ул. Макатаева, 67, Алматы', 'city' => 'Алматы', 'group' => 'Оптовые клиенты'],
            
            // Интернет-магазины
            ['name' => 'Онлайн магазин "Еда"', 'phone' => '+7 (710) 012-34-56', 'email' => 'eda@example.com', 'address' => 'ул. Жандосова, 89, Алматы', 'city' => 'Алматы', 'group' => 'Интернет-магазины'],
        ];

        foreach ($customers as $customerData) {
            $group = $customerGroups->where('name', $customerData['group'])->first();

            $customer = Customer::updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'name' => $customerData['name'],
                ],
                [
                    'phone' => $customerData['phone'],
                    'email' => $customerData['email'],
                    'address' => $customerData['address'],
                    'city' => $customerData['city'],
                    'customer_group_id' => $group ? $group->id : null,
                    'latitude' => 43.238949 + (rand(-100, 100) / 10000), // Random coordinates around Almaty
                    'longitude' => 76.889709 + (rand(-100, 100) / 10000),
                    'is_active' => true,
                ]
            );

            // Add a sample image for some customers
            if (rand(1, 3) === 1) {
                $customer->update(['image' => 'customers/sample_storefront_' . $customer->id . '.jpg']);
            }
        }

        $this->command->info('Customers created.');
    }

    private function createOrders($tenant)
    {
        $customers = Customer::where('tenant_id', $tenant->id)->get();
        $products = Product::where('tenant_id', $tenant->id)->get();
        $salesUser = TenantUser::where('tenant_id', $tenant->id)->where('role', 'sales')->first();
        $pendingOrderStatus = OrderStatus::where('name', 'pending')->first();
        $pendingPaymentStatus = PaymentStatus::where('name', 'pending')->first();

        if (!$salesUser || !$pendingOrderStatus || !$pendingPaymentStatus) {
            $this->command->warn('Sales user or statuses not found. Skipping orders creation.');
            return;
        }

        $orderStatuses = OrderStatus::all();
        $paymentStatuses = PaymentStatus::all();

        // Create some sample orders
        for ($i = 1; $i <= 15; $i++) {
            $customer = $customers->random();
            $orderStatus = $orderStatuses->random();
            $paymentStatus = $paymentStatuses->random();
            
            // Random date within last 30 days
            $orderDate = now()->subDays(rand(0, 30));
            
            $order = Order::create([
                'tenant_id' => $tenant->id,
                'order_number' => 'ORD-' . date('Ymd') . '-' . str_pad($i, 4, '0', STR_PAD_LEFT) . '-' . time(),
                'customer_id' => $customer->id,
                'sales_user_id' => $salesUser->id,
                'order_status_id' => $orderStatus->id,
                'payment_status_id' => $paymentStatus->id,
                'total_amount' => 0, // Will be calculated
                'remaining_amount' => 0, // Will be calculated
                'notes' => rand(1, 3) === 1 ? 'Срочный заказ' : null,
                'latitude' => $customer->latitude + (rand(-50, 50) / 10000),
                'longitude' => $customer->longitude + (rand(-50, 50) / 10000),
                'order_date' => $orderDate,
            ]);

            // Add 1-5 products to each order
            $orderProducts = $products->random(rand(1, 5));
            $totalAmount = 0;

            foreach ($orderProducts as $product) {
                $quantity = rand(1, 10);
                $unitPrice = $product->price;
                $totalPrice = $unitPrice * $quantity;
                $totalAmount += $totalPrice;

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'unit_price' => $unitPrice,
                    'total_price' => $totalPrice,
                ]);
            }

            // Update order totals
            $order->update([
                'total_amount' => $totalAmount,
                'remaining_amount' => $paymentStatus->name === 'paid' ? 0 : $totalAmount,
            ]);
        }

        $this->command->info('Orders created.');
    }
} 