<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\OrderStatus;

class OrderStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $statuses = [
            [
                'name' => 'pending',
                'description' => 'Order is created and waiting for approval',
                'color' => '#fbbf24', // yellow
            ],
            [
                'name' => 'approved',
                'description' => 'Order has been approved and is ready for processing',
                'color' => '#10b981', // green
            ],
            [
                'name' => 'cancelled',
                'description' => 'Order has been cancelled',
                'color' => '#ef4444', // red
            ],
            [
                'name' => 'loaded',
                'description' => 'Order items have been loaded and ready for delivery',
                'color' => '#3b82f6', // blue
            ],
            [
                'name' => 'delivered',
                'description' => 'Order has been delivered to customer',
                'color' => '#8b5cf6', // purple
            ],
            [
                'name' => 'paid',
                'description' => 'Order has been fully paid',
                'color' => '#059669', // emerald
            ],
            [
                'name' => 'returned',
                'description' => 'Order has been returned by customer',
                'color' => '#dc2626', // red
            ],
            [
                'name' => 'closed',
                'description' => 'Order is completed and closed',
                'color' => '#6b7280', // gray
            ],
        ];

        foreach ($statuses as $status) {
            OrderStatus::updateOrCreate(
                ['name' => $status['name']],
                $status
            );
        }
    }
}
