<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\ReturnReason;

class ReturnReasonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $reasons = [
            [
                'name' => 'defective',
                'description' => 'Product is defective or damaged',
            ],
            [
                'name' => 'wrong_item',
                'description' => 'Wrong item delivered',
            ],
            [
                'name' => 'customer_change_mind',
                'description' => 'Customer changed their mind',
            ],
            [
                'name' => 'not_as_described',
                'description' => 'Product not as described',
            ],
            [
                'name' => 'quality_issue',
                'description' => 'Quality issue with the product',
            ],
            [
                'name' => 'shipping_damage',
                'description' => 'Product damaged during shipping',
            ],
            [
                'name' => 'expired',
                'description' => 'Product is expired',
            ],
            [
                'name' => 'customer_refused',
                'description' => 'Customer refused to accept the product',
            ],
            [
                'name' => 'other',
                'description' => 'Other reason',
            ],
        ];

        foreach ($reasons as $reason) {
            ReturnReason::updateOrCreate(
                ['name' => $reason['name']],
                $reason
            );
        }
    }
} 