<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\PaymentStatus;

class PaymentStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $statuses = [
            [
                'name' => 'pending',
                'description' => 'Payment is pending',
                'color' => '#fbbf24', // yellow
            ],
            [
                'name' => 'paid',
                'description' => 'Payment has been completed successfully',
                'color' => '#10b981', // green
            ],
            [
                'name' => 'failed',
                'description' => 'Payment has failed',
                'color' => '#ef4444', // red
            ],
            [
                'name' => 'refunded',
                'description' => 'Payment has been refunded',
                'color' => '#8b5cf6', // purple
            ],
        ];

        foreach ($statuses as $status) {
            PaymentStatus::updateOrCreate(
                ['name' => $status['name']],
                $status
            );
        }
    }
}
