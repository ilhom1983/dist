

<?php $__env->startSection('title', 'Заказы склада'); ?>
<?php $__env->startSection('header-title', 'Заказы склада'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 pb-20">
    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="mx-3 mt-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="mx-3 mt-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Bulk Actions Bar -->
    <div id="bulk-actions-bar" class="bg-blue-50 border-b border-blue-200 hidden">
        <div class="px-3 py-2 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="text-sm text-blue-700" id="selected-count">0 выбрано</span>
            </div>
            <div class="flex space-x-2">
                <button onclick="clearSelection()" class="text-xs text-blue-600 hover:text-blue-800">
                    Отменить
                </button>
                <button onclick="showAssignModal()" class="bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-blue-700">
                    Назначить доставку
                </button>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <div class="bg-white shadow-sm sticky top-0 z-10">
        <div class="flex">
            <button id="tab-orders-to-load" class="flex-1 py-2 px-3 text-center text-xs font-medium text-blue-600 border-b-2 border-blue-600">
                К загрузке (<?php echo e($ordersToLoad->total()); ?>)
            </button>
            <button id="tab-loaded-orders" class="flex-1 py-2 px-3 text-center text-xs font-medium text-gray-500 border-b-2 border-transparent">
                Загруженные (<?php echo e($loadedOrders->total()); ?>)
            </button>
        </div>
    </div>

    <!-- Orders to Load -->
    <div id="orders-to-load-content" class="tab-content">
        <?php if($ordersToLoad->count() > 0): ?>
            <div class="space-y-2 p-3">
                <?php $__currentLoopData = $ordersToLoad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow" 
                     onclick="window.location.href='<?php echo e(route('mobile.warehouse.orders.show', $order)); ?>'">
                    <!-- Order Header -->
                    <div class="p-3 border-b border-gray-50">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-2">
                                <input type="checkbox" class="order-checkbox" value="<?php echo e($order->id); ?>" onchange="updateSelection()" onclick="event.stopPropagation()">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center space-x-2">
                                        <span class="text-sm font-semibold text-gray-900"><?php echo e($order->order_number); ?></span>
                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                            К загрузке
                                        </span>
                                    </div>
                                    <p class="text-xs text-gray-500 truncate"><?php echo e($order->customer->name); ?></p>
                                </div>
                            </div>
                            <div class="text-right ml-2">
                                <p class="text-sm font-semibold text-gray-900"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</p>
                                <p class="text-xs text-gray-500"><?php echo e($order->orderItems->count() ?? 0); ?> товаров</p>
                            </div>
                        </div>
                    </div>

                    <!-- Order Details -->
                    <div class="p-3">
                        <div class="flex items-center justify-between text-xs text-gray-600">
                            <span class="truncate"><?php echo e($order->customer->address); ?></span>
                            <span><?php echo e($order->order_date->format('d.m.Y H:i')); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Compact Pagination -->
            <?php if($ordersToLoad->hasPages()): ?>
            <div class="mt-4 flex justify-center pb-4">
                <div class="flex space-x-1">
                    <?php if($ordersToLoad->onFirstPage()): ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">←</span>
                    <?php else: ?>
                        <a href="<?php echo e($ordersToLoad->previousPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">←</a>
                    <?php endif; ?>
                    
                    <span class="px-2 py-1 text-xs text-gray-600 bg-white border border-gray-300 rounded">
                        <?php echo e($ordersToLoad->currentPage()); ?> из <?php echo e($ordersToLoad->lastPage()); ?>

                    </span>
                    
                    <?php if($ordersToLoad->hasMorePages()): ?>
                        <a href="<?php echo e($ordersToLoad->nextPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">→</a>
                    <?php else: ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">→</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-8">
                <svg class="mx-auto h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">Нет заказов к загрузке</h3>
                <p class="mt-1 text-xs text-gray-500">Все заказы обработаны.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Loaded Orders -->
    <div id="loaded-orders-content" class="tab-content hidden">
        <?php if($loadedOrders->count() > 0): ?>
            <div class="space-y-2 p-3">
                <?php $__currentLoopData = $loadedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow" 
                     onclick="window.location.href='<?php echo e(route('mobile.warehouse.orders.show', $order)); ?>'">
                    <!-- Order Header -->
                    <div class="p-3 border-b border-gray-50">
                        <div class="flex items-center justify-between">
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm font-semibold text-gray-900"><?php echo e($order->order_number); ?></span>
                                    <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        Загружен
                                    </span>
                                    <?php if($order->delivery_user_id): ?>
                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                            Назначен
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <p class="text-xs text-gray-500 truncate"><?php echo e($order->customer->name); ?></p>
                                <?php if($order->delivery_user_id): ?>
                                    <p class="text-xs text-blue-600">Доставка: <?php echo e($order->deliveryUser->name ?? 'Неизвестно'); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="text-right ml-2">
                                <p class="text-sm font-semibold text-gray-900"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</p>
                                <p class="text-xs text-gray-500"><?php echo e($order->orderItems->count() ?? 0); ?> товаров</p>
                            </div>
                        </div>
                    </div>

                    <!-- Order Details -->
                    <div class="p-3">
                        <div class="flex items-center justify-between text-xs text-gray-600">
                            <span class="truncate"><?php echo e($order->customer->address); ?></span>
                            <span><?php echo e($order->updated_at->format('d.m.Y H:i')); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Compact Pagination -->
            <?php if($loadedOrders->hasPages()): ?>
            <div class="mt-4 flex justify-center pb-4">
                <div class="flex space-x-1">
                    <?php if($loadedOrders->onFirstPage()): ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">←</span>
                    <?php else: ?>
                        <a href="<?php echo e($loadedOrders->previousPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">←</a>
                    <?php endif; ?>
                    
                    <span class="px-2 py-1 text-xs text-gray-600 bg-white border border-gray-300 rounded">
                        <?php echo e($loadedOrders->currentPage()); ?> из <?php echo e($loadedOrders->lastPage()); ?>

                    </span>
                    
                    <?php if($loadedOrders->hasMorePages()): ?>
                        <a href="<?php echo e($loadedOrders->nextPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">→</a>
                    <?php else: ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">→</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-8">
                <svg class="mx-auto h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">Нет загруженных заказов</h3>
                <p class="mt-1 text-xs text-gray-500">Начните с загрузки первого заказа.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Assignment Modal -->
<div id="assign-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Назначить доставку</h3>
            
            <form id="assign-form" method="POST" action="<?php echo e(route('mobile.warehouse.orders.bulk-assign')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="selected-orders" name="order_ids">
                
                <div class="mb-4">
                    <label for="delivery_user_id" class="block text-sm font-medium text-gray-700 mb-2">
                        Выберите доставщика
                    </label>
                    <select id="delivery_user_id" name="delivery_user_id" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Выберите доставщика...</option>
                        <?php $__currentLoopData = $deliveryUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="closeAssignModal()" class="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Отмена
                    </button>
                    <button type="submit" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Назначить
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bottom Navigation -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
    <div class="flex justify-around">
        <a href="<?php echo e(route('mobile.warehouse.dashboard')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
            </svg>
            <span class="text-xs mt-1">Главная</span>
        </a>
        <a href="<?php echo e(route('mobile.warehouse.orders.index')); ?>" class="flex flex-col items-center py-2 px-3 text-blue-600">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
            </svg>
            <span class="text-xs mt-1">Заказы</span>
        </a>
        <a href="<?php echo e(route('mobile.warehouse.inventory.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
            </svg>
            <span class="text-xs mt-1">Остатки</span>
        </a>
        <a href="<?php echo e(route('mobile.warehouse.products.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
            <span class="text-xs mt-1">Товары</span>
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabOrdersToLoad = document.getElementById('tab-orders-to-load');
    const tabLoadedOrders = document.getElementById('tab-loaded-orders');
    const contentOrdersToLoad = document.getElementById('orders-to-load-content');
    const contentLoadedOrders = document.getElementById('loaded-orders-content');

    function showTab(tabElement, contentElement, otherTabElement, otherContentElement) {
        tabElement.classList.add('text-blue-600', 'border-blue-600');
        tabElement.classList.remove('text-gray-500', 'border-transparent');
        contentElement.classList.remove('hidden');
        
        otherTabElement.classList.remove('text-blue-600', 'border-blue-600');
        otherTabElement.classList.add('text-gray-500', 'border-transparent');
        otherContentElement.classList.add('hidden');
    }

    tabOrdersToLoad.addEventListener('click', function() {
        showTab(tabOrdersToLoad, contentOrdersToLoad, tabLoadedOrders, contentLoadedOrders);
    });

    tabLoadedOrders.addEventListener('click', function() {
        showTab(tabLoadedOrders, contentLoadedOrders, tabOrdersToLoad, contentOrdersToLoad);
    });
});

// Bulk selection functions
function updateSelection() {
    const checkboxes = document.querySelectorAll('.order-checkbox:checked');
    const selectedCount = checkboxes.length;
    const bulkActionsBar = document.getElementById('bulk-actions-bar');
    const selectedCountElement = document.getElementById('selected-count');
    
    if (selectedCount > 0) {
        bulkActionsBar.classList.remove('hidden');
        selectedCountElement.textContent = `${selectedCount} выбрано`;
    } else {
        bulkActionsBar.classList.add('hidden');
    }
}

function clearSelection() {
    const checkboxes = document.querySelectorAll('.order-checkbox');
    checkboxes.forEach(checkbox => checkbox.checked = false);
    updateSelection();
}

function showAssignModal() {
    const checkboxes = document.querySelectorAll('.order-checkbox:checked');
    const orderIds = Array.from(checkboxes).map(cb => cb.value);
    
    if (orderIds.length === 0) {
        alert('Выберите заказы для назначения');
        return;
    }
    
    document.getElementById('selected-orders').value = orderIds.join(',');
    document.getElementById('assign-modal').classList.remove('hidden');
}

function closeAssignModal() {
    document.getElementById('assign-modal').classList.add('hidden');
    document.getElementById('assign-form').reset();
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/warehouse/orders/index.blade.php ENDPATH**/ ?>