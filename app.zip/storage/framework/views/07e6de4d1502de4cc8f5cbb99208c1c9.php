

<?php $__env->startSection('title', 'Возврат товаров'); ?>
<?php $__env->startSection('header-title', 'Возврат товаров'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 pb-20">
    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="mx-3 mt-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="mx-3 mt-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="mx-3 mt-3 p-3 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg text-sm">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <!-- Order Information -->
    <div class="p-3">
        <div class="bg-white rounded-lg shadow-sm border p-3 mb-3">
            <h2 class="text-lg font-semibold text-gray-900 mb-3">Информация о заказе</h2>
            
            <div class="grid grid-cols-2 gap-3 text-sm">
                <div>
                    <p class="text-sm font-medium text-gray-500">Номер заказа</p>
                    <p class="text-gray-900 font-medium"><?php echo e($order->order_number); ?></p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Клиент</p>
                    <p class="text-gray-900 font-medium"><?php echo e($order->customer->name); ?></p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Общая сумма</p>
                    <p class="text-gray-900 font-bold"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Дата заказа</p>
                    <p class="text-gray-900"><?php echo e($order->order_date->format('d.m.Y H:i')); ?></p>
                </div>
            </div>
        </div>

        <!-- Return Form -->
        <form action="<?php echo e(route('mobile.delivery.orders.process-return', $order)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="bg-white rounded-lg shadow-sm border p-3 mb-3">
                <h2 class="text-lg font-semibold text-gray-900 mb-3">Выберите товары для возврата</h2>
                
                <?php if($order->orderItems->count() > 0): ?>
                    <div class="space-y-3">
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-200 rounded-lg p-3">
                            <!-- Product Header -->
                            <div class="mb-3">
                                <h3 class="font-medium text-gray-900 text-sm"><?php echo e($item->product->name); ?></h3>
                                <p class="text-xs text-gray-500"><?php echo e($item->product->sku ?? 'Без SKU'); ?></p>
                            </div>
                            
                            <!-- Product Details Grid -->
                            <div class="bg-gray-50 rounded-lg p-2 mb-3">
                                <div class="grid grid-cols-2 gap-2 text-xs">
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Цена:</span>
                                        <span class="font-medium"><?php echo e(number_format($item->unit_price, 0, ',', ' ')); ?> ₽</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Заказано:</span>
                                        <span class="font-medium"><?php echo e($item->quantity); ?> шт.</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Уже возвращено:</span>
                                        <span class="font-medium"><?php echo e($item->return_qty ?? 0); ?> шт.</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Доступно:</span>
                                        <span class="font-medium"><?php echo e($item->quantity - ($item->return_qty ?? 0)); ?> шт.</span>
                                    </div>
                                    <div class="flex justify-between col-span-2 border-t border-gray-200 pt-1 mt-1">
                                        <span class="text-gray-600 font-medium">Итого по товару:</span>
                                        <span class="font-bold"><?php echo e(number_format($item->unit_price * $item->quantity, 0, ',', ' ')); ?> ₽</span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Return Inputs -->
                            <div class="grid grid-cols-2 gap-2">
                                <div>
                                    <label for="return_qty_<?php echo e($item->id); ?>" class="block text-xs font-medium text-gray-700 mb-1">
                                        Количество для возврата
                                    </label>
                                    <input type="number" 
                                           name="return_qty[<?php echo e($item->id); ?>]" 
                                           id="return_qty_<?php echo e($item->id); ?>"
                                           min="0" 
                                           max="<?php echo e($item->quantity - ($item->return_qty ?? 0)); ?>"
                                           value="0"
                                           class="w-full p-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           onchange="updateReturnAmount(<?php echo e($item->id); ?>, <?php echo e($item->unit_price); ?>)">
                                    <p class="text-xs text-gray-500 mt-1">Макс: <?php echo e($item->quantity - ($item->return_qty ?? 0)); ?> шт.</p>
                                </div>
                                
                                <div>
                                    <label for="return_amount_<?php echo e($item->id); ?>" class="block text-xs font-medium text-gray-700 mb-1">
                                        Сумма возврата
                                    </label>
                                    <input type="text" 
                                           id="return_amount_<?php echo e($item->id); ?>"
                                           value="0 ₽"
                                           readonly
                                           class="w-full p-2 border border-gray-300 rounded text-sm bg-gray-50">
                                </div>
                            </div>
                            
                            <div class="mt-2">
                                <label for="return_reason_<?php echo e($item->id); ?>" class="block text-xs font-medium text-gray-700 mb-1">
                                    Причина возврата
                                </label>
                                <select name="return_reason[<?php echo e($item->id); ?>]" 
                                        id="return_reason_<?php echo e($item->id); ?>"
                                        class="w-full p-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="">Выберите причину</option>
                                    <?php $__currentLoopData = $returnReasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reason->id); ?>"><?php echo e($reason->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="mt-2">
                                <label for="return_notes_<?php echo e($item->id); ?>" class="block text-xs font-medium text-gray-700 mb-1">
                                    Примечания
                                </label>
                                <textarea name="return_notes[<?php echo e($item->id); ?>]" 
                                          id="return_notes_<?php echo e($item->id); ?>"
                                          rows="2"
                                          class="w-full p-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Дополнительная информация"></textarea>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4">Нет товаров в заказе</p>
                <?php endif; ?>
            </div>

            <!-- Return Summary -->
            <div class="bg-white rounded-lg shadow-sm border p-3 mb-3">
                <h2 class="text-lg font-semibold text-gray-900 mb-3">Сводка возврата</h2>
                
                <div class="bg-gray-50 rounded-lg p-2 mb-3">
                    <div class="grid grid-cols-2 gap-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Общая сумма заказа:</span>
                            <span class="font-medium"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Товаров в заказе:</span>
                            <span class="font-medium"><?php echo e($order->orderItems->count()); ?> шт.</span>
                        </div>
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Сумма возврата</p>
                        <p class="text-lg font-semibold text-red-600" id="total_return_amount">0 ₽</p>
                    </div>
                    
                    <div>
                        <p class="text-sm font-medium text-gray-500">Товаров для возврата</p>
                        <p class="text-lg font-semibold text-gray-900" id="total_return_items">0</p>
                    </div>
                </div>
                
                <div class="mt-3 pt-3 border-t border-gray-200">
                    <div class="flex justify-between">
                        <span class="text-sm font-medium text-gray-600">Остаток после возврата:</span>
                        <span class="text-sm font-bold text-gray-900" id="remaining_amount"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</span>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="bg-white rounded-lg shadow-sm border p-3">
                <button type="submit" 
                        id="submitBtn"
                        class="w-full bg-red-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-red-700 focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed">
                    <span id="submitText">Обработать возврат</span>
                    <span id="submitLoading" class="hidden">
                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Обработка...
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Track return amounts for each item
let returnAmounts = {};

function updateReturnAmount(itemId, unitPrice) {
    const quantity = parseInt(document.getElementById('return_qty_' + itemId).value) || 0;
    const amount = quantity * unitPrice;
    returnAmounts[itemId] = amount;
    
    document.getElementById('return_amount_' + itemId).value = amount.toLocaleString('ru-RU') + ' ₽';
    
    updateTotalReturn();
}

function updateTotalReturn() {
    let totalAmount = 0;
    let totalItems = 0;
    
    for (let itemId in returnAmounts) {
        totalAmount += returnAmounts[itemId];
        const quantity = parseInt(document.getElementById('return_qty_' + itemId).value) || 0;
        totalItems += quantity;
    }
    
    document.getElementById('total_return_amount').textContent = totalAmount.toLocaleString('ru-RU') + ' ₽';
    document.getElementById('total_return_items').textContent = totalItems;
    
    // Calculate remaining amount after returns
    const orderTotal = <?php echo e($order->total_amount); ?>;
    const remainingAmount = orderTotal - totalAmount;
    document.getElementById('remaining_amount').textContent = remainingAmount.toLocaleString('ru-RU') + ' ₽';
    
    // Enable/disable submit button
    const submitBtn = document.getElementById('submitBtn');
    if (totalItems > 0) {
        submitBtn.disabled = false;
        submitBtn.classList.remove('opacity-50', 'cursor-not-allowed');
    } else {
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-50', 'cursor-not-allowed');
    }
}

// Form submission
document.querySelector('form').addEventListener('submit', function() {
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const submitLoading = document.getElementById('submitLoading');
    
    submitBtn.disabled = true;
    submitText.classList.add('hidden');
    submitLoading.classList.remove('hidden');
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateTotalReturn();
});
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/delivery/orders/return.blade.php ENDPATH**/ ?>