<?php $__env->startSection('title', 'Заказы доставки'); ?>
<?php $__env->startSection('header-title', 'Заказы доставки'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 pb-20">
    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="mx-3 mt-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="mx-3 mt-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="mx-3 mt-3 p-3 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg text-sm">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <!-- Compact Tabs -->
    <div class="bg-white shadow-sm sticky top-0 z-10">
        <div class="flex">
            <button onclick="showTab('to-deliver')" id="tab-to-deliver" class="flex-1 py-2 px-3 text-xs font-medium text-center border-b-2 border-blue-600 text-blue-600">
                К доставке (<?php echo e($ordersToDeliver->count() ?? 0); ?>)
            </button>
            <button onclick="showTab('delivered')" id="tab-delivered" class="flex-1 py-2 px-3 text-xs font-medium text-center border-b-2 border-transparent text-gray-500">
                Доставленные (<?php echo e($deliveredOrders->count() ?? 0); ?>)
            </button>
        </div>
        
        <!-- Bulk Actions Bar -->
        <div id="bulkActionsBar" class="hidden bg-blue-50 border-t border-blue-200 p-2">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <input type="checkbox" 
                           id="selectAll" 
                           onchange="toggleSelectAll()"
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="selectAll" class="text-xs font-medium text-blue-900">Выбрать все</label>
                    <span class="text-xs font-medium text-blue-900" id="selectedCount">(0 выбрано)</span>
                </div>
                <div class="flex space-x-2">
                    <button onclick="openYandexNavigator()" 
                            class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-white bg-green-600 hover:bg-green-700">
                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m0 0L9 7"></path>
                        </svg>
                        Yandex Navigator
                    </button>
                    <button onclick="clearSelection()" 
                            class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50">
                        Отменить
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Orders to Deliver Tab -->
    <div id="content-to-deliver" class="p-3">
        <?php if(($ordersToDeliver->count() ?? 0) > 0): ?>
            <div class="space-y-2">
                <?php $__currentLoopData = $ordersToDeliver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow" 
                     onclick="handleOrderClick(event, <?php echo e($order->id); ?>)"
                     data-latitude="<?php echo e($order->latitude ?? ''); ?>"
                     data-longitude="<?php echo e($order->longitude ?? ''); ?>">
                    <div class="p-3">
                        <div class="flex items-center space-x-3">
                            <!-- Checkbox -->
                            <input type="checkbox" 
                                   id="order_<?php echo e($order->id); ?>" 
                                   value="<?php echo e($order->id); ?>"
                                   onclick="event.stopPropagation()"
                                   onchange="updateSelection()"
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            
                            <!-- Order Info Columns -->
                            <div class="flex-1 grid grid-cols-3 gap-3 text-xs">
                                <!-- Column 1: Order Date & Number -->
                                <div class="space-y-1">
                                    <p class="font-medium text-gray-900"><?php echo e($order->created_at->format('d.m.Y')); ?></p>
                                    <p class="text-gray-600"><?php echo e($order->order_number); ?></p>
                                </div>
                                
                                <!-- Column 2: Customer Name & Phone -->
                                <div class="space-y-1">
                                    <p class="font-medium text-gray-900 truncate"><?php echo e($order->customer->name); ?></p>
                                    <p class="text-gray-600"><?php echo e($order->customer->phone ?? 'Нет телефона'); ?></p>
                                </div>
                                
                                <!-- Column 3: Order Total & Created By -->
                                <div class="space-y-1 text-right">
                                    <p class="font-medium text-gray-900"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</p>
                                    <p class="text-gray-600"><?php echo e($order->createdBy->name ?? 'Система'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <!-- Compact Pagination -->
            <?php if($ordersToDeliver->hasPages()): ?>
            <div class="mt-4 flex justify-center">
                <div class="flex space-x-1">
                    <?php if($ordersToDeliver->onFirstPage()): ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">←</span>
                    <?php else: ?>
                        <a href="<?php echo e($ordersToDeliver->previousPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">←</a>
                    <?php endif; ?>
                    
                    <span class="px-2 py-1 text-xs text-gray-600 bg-white border border-gray-300 rounded">
                        <?php echo e($ordersToDeliver->currentPage()); ?> из <?php echo e($ordersToDeliver->lastPage()); ?>

                    </span>
                    
                    <?php if($ordersToDeliver->hasMorePages()): ?>
                        <a href="<?php echo e($ordersToDeliver->nextPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">→</a>
                    <?php else: ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">→</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-8">
                <svg class="mx-auto h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">Нет заказов к доставке</h3>
                <p class="mt-1 text-xs text-gray-500">Все заказы уже доставлены или в обработке.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Delivered Orders Tab -->
    <div id="content-delivered" class="p-3 hidden">
        <?php if(($deliveredOrders->count() ?? 0) > 0): ?>
            <div class="space-y-2">
                <?php $__currentLoopData = $deliveredOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow" 
                     onclick="window.location.href='<?php echo e(route('mobile.delivery.orders.show', $order)); ?>'">
                    <!-- Order Header -->
                    <div class="p-3 border-b border-gray-50">
                        <div class="flex items-center justify-between">
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm font-semibold text-gray-900"><?php echo e($order->order_number); ?></span>
                                    <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium 
                                        <?php if($order->orderStatus && $order->orderStatus->name === 'delivered'): ?> bg-green-100 text-green-800
                                        <?php elseif($order->orderStatus && $order->orderStatus->name === 'paid'): ?> bg-blue-100 text-blue-800
                                        <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                        <?php if($order->orderStatus && $order->orderStatus->name === 'delivered'): ?> Доставлено
                                        <?php elseif($order->orderStatus && $order->orderStatus->name === 'paid'): ?> Оплачено
                                        <?php else: ?> <?php echo e($order->orderStatus ? ucfirst($order->orderStatus->name) : 'Статус'); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>
                                <p class="text-xs text-gray-500 truncate"><?php echo e($order->customer->name); ?></p>
                            </div>
                            <div class="text-right ml-2">
                                <p class="text-sm font-semibold text-gray-900"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</p>
                                <p class="text-xs text-gray-500"><?php echo e($order->delivery_date?->format('d.m.Y') ?? 'Без даты'); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Order Details -->
                    <div class="p-3">
                        <div class="flex items-center justify-between text-xs text-gray-600 mb-2">
                            <span class="truncate"><?php echo e($order->customer->address); ?></span>
                            <span><?php echo e($order->orderItems->count() ?? 0); ?> товаров</span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <!-- Compact Pagination -->
            <?php if($deliveredOrders->hasPages()): ?>
            <div class="mt-4 flex justify-center">
                <div class="flex space-x-1">
                    <?php if($deliveredOrders->onFirstPage()): ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">←</span>
                    <?php else: ?>
                        <a href="<?php echo e($deliveredOrders->previousPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">←</a>
                    <?php endif; ?>
                    
                    <span class="px-2 py-1 text-xs text-gray-600 bg-white border border-gray-300 rounded">
                        <?php echo e($deliveredOrders->currentPage()); ?> из <?php echo e($deliveredOrders->lastPage()); ?>

                    </span>
                    
                    <?php if($deliveredOrders->hasMorePages()): ?>
                        <a href="<?php echo e($deliveredOrders->nextPageUrl()); ?>" class="px-2 py-1 text-xs text-blue-600 bg-white border border-gray-300 rounded hover:bg-gray-50">→</a>
                    <?php else: ?>
                        <span class="px-2 py-1 text-xs text-gray-400 bg-gray-100 rounded">→</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-8">
                <svg class="mx-auto h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">Нет доставленных заказов</h3>
                <p class="mt-1 text-xs text-gray-500">Доставленные заказы будут отображаться здесь.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Bottom Navigation -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
    <div class="flex justify-around">
        <a href="<?php echo e(route('mobile.delivery.dashboard')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
            </svg>
            <span class="text-xs mt-1">Главная</span>
        </a>
        <a href="<?php echo e(route('mobile.delivery.orders.index')); ?>" class="flex flex-col items-center py-2 px-3 text-blue-600">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
            </svg>
            <span class="text-xs mt-1">Заказы</span>
        </a>
        <a href="<?php echo e(route('mobile.delivery.debtors.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span class="text-xs mt-1">Должники</span>
        </a>
        <a href="<?php echo e(route('mobile.delivery.payments.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
            </svg>
            <span class="text-xs mt-1">Платежи</span>
        </a>
    </div>
</div>

<!-- Include Modals -->
<?php echo $__env->make("mobile.delivery.modals.commitments", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make("mobile.delivery.modals.payments", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make("mobile.delivery.modals.return-items", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
// Tab switching
function showTab(tabName) {
    // Hide all content
    document.getElementById('content-to-deliver').classList.add('hidden');
    document.getElementById('content-delivered').classList.add('hidden');
    
    // Remove active styles from all tabs
    document.getElementById('tab-to-deliver').classList.remove('border-blue-600', 'text-blue-600');
    document.getElementById('tab-to-deliver').classList.add('border-transparent', 'text-gray-500');
    document.getElementById('tab-delivered').classList.remove('border-blue-600', 'text-blue-600');
    document.getElementById('tab-delivered').classList.add('border-transparent', 'text-gray-500');
    
    // Show selected content and activate tab
    if (tabName === 'to-deliver') {
        document.getElementById('content-to-deliver').classList.remove('hidden');
        document.getElementById('tab-to-deliver').classList.add('border-blue-600', 'text-blue-600');
        document.getElementById('tab-to-deliver').classList.remove('border-transparent', 'text-gray-500');
        // Show bulk actions bar for "To Deliver" tab
        document.getElementById('bulkActionsBar').classList.remove('hidden');
    } else if (tabName === 'delivered') {
        document.getElementById('content-delivered').classList.remove('hidden');
        document.getElementById('tab-delivered').classList.add('border-blue-600', 'text-blue-600');
        document.getElementById('tab-delivered').classList.remove('border-transparent', 'text-gray-500');
        // Hide bulk actions bar for "Delivered" tab
        document.getElementById('bulkActionsBar').classList.add('hidden');
    }
    
    // Clear checkboxes when switching tabs
    clearAllCheckboxes();
}

// Order selection functions
function handleOrderClick(event, orderId) {
    // If checkbox is clicked, don't navigate
    if (event.target.type === 'checkbox') {
        return;
    }
    
    // Navigate to order details
    window.location.href = `/mobile/delivery/orders/${orderId}`;
}

function updateSelection() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][id^="order_"]');
    const selectedCheckboxes = document.querySelectorAll('input[type="checkbox"][id^="order_"]:checked');
    const bulkActionsBar = document.getElementById('bulkActionsBar');
    const selectedCount = document.getElementById('selectedCount');
    const selectAllCheckbox = document.getElementById('selectAll');
    
    selectedCount.textContent = `(${selectedCheckboxes.length} выбрано)`;
    
    // Update select all checkbox state
    if (selectedCheckboxes.length === 0) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    } else if (selectedCheckboxes.length === checkboxes.length) {
        selectAllCheckbox.checked = true;
        selectAllCheckbox.indeterminate = false;
    } else {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = true;
    }
    
    // Only show bulk actions bar if we're on the "To Deliver" tab and there are orders
    const toDeliverTab = document.getElementById('content-to-deliver');
    if (checkboxes.length > 0 && !toDeliverTab.classList.contains('hidden')) {
        bulkActionsBar.classList.remove('hidden');
    }
}

function clearSelection() {
    clearAllCheckboxes();
    // Don't hide the bulk actions bar since it contains the select all checkbox
}

function clearAllCheckboxes() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][id^="order_"]');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    updateSelection();
}

function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('selectAll');
    const orderCheckboxes = document.querySelectorAll('input[type="checkbox"][id^="order_"]');
    
    orderCheckboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
    
    updateSelection();
}

// Initialize the page - show bulk actions bar for "To Deliver" tab on page load
document.addEventListener('DOMContentLoaded', function() {
    // Show bulk actions bar for "To Deliver" tab (default active tab)
    document.getElementById('bulkActionsBar').classList.remove('hidden');
});

function openYandexNavigator() {
    const selectedCheckboxes = document.querySelectorAll('input[type="checkbox"][id^="order_"]:checked');
    
    if (selectedCheckboxes.length === 0) {
        alert('Выберите хотя бы один заказ для построения маршрута');
        return;
    }
    
    // Get coordinates of selected orders
    const coordinates = [];
    selectedCheckboxes.forEach(checkbox => {
        const orderId = checkbox.value;
        const orderCard = checkbox.closest('.bg-white');
        const latitude = orderCard.dataset.latitude;
        const longitude = orderCard.dataset.longitude;
        
        if (latitude && longitude && !isNaN(latitude) && !isNaN(longitude)) {
            coordinates.push(`${latitude},${longitude}`);
        }
    });
    
    if (coordinates.length === 0) {
        alert('У выбранных заказов нет координат для построения маршрута');
        return;
    }
    
    // Build Yandex Navigator URL
    const waypoints = coordinates.join('~');
    const url = `https://yandex.ru/maps/?rtext=~${waypoints}&rtt=auto`;
    
    // Open in new tab/window
    window.open(url, '_blank');
}

// Status update function
function updateOrderStatus(orderId, status) {
    // Show appropriate modal based on status
    if (status === "delivered") {
        showCommitmentsModal(orderId);
    } else if (status === "paid") {
        showPaymentsModal(orderId);
    } else if (status === "returned") {
        showReturnItemsModal(orderId);
    }
}

function showCommitmentsModal(orderId) {
    document.getElementById("commitmentsModal").classList.remove("hidden");
    document.getElementById("commitmentsOrderId").value = orderId;
}

function showPaymentsModal(orderId) {
    document.getElementById("paymentsModal").classList.remove("hidden");
    document.getElementById("paymentsOrderId").value = orderId;
}

function showReturnItemsModal(orderId) {
    document.getElementById("returnItemsModal").classList.remove("hidden");
    document.getElementById("returnItemsOrderId").value = orderId;
    loadOrderItems(orderId);
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.add("hidden");
}

function loadOrderItems(orderId) {
    const itemsList = document.getElementById("returnItemsList");
    itemsList.innerHTML = "<p class='text-gray-500'>Загрузка товаров...</p>";
    
    // Fetch order items via AJAX
    fetch(`/mobile/delivery/orders/${orderId}/return`, {
        method: 'GET',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Accept': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.items) {
            let html = '<div class="space-y-3">';
            data.items.forEach(item => {
                html += `
                    <div class="border border-gray-200 rounded-lg p-3">
                        <div class="flex justify-between items-start mb-2">
                            <div class="flex-1">
                                <p class="font-medium text-gray-900">${item.product_name}</p>
                                <p class="text-sm text-gray-600">SKU: ${item.product_sku || 'Нет артикула'}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-900">${item.unit_price} ₽/шт.</p>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-medium text-gray-700 mb-1">Количество для возврата</label>
                                <input type="number" name="return_items[${item.id}][return_quantity]" 
                                       min="0" max="${item.quantity}" value="0" 
                                       class="w-full p-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-700 mb-1">Причина возврата</label>
                                <select name="return_items[${item.id}][return_reason_id]" required 
                                        class="w-full p-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="">Выберите причину</option>
                                    ${data.return_reasons.map(reason => `<option value="${reason.id}">${reason.name}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            itemsList.innerHTML = html;
        } else {
            itemsList.innerHTML = "<p class='text-red-500'>Ошибка загрузки товаров</p>";
        }
    })
    .catch(error => {
        console.error('Error:', error);
        itemsList.innerHTML = "<p class='text-red-500'>Ошибка загрузки товаров</p>";
    });
}

// Route function
function openRoute(latitude, longitude) {
    if (latitude && longitude && !isNaN(latitude) && !isNaN(longitude)) {
        const yandexNavUrl = `yandexnavi://build_route_on_map?lat_to=${latitude}&lon_to=${longitude}`;
        const yandexMapsUrl = `https://yandex.ru/maps/?rtext=~${latitude},${longitude}&rtt=auto`;
        
        // Try to open Yandex Navigator app, fallback to Yandex Maps
        window.location.href = yandexNavUrl;
        
        // Fallback to Yandex Maps in case app is not installed
        setTimeout(() => {
            window.open(yandexMapsUrl, '_blank');
        }, 2000);
    } else {
        alert('Некорректные координаты для построения маршрута');
    }
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/delivery/orders/index.blade.php ENDPATH**/ ?>