

<?php $__env->startSection('title', 'Должники'); ?>
<?php $__env->startSection('header-title', 'Должники'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Должники</h1>
                    <p class="text-sm text-gray-600">Клиенты с задолженностями</p>
                </div>
                <a href="<?php echo e(route('mobile.delivery.dashboard')); ?>" class="text-blue-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="mx-4 mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="mx-4 mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="p-4 grid grid-cols-2 gap-4">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-red-100 rounded-lg">
                    <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Всего должников</p>
                    <p class="text-2xl font-semibold text-gray-900"><?php echo e($stats['total_debtors']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-yellow-100 rounded-lg">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Общая задолженность</p>
                    <p class="text-xl font-semibold text-gray-900"><?php echo e(number_format($stats['total_debt'], 0, ',', ' ')); ?> ₽</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-orange-100 rounded-lg">
                    <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Просрочено</p>
                    <p class="text-2xl font-semibold text-gray-900"><?php echo e($stats['overdue_commitments']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Сегодня к оплате</p>
                    <p class="text-2xl font-semibold text-gray-900"><?php echo e($stats['today_due']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Debtors List -->
    <div class="p-4">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Список должников</h2>
        
        <?php if($debtors->count() > 0): ?>
            <div class="space-y-4">
                <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debtor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="p-4">
                        <div class="flex items-center justify-between mb-3">
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900"><?php echo e($debtor->name); ?></h3>
                                <p class="text-sm text-gray-500"><?php echo e($debtor->phone); ?></p>
                                <p class="text-xs text-gray-400"><?php echo e($debtor->address); ?></p>
                            </div>
                            <div class="text-right">
                                <?php 
                                    $totalDebt = $debtor->commitments->sum('remaining_amount');
                                    $isOverdue = $debtor->commitments->where('due_date', '<', now()->toDateString())->count() > 0;
                                ?>
                                <p class="text-lg font-semibold text-red-600"><?php echo e(number_format($totalDebt, 0, ',', ' ')); ?> ₽</p>
                                <?php if($isOverdue): ?>
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                        Просрочено
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                        Активно
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Commitments Summary -->
                        <div class="mb-3">
                            <p class="text-xs text-gray-500 mb-2">Обязательства:</p>
                            <?php $__currentLoopData = $debtor->commitments->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between text-sm mb-1">
                                <span class="text-gray-600">
                                    <?php echo e($commitment->due_date->format('d.m.Y')); ?> - <?php echo e(number_format($commitment->remaining_amount, 0, ',', ' ')); ?> ₽
                                </span>
                                <?php if($commitment->due_date < now()->toDateString()): ?>
                                    <span class="text-red-600 text-xs">Просрочено</span>
                                <?php elseif($commitment->due_date == now()->toDateString()): ?>
                                    <span class="text-blue-600 text-xs">Сегодня</span>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($debtor->commitments->count() > 3): ?>
                                <p class="text-xs text-gray-400">+ еще <?php echo e($debtor->commitments->count() - 3); ?> обязательств</p>
                            <?php endif; ?>
                        </div>

                        <div class="flex justify-between space-x-2">
                            <a href="<?php echo e(route('mobile.delivery.debtors.show', $debtor)); ?>" 
                               class="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                </svg>
                                Детали
                            </a>
                            
                            <?php if($debtor->latitude && $debtor->longitude): ?>
                            <button onclick="openRoute(<?php echo e($debtor->latitude); ?>, <?php echo e($debtor->longitude); ?>)" 
                                    class="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m0 0L9 7"></path>
                                </svg>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <!-- Pagination -->
            <div class="mt-6">
                <?php echo e($debtors->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">Нет должников</h3>
                <p class="mt-1 text-sm text-gray-500">Все клиенты оплатили свои обязательства.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="<?php echo e(route('mobile.delivery.dashboard')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="<?php echo e(route('mobile.delivery.orders.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="<?php echo e(route('mobile.delivery.debtors.index')); ?>" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span class="text-xs mt-1">Должники</span>
            </a>
            <a href="<?php echo e(route('mobile.delivery.payments.index')); ?>" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <span class="text-xs mt-1">Платежи</span>
            </a>
        </div>
    </div>
</div>

<script>
function openRoute(latitude, longitude) {
    const yandexNavUrl = `yandexnavi://build_route_on_map?lat_to=${latitude}&lon_to=${longitude}`;
    const yandexMapsUrl = `https://yandex.ru/maps/?rtext=~${latitude},${longitude}&rtt=auto`;
    
    // Try to open Yandex Navigator app, fallback to Yandex Maps
    window.location.href = yandexNavUrl;
    
    // Fallback to Yandex Maps in case app is not installed
    setTimeout(() => {
        window.open(yandexMapsUrl, '_blank');
    }, 2000);
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/delivery/debtors/index.blade.php ENDPATH**/ ?>