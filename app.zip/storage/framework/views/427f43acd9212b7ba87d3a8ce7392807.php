

<?php $__env->startSection('title', 'Детали заказа'); ?>
<?php $__env->startSection('header-title', 'Детали заказа'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 pb-20">
    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="mx-3 mt-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="mx-3 mt-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Order Header -->
    <div class="bg-white border-b px-3 py-4">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-lg font-semibold text-gray-900">Заказ #<?php echo e($order->order_number); ?></h1>
                <p class="text-sm text-gray-600"><?php echo e($order->customer->name ?? 'Неизвестный клиент'); ?></p>
            </div>
            <div class="text-right">
                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                    <?php if($order->orderStatus->name === 'approved'): ?> bg-orange-100 text-orange-800
                    <?php elseif($order->orderStatus->name === 'loaded'): ?> bg-blue-100 text-blue-800
                    <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                    <?php echo e(ucfirst($order->orderStatus->name)); ?>

                </span>
            </div>
        </div>
    </div>

    <!-- Order Details -->
    <div class="p-3 space-y-3">
        <!-- Customer Info -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Информация о клиенте</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Имя:</span>
                    <span class="font-medium"><?php echo e($order->customer->name); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Телефон:</span>
                    <span class="font-medium"><?php echo e($order->customer->phone); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Адрес:</span>
                    <span class="font-medium text-right"><?php echo e($order->customer->address); ?></span>
                </div>
            </div>
        </div>

        <!-- Order Info -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Информация о заказе</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Дата заказа:</span>
                    <span class="font-medium"><?php echo e($order->order_date->format('d.m.Y H:i')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Статус:</span>
                    <span class="font-medium"><?php echo e(ucfirst($order->orderStatus->name)); ?></span>
                </div>
                <?php if($order->salesUser): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Продавец:</span>
                    <span class="font-medium"><?php echo e($order->salesUser->name); ?></span>
                </div>
                <?php endif; ?>
                <?php if($order->warehouseUser): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Склад:</span>
                    <span class="font-medium"><?php echo e($order->warehouseUser->name); ?></span>
                </div>
                <?php endif; ?>
                <?php if($order->deliveryUser): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Доставка:</span>
                    <span class="font-medium"><?php echo e($order->deliveryUser->name); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Order Items -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Товары (<?php echo e($order->orderItems->count()); ?>)</h3>
            <div class="space-y-2">
                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($item->product->name); ?></p>
                        <p class="text-xs text-gray-500">SKU: <?php echo e($item->product->sku); ?></p>
                    </div>
                    <div class="text-right ml-2">
                        <p class="text-sm font-medium text-gray-900"><?php echo e($item->quantity); ?> шт.</p>
                        <p class="text-xs text-gray-500"><?php echo e(number_format($item->unit_price, 0, ',', ' ')); ?> ₽</p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Order Totals -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Итого</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Сумма заказа:</span>
                    <span class="font-medium"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</span>
                </div>
                <?php if($order->discount_amount > 0): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Скидка:</span>
                    <span class="font-medium text-red-600">-<?php echo e(number_format($order->discount_amount, 0, ',', ' ')); ?> ₽</span>
                </div>
                <?php endif; ?>
                <?php if($order->shipping_amount > 0): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Доставка:</span>
                    <span class="font-medium"><?php echo e(number_format($order->shipping_amount, 0, ',', ' ')); ?> ₽</span>
                </div>
                <?php endif; ?>
                <div class="flex justify-between pt-2 border-t border-gray-200">
                    <span class="text-gray-900 font-medium">К оплате:</span>
                    <span class="text-gray-900 font-bold"><?php echo e(number_format($order->total_amount, 0, ',', ' ')); ?> ₽</span>
                </div>
            </div>
        </div>

        <!-- Notes -->
        <?php if($order->notes): ?>
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Примечания</h3>
            <p class="text-sm text-gray-700"><?php echo e($order->notes); ?></p>
        </div>
        <?php endif; ?>

        <!-- Action Buttons -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <?php if($order->orderStatus->name === 'approved'): ?>
            <div class="space-y-2">
                <a href="<?php echo e(route('mobile.warehouse.orders.load-form', $order)); ?>" 
                   class="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                    Загрузить заказ
                </a>
            </div>
            <?php elseif($order->orderStatus->name === 'loaded'): ?>
            <div class="space-y-2">
                <p class="text-sm text-gray-600 text-center">Заказ уже загружен</p>
                <?php if(!$order->delivery_user_id): ?>
                <p class="text-xs text-orange-600 text-center">Ожидает назначения доставщика</p>
                <?php else: ?>
                <p class="text-xs text-green-600 text-center">Назначен доставщику: <?php echo e($order->deliveryUser->name); ?></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/warehouse/orders/show.blade.php ENDPATH**/ ?>