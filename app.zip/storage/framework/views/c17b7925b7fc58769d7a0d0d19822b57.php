<!-- Payments Modal -->
<div id="paymentsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-2/3 lg:w-1/2 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-medium text-gray-900">Создание платежа</h3>
                <button onclick="closeModal('paymentsModal')" class="text-gray-400 hover:text-gray-600" title="Закрыть" aria-label="Закрыть модальное окно">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form action="<?php echo e(route("mobile.delivery.payments.store")); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="paymentsOrderId" name="order_id">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Сумма платежа</label>
                    <input type="number" name="amount" step="0.01" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Способ оплаты</label>
                    <select name="payment_method_id" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Выберите способ оплаты</option>
                        <option value="1">Наличные</option>
                        <option value="2">Карта</option>
                        <option value="3">Перевод</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Примечания</label>
                    <textarea name="notes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeModal('paymentsModal')" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">Отмена</button>
                    <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">Создать платеж</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects3\ixasales\new2\distribution-app\resources\views/mobile/delivery/modals/payments.blade.php ENDPATH**/ ?>