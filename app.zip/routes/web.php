<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\Superuser\TenantController as SuperuserTenantController;
use App\Http\Controllers\Superuser\TenantUserController as SuperuserTenantUserController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;

// Authentication routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Tenant user logout route
Route::middleware(['auth.tenant'])->group(function () {
    Route::post('/tenant/logout', [AuthController::class, 'logout'])->name('tenant.logout');
});

// Public routes
Route::get('/', function () {
    return redirect('/login');
});

// Superuser routes
Route::middleware(['auth:superuser'])->prefix('superuser')->name('superuser.')->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\Superuser\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/api-stats', [App\Http\Controllers\Superuser\DashboardController::class, 'apiStats'])->name('dashboard.api-stats');
    
    // System management
    Route::get('/system', [App\Http\Controllers\Superuser\SystemController::class, 'index'])->name('system.index');
    Route::post('/system/backup', [App\Http\Controllers\Superuser\SystemController::class, 'backup'])->name('system.backup');
    Route::get('/system/logs/{filename?}', [App\Http\Controllers\Superuser\SystemController::class, 'logs'])->name('system.logs');
    Route::post('/system/clear-cache', [App\Http\Controllers\Superuser\SystemController::class, 'clearCache'])->name('system.clear-cache');
    Route::post('/system/optimize', [App\Http\Controllers\Superuser\SystemController::class, 'optimize'])->name('system.optimize');
    
    // API management
    Route::get('/api', [App\Http\Controllers\Superuser\ApiController::class, 'index'])->name('api.index');
    Route::post('/api/regenerate-key/{id}', [App\Http\Controllers\Superuser\ApiController::class, 'regenerateKey'])->name('api.regenerate-key');
    Route::post('/api/toggle-status/{id}', [App\Http\Controllers\Superuser\ApiController::class, 'toggleStatus'])->name('api.toggle-status');
    Route::get('/api/usage-logs', [App\Http\Controllers\Superuser\ApiController::class, 'usageLogs'])->name('api.usage-logs');
    
    // Security monitoring
    Route::get('/security', [App\Http\Controllers\Superuser\SecurityController::class, 'index'])->name('security.index');
    Route::post('/security/block-ip/{ip}', [App\Http\Controllers\Superuser\SecurityController::class, 'blockIp'])->name('security.block-ip');
    Route::post('/security/unblock-ip/{ip}', [App\Http\Controllers\Superuser\SecurityController::class, 'unblockIp'])->name('security.unblock-ip');
    Route::get('/security/logs', [App\Http\Controllers\Superuser\SecurityController::class, 'securityLogs'])->name('security.logs');
    
    // Tenant management
    Route::resource('tenants', SuperuserTenantController::class);
    
    // User management
    Route::resource('users', SuperuserTenantUserController::class);
    Route::post('/users/{user}/toggle-status', [SuperuserTenantUserController::class, 'toggleStatus'])->name('users.toggle-status');
});



// Admin routes (for admin users within tenants)
Route::middleware(['auth.tenant', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
    
    // Order management
    Route::resource('orders', OrderController::class);
    Route::post('/orders/bulk-status', [OrderController::class, 'bulkUpdateStatus'])->name('orders.bulk-status');
    
    // Customer management
    Route::resource('customers', CustomerController::class);
    
    // Product management
    Route::resource('products', ProductController::class);
    
    // Brand management
    Route::resource('brands', \App\Http\Controllers\Admin\BrandController::class);
    
    // Category management
    Route::resource('categories', \App\Http\Controllers\Admin\CategoryController::class);
    
    // Delivery management
    Route::resource('deliveries', \App\Http\Controllers\Admin\DeliveryController::class);
    
    // Payment management
    Route::resource('payments', \App\Http\Controllers\Admin\PaymentController::class);
    
    // User management
    Route::resource('users', \App\Http\Controllers\Admin\UserController::class);
    Route::post('/users/{user}/toggle-status', [\App\Http\Controllers\Admin\UserController::class, 'toggleStatus'])->name('users.toggle-status');
    Route::post('/users/{user}/reset-password', [\App\Http\Controllers\Admin\UserController::class, 'resetPassword'])->name('users.reset-password');
    Route::get('/users/{user}/activity', [\App\Http\Controllers\Admin\UserController::class, 'activity'])->name('users.activity');

    // Salary management
    Route::resource('salaries', \App\Http\Controllers\Admin\SalaryController::class);
    Route::post('/salaries/calculate-all', [\App\Http\Controllers\Admin\SalaryController::class, 'calculateAll'])->name('salaries.calculate-all');
    Route::post('/salaries/create-all', [\App\Http\Controllers\Admin\SalaryController::class, 'createAll'])->name('salaries.create-all');

    // Reports
    Route::get('/reports', function() { return view('admin.reports.index'); })->name('reports.index');
    
    // Settings
    Route::get('/settings', function() { return view('admin.settings.index'); })->name('settings.index');
});

// Tenant user routes (for regular users)
Route::middleware(['auth.tenant'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/api/stats', [DashboardController::class, 'apiStats'])->name('api.stats');
    
    // Products
    Route::resource('products', ProductController::class);
    
    // Customers
    Route::resource('customers', CustomerController::class);
    
    // Orders (accessible by all authenticated users, but with admin privileges for admin users)
    Route::resource('orders', OrderController::class);
    Route::post('/orders/bulk-status', [OrderController::class, 'bulkUpdateStatus'])->name('orders.bulk-status');
});

// Mobile dashboard route for non-sales mobile users (manager, warehouse, delivery)
Route::middleware(['auth.tenant'])->get('/mobile/dashboard', function() {
    $user = auth()->guard('tenant')->user();
    if ($user->role === 'sales') {
        return redirect()->route('mobile.sales.dashboard');
    }
    if ($user->role === 'warehouse') {
        return redirect()->route('mobile.warehouse.dashboard');
    }
    if ($user->role === 'delivery') {
        return redirect()->route('mobile.delivery.dashboard');
    }
    return view('mobile.dashboard');
})->name('mobile.dashboard');

// Warehouse routes
Route::middleware(['auth.tenant'])->prefix('mobile/warehouse')->name('mobile.warehouse.')->group(function () {
    Route::get('/', [\App\Http\Controllers\Mobile\Warehouse\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('inventory', \App\Http\Controllers\Mobile\Warehouse\InventoryController::class);
    Route::resource('orders', \App\Http\Controllers\Mobile\Warehouse\OrderController::class);
    Route::resource('products', \App\Http\Controllers\Mobile\Warehouse\ProductController::class);
    Route::post('/orders/{order}/load', [\App\Http\Controllers\Mobile\Warehouse\OrderController::class, 'loadOrder'])->name('orders.load');
    Route::get('/orders/{order}/load', [\App\Http\Controllers\Mobile\Warehouse\OrderController::class, 'loadOrderForm'])->name('orders.load-form');
    Route::post('/orders/bulk-assign', [\App\Http\Controllers\Mobile\Warehouse\OrderController::class, 'bulkAssign'])->name('orders.bulk-assign');
    Route::post('/inventory/{product}/adjust', [\App\Http\Controllers\Mobile\Warehouse\InventoryController::class, 'adjustStock'])->name('inventory.adjust');
    Route::get('/inventory/{product}/adjust', [\App\Http\Controllers\Mobile\Warehouse\InventoryController::class, 'adjustStockForm'])->name('inventory.adjust-form');
    Route::get('/inventory/search', [\App\Http\Controllers\Mobile\Warehouse\InventoryController::class, 'search'])->name('inventory.search');
    Route::get('/products/search', [\App\Http\Controllers\Mobile\Warehouse\ProductController::class, 'search'])->name('products.search');
});

// Delivery routes
Route::middleware(['auth.tenant'])->prefix('mobile/delivery')->name('mobile.delivery.')->group(function () {
    Route::get('/', [\App\Http\Controllers\Mobile\Delivery\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('orders', \App\Http\Controllers\Mobile\Delivery\OrderController::class);
    Route::resource('debtors', \App\Http\Controllers\Mobile\Delivery\DebtorController::class);
    Route::resource('commitments', \App\Http\Controllers\Mobile\Delivery\CommitmentController::class);
    Route::post('/orders/{order}/start', [\App\Http\Controllers\Mobile\Delivery\OrderController::class, 'startDelivery'])->name('orders.start');
    Route::post('/orders/{order}/status', [\App\Http\Controllers\Mobile\Delivery\OrderController::class, 'updateStatus'])->name('orders.status');
    Route::get('/orders/{order}/return', [\App\Http\Controllers\Mobile\Delivery\OrderController::class, 'returnItems'])->name('orders.return');
    Route::post('/orders/{order}/return', [\App\Http\Controllers\Mobile\Delivery\OrderController::class, 'processReturn'])->name('orders.process-return');
    Route::get('/commitments/create/{order?}', [\App\Http\Controllers\Mobile\Delivery\CommitmentController::class, 'create'])->name('commitments.create');

    // Payment routes (separate from resource to avoid conflicts)
    Route::get('/payments', [\App\Http\Controllers\Mobile\Delivery\PaymentController::class, 'index'])->name('payments.index');
    Route::get('/payments/create/{order?}', [\App\Http\Controllers\Mobile\Delivery\PaymentController::class, 'create'])->name('payments.create');
    Route::post('/payments', [\App\Http\Controllers\Mobile\Delivery\PaymentController::class, 'store'])->name('payments.store');
    Route::get('/payments/{payment}', [\App\Http\Controllers\Mobile\Delivery\PaymentController::class, 'show'])->name('payments.show');

    // Modal form submission routes
    Route::post("/commitments", [\App\Http\Controllers\Mobile\Delivery\OrderController::class, "createCommitment"])->name("commitments.store");
    Route::post("/orders/return", [\App\Http\Controllers\Mobile\Delivery\OrderController::class, "processReturnItems"])->name("orders.return-items");
});

// Test route for debugging
Route::get('/test-sales', function() {
    return 'Sales route is working!';
});

// Test sales dashboard without auth
Route::get('/test-sales-dashboard', function() {
    return 'Sales dashboard route is working! User: ' . (auth()->guard('tenant')->user() ? auth()->guard('tenant')->user()->name : 'Not logged in');
});

// Test Alpine.js route
Route::get('/test-alpine', function() {
    return view('mobile.sales.test-alpine');
})->name('test-alpine');

// Mobile Sales routes
Route::middleware(['auth.tenant'])->prefix('mobile/sales')->name('mobile.sales.')->group(function () {
    Route::get('/', [\App\Http\Controllers\Mobile\Sales\DashboardController::class, 'index'])->name('dashboard');
    
    // Read-only routes for sales users
    Route::get('customers', [\App\Http\Controllers\Mobile\Sales\CustomerController::class, 'index'])->name('customers.index');
    Route::get('customers/create', [\App\Http\Controllers\Mobile\Sales\CustomerController::class, 'create'])->name('customers.create');
    Route::post('customers', [\App\Http\Controllers\Mobile\Sales\CustomerController::class, 'store'])->name('customers.store');
    Route::get('customers/{customer}', [\App\Http\Controllers\Mobile\Sales\CustomerController::class, 'show'])->name('customers.show');
    
    Route::get('orders', [\App\Http\Controllers\Mobile\Sales\OrderController::class, 'index'])->name('orders.index');
    Route::get('orders/create', [\App\Http\Controllers\Mobile\Sales\OrderController::class, 'create'])->name('orders.create');
    Route::post('orders', [\App\Http\Controllers\Mobile\Sales\OrderController::class, 'store'])->name('orders.store');
    Route::get('orders/{order}', [\App\Http\Controllers\Mobile\Sales\OrderController::class, 'show'])->name('orders.show');
    
    Route::get('debtors', [\App\Http\Controllers\Mobile\Sales\DebtorController::class, 'index'])->name('debtors.index');
    Route::get('debtors/{customer}', [\App\Http\Controllers\Mobile\Sales\DebtorController::class, 'show'])->name('debtors.show');
    
    Route::get('products', [\App\Http\Controllers\Mobile\Sales\ProductController::class, 'index'])->name('products.index');
    Route::get('products/{product}', [\App\Http\Controllers\Mobile\Sales\ProductController::class, 'show'])->name('products.show');
    
    Route::post('location/capture', [\App\Http\Controllers\Mobile\Sales\LocationController::class, 'capture'])->name('location.capture');
    Route::get('yandex/route', [\App\Http\Controllers\Mobile\Sales\LocationController::class, 'generateRoute'])->name('yandex.route');
});


