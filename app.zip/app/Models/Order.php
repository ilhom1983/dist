<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'tenant_id',
        'order_number',
        'customer_id',
        'sales_user_id',
        'warehouse_user_id',
        'delivery_user_id',
        'order_status_id',
        'payment_status_id',
        'total_amount',
        'paid_amount',
        'remaining_amount',
        'tax_amount',
        'discount_amount',
        'shipping_amount',
        'latitude',
        'longitude',
        'notes',
        'order_date',
        'delivery_date',
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'paid_amount' => 'decimal:2',
        'remaining_amount' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'shipping_amount' => 'decimal:2',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'order_date' => 'datetime',
        'delivery_date' => 'datetime',
    ];

    // Relationships
    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function salesUser()
    {
        return $this->belongsTo(TenantUser::class, 'sales_user_id');
    }

    public function warehouseUser()
    {
        return $this->belongsTo(TenantUser::class, 'warehouse_user_id');
    }

    public function deliveryUser()
    {
        return $this->belongsTo(TenantUser::class, 'delivery_user_id');
    }

    public function orderStatus()
    {
        return $this->belongsTo(OrderStatus::class, 'order_status_id');
    }

    public function paymentStatus()
    {
        return $this->belongsTo(PaymentStatus::class, 'payment_status_id');
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function orderStatusHistory()
    {
        return $this->hasMany(OrderStatusHistory::class);
    }

    public function commitments()
    {
        return $this->hasMany(Commitment::class);
    }

    // Accessors
    public function getStatusNameAttribute()
    {
        return $this->orderStatus->name ?? '';
    }

    public function getPaymentStatusNameAttribute()
    {
        return $this->paymentStatus->name ?? '';
    }

    public function getIsFullyPaidAttribute()
    {
        return $this->remaining_amount <= 0;
    }

    public function getIsOverdueAttribute()
    {
        return $this->remaining_amount > 0 && $this->delivery_date && $this->delivery_date->isPast();
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->whereHas('orderStatus', function ($q) {
            $q->whereNotIn('name', ['cancelled', 'closed']);
        });
    }

    public function scopeByStatus($query, $status)
    {
        return $query->whereHas('orderStatus', function ($q) use ($status) {
            $q->where('name', $status);
        });
    }

    public function scopeByPaymentStatus($query, $status)
    {
        return $query->whereHas('paymentStatus', function ($q) use ($status) {
            $q->where('name', $status);
        });
    }

    public function scopeByCustomer($query, $customerId)
    {
        return $query->where('customer_id', $customerId);
    }

    public function scopeBySalesUser($query, $userId)
    {
        return $query->where('sales_user_id', $userId);
    }

    public function scopeByDeliveryUser($query, $userId)
    {
        return $query->where('delivery_user_id', $userId);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeOverdue($query)
    {
        return $query->where('remaining_amount', '>', 0)
                    ->where('delivery_date', '<', now());
    }

    public function scopeUnpaid($query)
    {
        return $query->where('remaining_amount', '>', 0);
    }

    // Methods
    public function updateStatus($statusName, $notes = null)
    {
        $status = OrderStatus::where('name', $statusName)->first();
        
        if ($status) {
            $this->order_status_id = $status->id;
            $this->save();

            // Create status history
            $this->orderStatusHistory()->create([
                'order_status_id' => $status->id,
                'notes' => $notes,
                'changed_by' => auth()->id(),
            ]);

            // Update delivery date if status is 'delivered'
            if ($statusName === 'delivered' && !$this->delivery_date) {
                $this->delivery_date = now();
                $this->save();
            }
        }
    }

    public function addPayment($amount, $methodId, $notes = null)
    {
        $payment = $this->payments()->create([
            'tenant_id' => $this->tenant_id,
            'amount' => $amount,
            'payment_method_id' => $methodId,
            'payment_status_id' => PaymentStatus::where('name', 'paid')->first()->id,
            'payment_date' => now(),
            'notes' => $notes,
        ]);

        // Update order payment amounts
        $this->paid_amount += $amount;
        $this->remaining_amount = max(0, $this->total_amount - $this->paid_amount);
        $this->save();

        // Update payment status
        if ($this->remaining_amount <= 0) {
            $this->updatePaymentStatus('paid');
        }

        return $payment;
    }

    public function updatePaymentStatus($statusName)
    {
        $status = PaymentStatus::where('name', $statusName)->first();
        
        if ($status) {
            $this->payment_status_id = $status->id;
            $this->save();
        }
    }

    public function calculateTotals()
    {
        $subtotal = $this->orderItems->sum('total_price');
        $this->total_amount = $subtotal + $this->tax_amount + $this->shipping_amount - $this->discount_amount;
        $this->remaining_amount = max(0, $this->total_amount - $this->paid_amount);
        $this->save();
    }

    public function generateOrderNumber()
    {
        $prefix = 'ORD';
        $year = date('Y');
        $month = date('m');
        
        $lastOrder = static::where('tenant_id', $this->tenant_id)
                           ->whereYear('created_at', $year)
                           ->whereMonth('created_at', $month)
                           ->orderBy('id', 'desc')
                           ->first();

        $sequence = $lastOrder ? (intval(substr($lastOrder->order_number, -4)) + 1) : 1;
        
        return $prefix . $year . $month . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($order) {
            if (!$order->order_number) {
                $order->order_number = $order->generateOrderNumber();
            }
            if (!$order->order_date) {
                $order->order_date = now();
            }
        });
    }
}
