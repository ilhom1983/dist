<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductBrand extends Model
{
    protected $fillable = [
        'tenant_id', 'name', 'description', 'logo', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class, 'brand_id');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    // Brand assignments (many-to-many)
    public function userAssignments()
    {
        return $this->hasMany(UserBrandAssignment::class, 'brand_id');
    }

    public function assignedUsers()
    {
        return $this->belongsToMany(TenantUser::class, 'user_brand_assignments', 'brand_id', 'tenant_user_id')
                    ->withPivot('is_active')
                    ->withTimestamps();
    }

    // Helper methods
    public function getAssignedUserIds()
    {
        return $this->userAssignments()
                    ->where('is_active', true)
                    ->pluck('tenant_user_id')
                    ->toArray();
    }
}
