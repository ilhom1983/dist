<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class TenantUser extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = [
        'tenant_id',
        'name',
        'email',
        'phone',
        'password',
        'role',
        'territory',
        'manager_id',
        'is_active',
        'notes',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'is_active' => 'boolean',
    ];

    // Relationships
    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function salesOrders()
    {
        return $this->hasMany(Order::class, 'sales_user_id');
    }

    public function warehouseOrders()
    {
        return $this->hasMany(Order::class, 'warehouse_user_id');
    }

    public function deliveryOrders()
    {
        return $this->hasMany(Order::class, 'delivery_user_id');
    }

    public function payments()
    {
        return $this->hasMany(Payment::class, 'created_by');
    }

    public function inventoryTransactions()
    {
        return $this->hasMany(InventoryTransaction::class, 'created_by');
    }

    public function customerStatusChanges()
    {
        return $this->hasMany(CustomerStatusAssignment::class, 'changed_by');
    }

    public function orderStatusChanges()
    {
        return $this->hasMany(OrderStatusHistory::class, 'changed_by');
    }

    public function salaryPayments()
    {
        return $this->hasMany(SalaryPayment::class);
    }

    public function commissionCalculations()
    {
        return $this->hasMany(CommissionCalculation::class);
    }

    public function attendanceRecords()
    {
        return $this->hasMany(AttendanceRecord::class);
    }

    public function commitments()
    {
        return $this->hasMany(Commitment::class, 'created_by');
    }

    // Manager relationships
    public function manager()
    {
        return $this->belongsTo(TenantUser::class, 'manager_id');
    }

    public function managedUsers()
    {
        return $this->hasMany(TenantUser::class, 'manager_id');
    }

    // Brand assignments (many-to-many)
    public function brandAssignments()
    {
        return $this->hasMany(UserBrandAssignment::class);
    }

    public function assignedBrands()
    {
        return $this->belongsToMany(ProductBrand::class, 'user_brand_assignments', 'tenant_user_id', 'brand_id')
                    ->withPivot('is_active')
                    ->withTimestamps();
    }

    // Territory assignments (many-to-many)
    public function territoryAssignments()
    {
        return $this->hasMany(UserTerritoryAssignment::class);
    }

    public function assignedTerritories()
    {
        return $this->hasMany(UserTerritoryAssignment::class);
    }

    // Helper methods for brand access
    public function hasBrandAccess($brandId)
    {
        // If no brands are assigned, user has access to all brands
        if (!$this->hasAnyBrandAssigned()) {
            return true;
        }
        
        return $this->brandAssignments()
                    ->where('brand_id', $brandId)
                    ->where('is_active', true)
                    ->exists();
    }

    public function getAssignedBrandIds()
    {
        return $this->brandAssignments()
                    ->where('is_active', true)
                    ->pluck('brand_id')
                    ->toArray();
    }

    public function hasAnyBrandAssigned()
    {
        return $this->brandAssignments()
                    ->where('is_active', true)
                    ->exists();
    }

    // New method to check if user has restricted brand access
    public function hasRestrictedBrandAccess()
    {
        return $this->hasAnyBrandAssigned();
    }

    // Method to get all accessible brand IDs (all brands if none assigned, or specific assigned brands)
    public function getAccessibleBrandIds()
    {
        if (!$this->hasAnyBrandAssigned()) {
            // Return all brand IDs for the tenant if no brands are assigned
            return ProductBrand::where('tenant_id', $this->tenant_id)
                              ->where('is_active', true)
                              ->pluck('id')
                              ->toArray();
        }
        
        return $this->getAssignedBrandIds();
    }

    // Helper methods for territory access
    public function hasTerritoryAccess($territoryName)
    {
        return $this->territoryAssignments()
                    ->where('territory_name', $territoryName)
                    ->where('is_active', true)
                    ->exists();
    }

    public function getAssignedTerritories()
    {
        return $this->territoryAssignments()
                    ->where('is_active', true)
                    ->pluck('territory_name')
                    ->toArray();
    }

    // Role methods
    public function hasRole($role)
    {
        return $this->role === $role;
    }

    public function isSuperAdmin()
    {
        return $this->role === 'superadmin';
    }

    public function isAdmin()
    {
        return in_array($this->role, ['superadmin', 'admin']);
    }

    public function isOperator()
    {
        return in_array($this->role, ['superadmin', 'admin', 'operator']);
    }

    public function isManager()
    {
        return in_array($this->role, ['superadmin', 'admin', 'operator', 'manager']);
    }

    public function isSales()
    {
        return $this->role === 'sales';
    }

    public function isWarehouse()
    {
        return $this->role === 'warehouse';
    }

    public function isDelivery()
    {
        return $this->role === 'delivery';
    }

    public function usesWebUI()
    {
        return in_array($this->role, ['superadmin', 'admin', 'operator']);
    }

    public function usesMobileUI()
    {
        return in_array($this->role, ['manager', 'sales', 'warehouse', 'delivery']);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByRole($query, $role)
    {
        return $query->where('role', $role);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }
}
