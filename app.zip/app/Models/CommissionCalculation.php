<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommissionCalculation extends Model
{
    protected $fillable = [
        'tenant_id', 'tenant_user_id', 'month', 'total_sales', 'total_orders', 'commission_rate', 'commission_amount',
    ];

    protected $casts = [
        'total_sales' => 'decimal:2',
        'total_orders' => 'integer',
        'commission_rate' => 'decimal:2',
        'commission_amount' => 'decimal:2',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function tenantUser()
    {
        return $this->belongsTo(TenantUser::class);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('tenant_user_id', $userId);
    }

    public function scopeByMonth($query, $month)
    {
        return $query->where('month', $month);
    }
}
