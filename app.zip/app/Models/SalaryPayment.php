<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalaryPayment extends Model
{
    protected $fillable = [
        'tenant_id', 'tenant_user_id', 'month', 'base_salary', 'commission', 'bonus', 'total_amount', 'payment_date', 'notes',
    ];

    protected $casts = [
        'base_salary' => 'decimal:2',
        'commission' => 'decimal:2',
        'bonus' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'payment_date' => 'date',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function tenantUser()
    {
        return $this->belongsTo(TenantUser::class);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('tenant_user_id', $userId);
    }

    public function scopeByMonth($query, $month)
    {
        return $query->where('month', $month);
    }
}
