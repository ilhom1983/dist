<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerStatusAssignment extends Model
{
    protected $fillable = [
        'customer_id', 'status', 'notes', 'changed_by',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function changedBy()
    {
        return $this->belongsTo(TenantUser::class, 'changed_by');
    }

    public function scopeByCustomer($query, $customerId)
    {
        return $query->where('customer_id', $customerId);
    }

    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }
}
