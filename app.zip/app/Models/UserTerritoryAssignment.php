<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserTerritoryAssignment extends Model
{
    protected $fillable = [
        'tenant_id', 'tenant_user_id', 'territory_name', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function tenantUser()
    {
        return $this->belongsTo(TenantUser::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('tenant_user_id', $userId);
    }

    public function scopeByTerritory($query, $territoryName)
    {
        return $query->where('territory_name', $territoryName);
    }
}
