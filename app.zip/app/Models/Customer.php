<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = [
        'tenant_id', 'name', 'email', 'phone', 'address', 'latitude', 'longitude',
        'city', 'postal_code', 'country', 'customer_group_id', 'telegram_chat_id',
        'image', 'delivery_notes', 'is_active',
    ];

    protected $casts = [
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'delivery_notes' => 'array',
        'is_active' => 'boolean',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function customerGroup()
    {
        return $this->belongsTo(CustomerGroup::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function commitments()
    {
        return $this->hasMany(Commitment::class);
    }

    public function customerStatusAssignments()
    {
        return $this->hasMany(CustomerStatusAssignment::class);
    }

    public function telegramNotifications()
    {
        return $this->hasMany(TelegramNotification::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeByGroup($query, $groupId)
    {
        return $query->where('customer_group_id', $groupId);
    }
}
