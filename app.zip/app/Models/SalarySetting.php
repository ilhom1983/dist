<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalarySetting extends Model
{
    protected $fillable = [
        'tenant_id', 'attendance_bonus', 'commission_calculation', 'payment_schedule', 'is_active',
    ];

    protected $casts = [
        'attendance_bonus' => 'decimal:2',
        'commission_calculation' => 'array',
        'payment_schedule' => 'array',
        'is_active' => 'boolean',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }
}
