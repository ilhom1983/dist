<?php

namespace App\Http\Controllers;

use App\Models\Product;

use App\Models\ProductCategory;
use App\Models\ProductBrand;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        $products = Product::with(['category', 'brand'])
            ->where('tenant_id', $user->tenant_id)
            ->latest()
            ->paginate(20);

        // Get available brands for filtering
        $availableBrands = ProductBrand::where('tenant_id', $user->tenant_id)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('admin.products.index', compact('products', 'availableBrands'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        $categories = ProductCategory::where('tenant_id', $user->tenant_id)->active()->get();
        $brands = ProductBrand::where('tenant_id', $user->tenant_id)->active()->get();

        return view('admin.products.create', compact('categories', 'brands') + ['availableBrands' => $brands]);
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        $request->validate([
            'name' => 'required|string|max:255',
            'sku' => 'required|string|max:255|unique:products,sku,NULL,id,tenant_id,' . $user->tenant_id,
            'category_id' => 'nullable|exists:product_categories,id',
            'brand_id' => 'nullable|exists:product_brands,id',
            'price' => 'required|numeric|min:0',
            'cost_price' => 'required|numeric|min:0',
            'stock_quantity' => 'required|integer|min:0',
            'min_stock_level' => 'required|integer|min:0',
        ]);

        Product::create([
            'tenant_id' => $user->tenant_id,
            'name' => $request->name,
            'sku' => $request->sku,
            'category_id' => $request->category_id,
            'brand_id' => $request->brand_id,
            'price' => $request->price,
            'cost_price' => $request->cost_price,
            'stock_quantity' => $request->stock_quantity,
            'min_stock_level' => $request->min_stock_level,
            'description' => $request->description,
            'is_active' => true,
        ]);

        return redirect()->route('products.index')->with('success', 'Product created successfully.');
    }

    public function show(Product $product)
    {
        $this->authorize('view', $product);
        
        $product->load(['category', 'brand']);
        return view('admin.products.show', compact('product'));
    }

    public function edit(Product $product)
    {
        $this->authorize('update', $product);
        
        $user = auth()->guard('tenant')->user();
        $categories = ProductCategory::where('tenant_id', $user->tenant_id)->active()->get();
        $brands = ProductBrand::where('tenant_id', $user->tenant_id)->active()->get();

        return view('admin.products.edit', compact('product', 'categories', 'brands') + ['availableBrands' => $brands]);
    }

    public function update(Request $request, Product $product)
    {
        $this->authorize('update', $product);
        
        $user = auth()->guard('tenant')->user();
        
        $request->validate([
            'name' => 'required|string|max:255',
            'sku' => 'required|string|max:255|unique:products,sku,' . $product->id . ',id,tenant_id,' . $user->tenant_id,
            'category_id' => 'nullable|exists:product_categories,id',
            'brand_id' => 'nullable|exists:product_brands,id',
            'price' => 'required|numeric|min:0',
            'cost_price' => 'required|numeric|min:0',
            'stock_quantity' => 'required|integer|min:0',
            'min_stock_level' => 'required|integer|min:0',
        ]);

        $product->update($request->all());

        return redirect()->route('products.index')->with('success', 'Product updated successfully.');
    }

    public function destroy(Product $product)
    {
        $this->authorize('delete', $product);
        
        $product->delete();

        return redirect()->route('products.index')->with('success', 'Product deleted successfully.');
    }
} 