<?php

namespace App\Http\Controllers\Mobile\Warehouse;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\TenantUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access warehouse orders.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get orders to load (approved status)
        $ordersToLoad = Order::with(['customer', 'orderStatus', 'orderItems.product'])
            ->where('tenant_id', $tenantId)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'approved');
            })
            ->latest()
            ->paginate(15);

        // Get orders loaded by this user
        $loadedOrders = Order::with(['customer', 'orderStatus', 'orderItems.product', 'deliveryUser'])
            ->where('tenant_id', $tenantId)
            ->where('warehouse_user_id', $user->id)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'loaded');
            })
            ->latest()
            ->paginate(15);

        // Get delivery users for assignment dropdown
        $deliveryUsers = TenantUser::where('tenant_id', $tenantId)
            ->where('role', 'delivery')
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('mobile.warehouse.orders.index', compact('ordersToLoad', 'loadedOrders', 'deliveryUsers'));
    }

    public function show(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view order details.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        // Ensure warehouse user can only see orders from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->load(['customer', 'orderStatus', 'orderItems.product', 'salesUser']);
        
        return view('mobile.warehouse.orders.show', compact('order'));
    }

    public function loadOrder(Request $request, Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to load orders.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        // Ensure warehouse user can only load orders from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        // Check if order is in approved status
        if ($order->orderStatus->name !== 'approved') {
            return redirect()->back()->with('error', 'Order must be approved before loading.');
        }
        
        // Validate stock availability
        $insufficientStock = [];
        foreach ($order->orderItems as $item) {
            if ($item->product->stock_quantity < $item->quantity) {
                $insufficientStock[] = [
                    'product' => $item->product->name,
                    'required' => $item->quantity,
                    'available' => $item->product->stock_quantity
                ];
            }
        }
        
        if (!empty($insufficientStock)) {
            return redirect()->back()->with('error', 'Insufficient stock for some items. Please check inventory.');
        }
        
        // Get loaded status
        $loadedStatus = OrderStatus::where('name', 'loaded')->first();
        if (!$loadedStatus) {
            return redirect()->back()->with('error', 'System error: Loaded status not found. Contact administrator.');
        }
        
        DB::transaction(function () use ($order, $user, $loadedStatus) {
            // Update order status to loaded
            $order->update([
                'order_status_id' => $loadedStatus->id,
                'warehouse_user_id' => $user->id,
            ]);
            
            // Reduce stock for each item
            foreach ($order->orderItems as $item) {
                $item->product->updateStock(-$item->quantity, 'sale', $user->id);
            }
        });
        
        return redirect()->route('mobile.warehouse.orders.index')
            ->with('success', 'Order #' . $order->order_number . ' has been loaded successfully!');
    }

    public function loadOrderForm(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to load orders.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        // Ensure warehouse user can only see orders from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        // Check if order is in approved status
        if ($order->orderStatus->name !== 'approved') {
            return redirect()->back()->with('error', 'Order must be approved before loading.');
        }
        
        $order->load(['customer', 'orderStatus', 'orderItems.product']);
        
        return view('mobile.warehouse.orders.load', compact('order'));
    }

    public function bulkAssign(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to assign orders.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        $request->validate([
            'order_ids' => 'required|string',
            'delivery_user_id' => 'required|exists:tenant_users,id',
        ]);
        
        $tenantId = $user->tenant_id;
        $orderIds = explode(',', $request->order_ids);
        $deliveryUserId = $request->delivery_user_id;
        
        // Verify delivery user belongs to the same tenant
        $deliveryUser = TenantUser::where('id', $deliveryUserId)
            ->where('tenant_id', $tenantId)
            ->where('role', 'delivery')
            ->where('is_active', true)
            ->first();
            
        if (!$deliveryUser) {
            return redirect()->back()->with('error', 'Invalid delivery user selected.');
        }
        
        // Get loaded status
        $loadedStatus = OrderStatus::where('name', 'loaded')->first();
        if (!$loadedStatus) {
            return redirect()->back()->with('error', 'System error: Loaded status not found. Contact administrator.');
        }
        
        $assignedCount = 0;
        
        DB::transaction(function () use ($orderIds, $tenantId, $user, $deliveryUserId, $loadedStatus, $deliveryUser, &$assignedCount) {
            $assignedCount = 0;
            
            foreach ($orderIds as $orderId) {
                // First try to find orders that are already loaded by this warehouse user
                $order = Order::where('id', $orderId)
                    ->where('tenant_id', $tenantId)
                    ->where('warehouse_user_id', $user->id)
                    ->whereHas('orderStatus', function ($q) {
                        $q->where('name', 'loaded');
                    })
                    ->first();
                
                // If not found, try to find approved orders that need to be loaded first
                if (!$order) {
                    $order = Order::where('id', $orderId)
                        ->where('tenant_id', $tenantId)
                        ->whereHas('orderStatus', function ($q) {
                            $q->where('name', 'approved');
                        })
                        ->first();
                    
                    // If found, load the order first (assign to warehouse user and change status)
                    if ($order) {
                        // Load order items for stock validation
                        $order->load('orderItems.product');
                        
                        // Validate stock availability
                        $insufficientStock = [];
                        foreach ($order->orderItems as $item) {
                            if ($item->product->stock_quantity < $item->quantity) {
                                $insufficientStock[] = [
                                    'product' => $item->product->name,
                                    'required' => $item->quantity,
                                    'available' => $item->product->stock_quantity
                                ];
                            }
                        }
                        
                        if (!empty($insufficientStock)) {
                            continue; // Skip this order if insufficient stock
                        }
                        
                        // Load the order first
                        $order->update([
                            'order_status_id' => $loadedStatus->id,
                            'warehouse_user_id' => $user->id,
                        ]);
                        
                        // Reduce stock for each item
                        foreach ($order->orderItems as $item) {
                            $item->product->updateStock(-$item->quantity, 'sale', $user->id);
                        }
                    }
                }
                
                if ($order) {
                    // Update order with delivery user assignment
                    $order->update([
                        'delivery_user_id' => $deliveryUserId,
                    ]);
                    
                    // Add status history
                    $order->orderStatusHistory()->create([
                        'order_status_id' => $loadedStatus->id,
                        'notes' => 'Order assigned to delivery user: ' . $deliveryUser->name,
                        'changed_by' => $user->id,
                    ]);
                    
                    $assignedCount++;
                }
            }
            
            if ($assignedCount === 0) {
                throw new \Exception('No valid orders found to assign. Please ensure orders are approved and have sufficient stock.');
            }
        });
        
        return redirect()->route('mobile.warehouse.orders.index')
            ->with('success', $assignedCount . ' order(s) assigned to ' . $deliveryUser->name . ' successfully!');
    }
} 