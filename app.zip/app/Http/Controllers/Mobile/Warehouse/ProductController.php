<?php

namespace App\Http\Controllers\Mobile\Warehouse;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductBrand;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access products.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get filter parameters
        $categoryId = $request->get('category_id');
        $brandId = $request->get('brand_id');
        $stockStatus = $request->get('stock_status', 'all');
        $search = $request->get('search');

        // Build query
        $query = Product::with(['category', 'brand'])
            ->where('tenant_id', $tenantId)
            ->where('is_active', true);

        // Apply filters
        if ($categoryId) {
            $query->where('category_id', $categoryId);
        }

        if ($brandId) {
            $query->where('brand_id', $brandId);
        }

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%")
                  ->orWhere('barcode', 'like', "%{$search}%");
            });
        }

        // Apply stock status filter
        switch ($stockStatus) {
            case 'low_stock':
                $query->whereRaw('stock_quantity <= min_stock_level')
                      ->where('stock_quantity', '>', 0);
                break;
            case 'out_of_stock':
                $query->where('stock_quantity', 0);
                break;
            case 'in_stock':
                $query->where('stock_quantity', '>', 0)
                      ->whereRaw('stock_quantity > min_stock_level');
                break;
        }

        $products = $query->orderBy('name')->paginate(20);

        // Get categories and brands for filters
        $categories = ProductCategory::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        $brands = ProductBrand::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('mobile.warehouse.products.index', compact(
            'products',
            'categories',
            'brands',
            'categoryId',
            'brandId',
            'stockStatus',
            'search'
        ));
    }

    public function show(Product $product)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view product details.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        // Ensure warehouse user can only see products from their tenant
        if ($product->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to product.');
        }
        
        $product->load(['category', 'brand']);
        
        return view('mobile.warehouse.products.show', compact('product'));
    }

    public function search(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return response()->json(['error' => 'Access denied'], 403);
        }
        
        $search = $request->get('q');
        
        if (!$search) {
            return response()->json([]);
        }
        
        $products = Product::where('tenant_id', $user->tenant_id)
            ->where('is_active', true)
            ->where(function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%")
                      ->orWhere('sku', 'like', "%{$search}%")
                      ->orWhere('barcode', 'like', "%{$search}%");
            })
            ->select('id', 'name', 'sku', 'barcode', 'stock_quantity', 'min_stock_level', 'price')
            ->limit(10)
            ->get();
        
        return response()->json($products);
    }
} 