<?php

namespace App\Http\Controllers\Mobile\Warehouse;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\InventoryTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access the warehouse dashboard.');
        }
        
        // Check if user has warehouse role
        if ($user->role !== 'warehouse') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Warehouse role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Warehouse-specific statistics
        $stats = [
            'orders_to_load' => Order::where('tenant_id', $tenantId)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'approved');
                })
                ->count(),
            'low_stock_alerts' => Product::where('tenant_id', $tenantId)
                ->whereRaw('stock_quantity <= min_stock_level')
                ->where('stock_quantity', '>', 0)
                ->count(),
            'out_of_stock' => Product::where('tenant_id', $tenantId)
                ->where('stock_quantity', 0)
                ->where('is_active', true)
                ->count(),
            'today_loaded_orders' => Order::where('tenant_id', $tenantId)
                ->where('warehouse_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'loaded');
                })
                ->whereDate('updated_at', Carbon::today())
                ->count(),
            'total_inventory_value' => Product::where('tenant_id', $tenantId)
                ->where('is_active', true)
                ->sum(DB::raw('stock_quantity * cost_price')),
            'total_products' => Product::where('tenant_id', $tenantId)
                ->where('is_active', true)
                ->count(),
        ];

        // Recent orders to load
        $ordersToLoad = Order::with(['customer', 'orderStatus', 'orderItems.product'])
            ->where('tenant_id', $tenantId)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'approved');
            })
            ->latest()
            ->limit(5)
            ->get();

        // Low stock products
        $lowStockProducts = Product::with(['category', 'brand'])
            ->where('tenant_id', $tenantId)
            ->whereRaw('stock_quantity <= min_stock_level')
            ->where('stock_quantity', '>', 0)
            ->where('is_active', true)
            ->limit(5)
            ->get();

        // Recent inventory transactions
        $recentTransactions = InventoryTransaction::with(['product', 'createdBy'])
            ->where('tenant_id', $tenantId)
            ->latest()
            ->limit(10)
            ->get();

        // Today's loaded orders
        $todayLoadedOrders = Order::with(['customer', 'orderStatus'])
            ->where('tenant_id', $tenantId)
            ->where('warehouse_user_id', $user->id)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'loaded');
            })
            ->whereDate('updated_at', Carbon::today())
            ->latest()
            ->limit(5)
            ->get();

        return view('mobile.warehouse.dashboard', compact(
            'stats',
            'ordersToLoad',
            'lowStockProducts',
            'recentTransactions',
            'todayLoadedOrders'
        ));
    }
} 