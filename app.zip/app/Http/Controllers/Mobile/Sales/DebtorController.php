<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use App\Models\Commitment;
use App\Models\Customer;
use Illuminate\Http\Request;

class DebtorController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access debtors.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Get debtors (customers with overdue commitments) for this sales user
        $debtors = Commitment::with(['customer'])
            ->where('tenant_id', $user->tenant_id)
            ->whereIn('customer_id', function ($q) use ($user) {
                $q->select('customer_id')
                  ->from('orders')
                  ->where('sales_user_id', $user->id);
            })
            ->where('status', 'overdue')
            ->orderBy('due_date', 'asc')
            ->paginate(20);

        return view('mobile.sales.debtors.index', compact('debtors'));
    }

    public function show(Customer $customer)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view debtors.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Ensure sales user can only see their customers
        if ($customer->tenant_id !== $user->tenant_id || 
            !$customer->orders()->where('sales_user_id', $user->id)->exists()) {
            abort(403, 'Unauthorized access to customer.');
        }
        
        // Get all commitments for this customer
        $commitments = Commitment::where('customer_id', $customer->id)
            ->where('tenant_id', $user->tenant_id)
            ->orderBy('due_date', 'asc')
            ->get();
            
        // Get orders for this customer by this sales user
        $orders = $customer->orders()
            ->where('sales_user_id', $user->id)
            ->with(['orderStatus', 'paymentStatus'])
            ->latest()
            ->get();
        
        return view('mobile.sales.debtors.show', compact('customer', 'commitments', 'orders'));
    }
} 