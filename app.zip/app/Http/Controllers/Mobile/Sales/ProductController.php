<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access products.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $products = Product::where('tenant_id', $user->tenant_id)
            ->where('is_active', true)
            ->with(['category', 'brand'])
            ->orderBy('name')
            ->paginate(20);

        return view('mobile.sales.products.index', compact('products'));
    }

    public function show(Product $product)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view products.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Ensure sales user can only see products from their tenant
        if ($product->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to product.');
        }
        
        $product->load(['category', 'brand']);
        
        return view('mobile.sales.products.show', compact('product'));
    }
} 