<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\CustomerGroup;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access customers.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Get search query
        $search = $request->get('search', '');
        
        // Get all customers for this tenant (sales users can see all customers)
        $customers = Customer::with(['customerGroup'])
            ->where('tenant_id', $user->tenant_id)
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('phone', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%")
                      ->orWhere('city', 'like', "%{$search}%")
                      ->orWhere('address', 'like', "%{$search}%");
                });
            })
            ->withCount(['orders' => function ($q) use ($user) {
                $q->where('sales_user_id', $user->id);
            }])
            ->latest()
            ->paginate(20);

        // Debug information
        \Log::info('Sales customers listing', [
            'user_id' => $user->id,
            'tenant_id' => $user->tenant_id,
            'search' => $search,
            'total_customers' => $customers->total(),
            'current_page' => $customers->currentPage(),
            'per_page' => $customers->perPage(),
        ]);

        return view('mobile.sales.customers.index', compact('customers', 'search'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create customers.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $customerGroups = CustomerGroup::where('tenant_id', $user->tenant_id)->active()->get();

        return view('mobile.sales.customers.create', compact('customerGroups'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create customers.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'required|string|max:255',
            'address' => 'required|string',
            'city' => 'nullable|string|max:255',
            'customer_group_id' => 'nullable|exists:customer_groups,id',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'image' => 'required|file|mimes:jpeg,png,jpg|max:2048', // Changed from 'image' to 'file' for better compatibility
        ]);

        // Handle image upload
        $imagePath = null;
        if ($request->hasFile('image')) {
            try {
                $image = $request->file('image');
                
                // Debug information
                \Log::info('Image upload debug', [
                    'original_name' => $image->getClientOriginalName(),
                    'mime_type' => $image->getMimeType(),
                    'size' => $image->getSize(),
                    'extension' => $image->getClientOriginalExtension(),
                    'real_path' => $image->getRealPath(),
                ]);
                
                $imageName = 'customer_' . time() . '_' . $user->id . '.' . $image->getClientOriginalExtension();
                $imagePath = $image->storeAs('customers', $imageName, 'public');
                
                if (!$imagePath) {
                    return redirect()->back()->with('error', 'Ошибка при сохранении изображения. Попробуйте еще раз.');
                }
            } catch (\Exception $e) {
                \Log::error('Image upload error', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                return redirect()->back()->with('error', 'Ошибка при загрузке изображения: ' . $e->getMessage());
            }
        } else {
            \Log::warning('No image file found in request', [
                'files' => $request->allFiles(),
                'has_file' => $request->hasFile('image')
            ]);
        }

        Customer::create([
            'tenant_id' => $user->tenant_id,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'city' => $request->city,
            'customer_group_id' => $request->customer_group_id,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'image' => $imagePath,
            'is_active' => true,
        ]);

        // Debug information
        \Log::info('Customer created successfully', [
            'user_id' => $user->id,
            'tenant_id' => $user->tenant_id,
            'customer_name' => $request->name,
            'customer_phone' => $request->phone,
            'image_path' => $imagePath,
        ]);

        return redirect()->route('mobile.sales.customers.index')->with('success', 'Клиент успешно создан!');
    }

    public function show(Customer $customer)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view customers.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Ensure sales user can only see customers from their tenant
        if ($customer->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to customer.');
        }
        
        // Debug image path
        if ($customer->image) {
            \Log::info('Customer image debug', [
                'customer_id' => $customer->id,
                'image_path' => $customer->image,
                'full_url' => asset('storage/' . $customer->image),
                'storage_exists' => \Storage::disk('public')->exists($customer->image),
            ]);
        }
        
        $customer->load(['customerGroup', 'orders' => function ($q) use ($user) {
            $q->where('sales_user_id', $user->id);
        }, 'commitments']);
        
        return view('mobile.sales.customers.show', compact('customer'));
    }
} 