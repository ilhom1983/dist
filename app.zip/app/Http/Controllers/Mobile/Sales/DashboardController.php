<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Commitment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access the sales dashboard.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Sales user specific data
        $roleData = [
            'my_orders' => Order::where('tenant_id', $tenantId)
                ->where('sales_user_id', $user->id)
                ->count(),
            'my_active_orders' => Order::where('tenant_id', $tenantId)
                ->where('sales_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->whereNotIn('name', ['cancelled', 'closed']);
                })
                ->count(),
            'my_cancelled_orders' => Order::where('tenant_id', $tenantId)
                ->where('sales_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'cancelled');
                })
                ->where('created_at', '>=', now()->startOfMonth()) // Until end of current month
                ->count(),
            'my_returned_orders' => Order::where('tenant_id', $tenantId)
                ->where('sales_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'returned');
                })
                ->where('created_at', '>=', now()->startOfMonth()) // Until end of current month
                ->count(),
            'my_sales' => Order::where('tenant_id', $tenantId)
                ->where('sales_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'delivered');
                })
                ->sum('total_amount'),
            'my_customers' => Customer::where('tenant_id', $tenantId)
                ->whereHas('orders', function ($q) use ($user) {
                    $q->where('sales_user_id', $user->id);
                })
                ->count(),
            'my_debtors' => Commitment::where('tenant_id', $tenantId)
                ->whereIn('customer_id', function ($q) use ($user) {
                    $q->select('customer_id')
                      ->from('orders')
                      ->where('sales_user_id', $user->id);
                })
                ->where('status', 'overdue')
                ->sum('remaining_amount'),
        ];

        // Recent orders for this sales user
        $recentOrders = Order::with(['customer', 'orderStatus'])
            ->where('tenant_id', $tenantId)
            ->where('sales_user_id', $user->id)
            ->latest()
            ->limit(5)
            ->get();

        // Recent debtors for this sales user
        $recentDebtors = Commitment::with(['customer'])
            ->where('tenant_id', $tenantId)
            ->whereIn('customer_id', function ($q) use ($user) {
                $q->select('customer_id')
                  ->from('orders')
                  ->where('sales_user_id', $user->id);
            })
            ->where('status', 'overdue')
            ->latest()
            ->limit(3)
            ->get();

        return view('mobile.sales.dashboard', compact('roleData', 'recentOrders', 'recentDebtors'));
    }
} 