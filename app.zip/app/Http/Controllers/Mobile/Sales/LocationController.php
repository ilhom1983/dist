<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function capture(Request $request)
    {
        $request->validate([
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
        ]);

        return response()->json([
            'success' => true,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
        ]);
    }

    public function generateRoute(Request $request)
    {
        $request->validate([
            'from_lat' => 'required|numeric|between:-90,90',
            'from_lng' => 'required|numeric|between:-180,180',
            'to_lat' => 'required|numeric|between:-90,90',
            'to_lng' => 'required|numeric|between:-180,180',
        ]);

        // Generate Yandex Navigator route URL
        $yandexUrl = "https://yandex.ru/maps/?rtext={$request->from_lat},{$request->from_lng}~{$request->to_lat},{$request->to_lng}&rtt=auto";

        return response()->json([
            'success' => true,
            'yandex_url' => $yandexUrl,
        ]);
    }
} 