<?php

namespace App\Http\Controllers\Mobile\Sales;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;
use App\Models\OrderStatus;
use App\Models\PaymentStatus;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access orders.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $orders = Order::with(['customer', 'orderStatus', 'paymentStatus'])
            ->where('tenant_id', $user->tenant_id)
            ->where('sales_user_id', $user->id)
            ->latest()
            ->paginate(20);

        return view('mobile.sales.orders.index', compact('orders'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create orders.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Get ALL customers for the tenant (sales users should be able to create orders for any customer)
        $customers = Customer::where('tenant_id', $user->tenant_id)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        // Debug information
        \Log::info('Order creation - customers loaded', [
            'user_id' => $user->id,
            'tenant_id' => $user->tenant_id,
            'total_customers' => $customers->count(),
            'customers' => $customers->pluck('name', 'id')->toArray()
        ]);
            
        $products = Product::where('tenant_id', $user->tenant_id)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('mobile.sales.orders.create', compact('customers', 'products'));
    }

    public function store(Request $request)
    {
        \Log::info('Order store method called', [
            'request_data' => $request->all(),
            'user_id' => auth()->guard('tenant')->user() ? auth()->guard('tenant')->user()->id : 'no_user'
        ]);
        
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create orders.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'products' => 'required|array|min:1',
            'products.*.product_id' => 'required|exists:products,id',
            'products.*.quantity' => 'required|integer|min:1',
            'notes' => 'nullable|string',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
        ]);

        // Calculate totals
        $totalAmount = 0;
        $orderItems = [];
        
        foreach ($request->products as $item) {
            $product = Product::find($item['product_id']);
            $totalPrice = $product->price * $item['quantity'];
            $totalAmount += $totalPrice;
            
            $orderItems[] = [
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $product->price,
                'total_price' => $totalPrice,
            ];
        }

        // Get required statuses with error handling
        $pendingOrderStatus = OrderStatus::where('name', 'pending')->first();
        $pendingPaymentStatus = PaymentStatus::where('name', 'pending')->first();
        
        if (!$pendingOrderStatus) {
            return redirect()->back()->with('error', 'Системная ошибка: статус заказа "pending" не найден. Обратитесь к администратору.');
        }
        
        if (!$pendingPaymentStatus) {
            return redirect()->back()->with('error', 'Системная ошибка: статус оплаты "pending" не найден. Обратитесь к администратору.');
        }

        // Create order
        $order = Order::create([
            'tenant_id' => $user->tenant_id,
            'order_number' => 'ORD-' . time() . '-' . $user->id,
            'customer_id' => $request->customer_id,
            'sales_user_id' => $user->id,
            'order_status_id' => $pendingOrderStatus->id,
            'payment_status_id' => $pendingPaymentStatus->id,
            'total_amount' => $totalAmount,
            'remaining_amount' => $totalAmount,
            'notes' => $request->notes,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'order_date' => now(),
        ]);

        // Create order items
        foreach ($orderItems as $item) {
            $order->orderItems()->create($item);
        }

        return redirect()->route('mobile.sales.orders.index')->with('success', 'Заказ успешно создан!');
    }

    public function show(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view orders.');
        }
        
        // Check if user has sales role
        if ($user->role !== 'sales') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Sales role required.');
        }
        
        // Ensure sales user can only see their orders
        if ($order->tenant_id !== $user->tenant_id || $order->sales_user_id !== $user->id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->load(['customer', 'orderItems.product', 'orderStatus', 'paymentStatus', 'payments']);
        
        return view('mobile.sales.orders.show', compact('order'));
    }
} 