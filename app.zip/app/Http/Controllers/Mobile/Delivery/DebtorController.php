<?php

namespace App\Http\Controllers\Mobile\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Commitment;
use Illuminate\Http\Request;

class DebtorController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access debtors.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get customers with pending commitments
        $debtors = Customer::with(['commitments' => function ($q) {
                $q->where('status', 'active')->orderBy('due_date', 'asc');
            }])
            ->where('tenant_id', $tenantId)
            ->whereHas('commitments', function ($q) {
                $q->where('status', 'active');
            })
            ->paginate(20);

        // Calculate statistics
        $stats = [
            'total_debtors' => Customer::where('tenant_id', $tenantId)
                ->whereHas('commitments', function ($q) {
                    $q->where('status', 'active');
                })
                ->count(),
            'total_debt' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->sum('remaining_amount'),
            'overdue_commitments' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('due_date', '<', now()->toDateString())
                ->count(),
            'today_due' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('due_date', now()->toDateString())
                ->count(),
        ];

        return view('mobile.delivery.debtors.index', compact('debtors', 'stats'));
    }

    public function show(Customer $debtor)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view debtor details.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only see customers from their tenant
        if ($debtor->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to customer.');
        }
        
        $debtor->load([
            'commitments' => function ($q) {
                $q->where('status', 'active')->orderBy('due_date', 'asc');
            },
            'orders' => function ($q) {
                $q->latest()->limit(10);
            }
        ]);
        
        return view('mobile.delivery.debtors.show', compact('debtor'));
    }
} 