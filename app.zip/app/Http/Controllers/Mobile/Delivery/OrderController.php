<?php

namespace App\Http\Controllers\Mobile\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\OrderItem;
use App\Models\ReturnReason;
use App\Models\PaymentMethod;
use App\Models\PaymentStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access delivery orders.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get orders to deliver (loaded status) - only assigned to this delivery user
        $ordersToDeliver = Order::with(['customer', 'orderStatus', 'orderItems.product'])
            ->where('tenant_id', $tenantId)
            ->where('delivery_user_id', $user->id) // Only orders assigned to this delivery user
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'loaded');
            })
            ->latest()
            ->paginate(15);

        // Get orders delivered by this user
        $deliveredOrders = Order::with(['customer', 'orderStatus', 'orderItems.product'])
            ->where('tenant_id', $tenantId)
            ->where('delivery_user_id', $user->id)
            ->whereHas('orderStatus', function ($q) {
                $q->whereIn('name', ['delivered', 'paid', 'closed']);
            })
            ->latest()
            ->paginate(15);

        return view('mobile.delivery.orders.index', compact('ordersToDeliver', 'deliveredOrders'));
    }

    public function show(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view order details.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only see orders from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->load(['customer', 'orderStatus', 'orderItems.product', 'salesUser']);
        
        return view('mobile.delivery.orders.show', compact('order'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to update order status.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only update orders from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $request->validate([
            'status' => 'required|in:delivered,paid,returned',
            'notes' => 'nullable|string|max:500',
        ]);
        
        $status = $request->status;
        
        // Handle different status updates
        switch ($status) {
            case 'delivered':
                return $this->handleDeliveredStatus($order, $user, $request->notes);
            case 'paid':
                return $this->handlePaidStatus($order, $user, $request->notes);
            case 'returned':
                return $this->handleReturnedStatus($order, $user, $request->notes);
        }
        
        return redirect()->back()->with('error', 'Invalid status update.');
    }

    private function handleDeliveredStatus($order, $user, $notes = null)
    {
        // Check if order is in loaded status
        if ($order->orderStatus->name !== 'loaded') {
            return redirect()->back()->with('error', 'Order must be loaded before delivery.');
        }
        
        // Get delivered status
        $deliveredStatus = OrderStatus::where('name', 'delivered')->first();
        if (!$deliveredStatus) {
            return redirect()->back()->with('error', 'System error: Delivered status not found. Contact administrator.');
        }
        
        // If order has remaining amount, redirect to commitments page
        if ($order->remaining_amount > 0) {
            return redirect()->route('mobile.delivery.commitments.create', $order)
                ->with('info', 'Order delivered. Please set up payment commitment for remaining amount.');
        }
        
        // Update order status to delivered
        $order->update([
            'order_status_id' => $deliveredStatus->id,
            'delivery_user_id' => $user->id,
            'delivery_date' => now(),
        ]);
        
        // Add status history
        $order->orderStatusHistory()->create([
            'order_status_id' => $deliveredStatus->id,
            'notes' => $notes,
            'changed_by' => $user->id,
        ]);
        
        return redirect()->route('mobile.delivery.orders.index')
            ->with('success', 'Order #' . $order->order_number . ' has been delivered successfully!');
    }

    private function handlePaidStatus($order, $user, $notes = null)
    {
        // Redirect to payments page to create payment
        return redirect()->route('mobile.delivery.payments.create', $order)
            ->with('info', 'Please create payment for order #' . $order->order_number);
    }

    private function handleReturnedStatus($order, $user, $notes = null)
    {
        // Redirect to return items page
        return redirect()->route('mobile.delivery.orders.return', $order)
            ->with('info', 'Please select items to return for order #' . $order->order_number);
    }

    public function returnItems(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to return items.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only return items from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->load(['customer', 'orderStatus', 'orderItems.product']);
        $returnReasons = ReturnReason::active()->get();
        
        // If it's an AJAX request, return JSON data
        if (request()->expectsJson()) {
            $items = $order->orderItems->map(function ($item) {
                return [
                    'id' => $item->id,
                    'product_name' => $item->product->name ?? 'Неизвестный товар',
                    'product_sku' => $item->product->sku ?? null,
                    'quantity' => $item->quantity,
                    'unit_price' => number_format($item->unit_price, 0, ',', ' '),
                    'return_qty' => $item->return_qty ?? 0,
                ];
            });
            
            return response()->json([
                'success' => true,
                'items' => $items,
                'return_reasons' => $returnReasons->map(function ($reason) {
                    return [
                        'id' => $reason->id,
                        'name' => $reason->name,
                    ];
                }),
            ]);
        }
        
        return view('mobile.delivery.orders.return', compact('order', 'returnReasons'));
    }

    public function processReturn(Request $request, Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to process returns.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only process returns from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $request->validate([
            'items' => 'required|array',
            'items.*.return_qty' => 'required|integer|min:0',
            'items.*.return_reason_id' => 'required|exists:return_reasons,id',
            'items.*.return_notes' => 'nullable|string|max:500',
            'notes' => 'nullable|string|max:500',
        ]);
        
        $hasReturns = false;
        
        DB::transaction(function () use ($request, $order, $user, &$hasReturns) {
            foreach ($request->items as $itemId => $returnData) {
                $returnQty = (int) $returnData['return_qty'];
                
                if ($returnQty > 0) {
                    $orderItem = OrderItem::find($itemId);
                    
                    if ($orderItem && $orderItem->order_id === $order->id) {
                        // Validate return quantity
                        if ($returnQty > ($orderItem->quantity - $orderItem->return_qty)) {
                            throw new \Exception("Return quantity for {$orderItem->product->name} exceeds available quantity.");
                        }
                        
                        // Update order item with return information
                        $orderItem->update([
                            'return_qty' => $orderItem->return_qty + $returnQty,
                            'return_reason_id' => $returnData['return_reason_id'],
                            'return_notes' => $returnData['return_notes'],
                        ]);
                        
                        // Return stock to inventory
                        $orderItem->product->updateStock($returnQty, 'return', $user->id);
                        
                        $hasReturns = true;
                    }
                }
            }
            
            if ($hasReturns) {
                // Update order status to returned
                $returnedStatus = OrderStatus::where('name', 'returned')->first();
                if ($returnedStatus) {
                    $order->update([
                        'order_status_id' => $returnedStatus->id,
                        'delivery_user_id' => $user->id,
                    ]);
                    
                    // Add status history
                    $order->orderStatusHistory()->create([
                        'order_status_id' => $returnedStatus->id,
                        'notes' => $request->notes,
                        'changed_by' => $user->id,
                    ]);
                }
            }
        });
        
        if (!$hasReturns) {
            return redirect()->back()->with('error', 'No items were selected for return.');
        }
        
        return redirect()->route('mobile.delivery.orders.index')
            ->with('success', 'Items returned successfully for order #' . $order->order_number);
    }

    public function startDelivery(Request $request, Order $order)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to start delivery.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure delivery user can only start deliveries from their tenant
        if ($order->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        // Check if order is in loaded status
        if ($order->orderStatus->name !== 'loaded') {
            return redirect()->back()->with('error', 'Order must be loaded before starting delivery.');
        }
        
        // Assign delivery user to order
        $order->update([
            'delivery_user_id' => $user->id,
        ]);
        
        return redirect()->route('mobile.delivery.orders.show', $order)
            ->with('success', 'Delivery started for order #' . $order->order_number);
    }
    /**
     */
    public function createCommitment(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create commitment.');
        }
        
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'amount' => 'required|numeric|min:0.01',
            'due_date' => 'required|date|after:today',
            'notes' => 'nullable|string|max:500',
        ]);
        
        $order = Order::where('tenant_id', $user->tenant_id)->findOrFail($request->order_id);
        
        // Create commitment
        $commitment = \App\Models\Commitment::create([
            'tenant_id' => $user->tenant_id,
            'order_id' => $order->id,
            'customer_id' => $order->customer_id,
            'amount' => $request->amount,
            'paid_amount' => 0,
            'remaining_amount' => $request->amount,
            'due_date' => $request->due_date,
            'notes' => $request->notes,
            'created_by' => $user->id,
        ]);
        
        // Update order status to delivered
        $deliveredStatus = OrderStatus::where('name', 'delivered')->first();
        if ($deliveredStatus) {
            $order->update([
                'order_status_id' => $deliveredStatus->id,
                'delivery_user_id' => $user->id,
                'delivery_date' => now(),
            ]);
            
            // Add status history
            $order->orderStatusHistory()->create([
                'order_status_id' => $deliveredStatus->id,
                'notes' => 'Order delivered with commitment created',
                'changed_by' => $user->id,
            ]);
        }
        
        return redirect()->route('mobile.delivery.orders.index')
            ->with('success', 'Order delivered and commitment created successfully!');
    }
    
    /**
     * Handle payments form submission from modal
     */
    public function createPayment(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create payment.');
        }
        
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'amount' => 'required|numeric|min:0.01',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'notes' => 'nullable|string|max:500',
        ]);
        
        $order = Order::where('tenant_id', $user->tenant_id)->findOrFail($request->order_id);
        
        // Get paid status
        $paidStatus = \App\Models\PaymentStatus::where('name', 'paid')->first();
        if (!$paidStatus) {
            return redirect()->back()->with('error', 'System error: Paid status not found. Contact administrator.');
        }
        
        // Create payment
        $payment = \App\Models\Payment::create([
            'tenant_id' => $user->tenant_id,
            'order_id' => $order->id,
            'amount' => $request->amount,
            'payment_method_id' => $request->payment_method_id,
            'payment_status_id' => $paidStatus->id,
            'payment_date' => now(),
            'notes' => $request->notes,
            'created_by' => $user->id,
        ]);
        
        // Update order status to paid
        $paidStatus = OrderStatus::where('name', 'paid')->first();
        if ($paidStatus) {
            $order->update([
                'order_status_id' => $paidStatus->id,
                'delivery_user_id' => $user->id,
            ]);
            
            // Add status history
            $order->orderStatusHistory()->create([
                'order_status_id' => $paidStatus->id,
                'notes' => 'Order paid via delivery',
                'changed_by' => $user->id,
            ]);
        }
        
        return redirect()->route('mobile.delivery.orders.index')
            ->with('success', 'Payment created and order marked as paid successfully!');
    }
    
    /**
     * Handle return items form submission from modal
     */
    public function processReturnItems(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return response()->json(['success' => false, 'message' => 'Please login to process returns.'], 401);
        }
        
        if ($user->role !== 'delivery') {
            return response()->json(['success' => false, 'message' => 'Access denied. Delivery role required.'], 403);
        }
        
        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'return_reason_id' => 'required|exists:return_reasons,id',
            'return_items' => 'required|array',
            'return_items.*.return_quantity' => 'required|integer|min:0',
        ]);
        
        $order = Order::where('tenant_id', $user->tenant_id)->findOrFail($request->order_id);
        
        $hasReturns = false;
        $returnReasonId = $request->return_reason_id;
        
        // Process return items
        foreach ($request->return_items as $itemId => $returnItem) {
            // Skip if no return quantity
            if (empty($returnItem['return_quantity']) || $returnItem['return_quantity'] <= 0) {
                continue;
            }
            
            $orderItem = \App\Models\OrderItem::find($itemId);
            if (!$orderItem || $orderItem->order_id != $order->id) {
                continue;
            }
            
            // Update order item with return information (using the same return reason for all items)
            $orderItem->update([
                'return_qty' => ($orderItem->return_qty ?? 0) + $returnItem['return_quantity'],
                'return_reason_id' => $returnReasonId,
                'return_notes' => 'Returned by delivery user'
            ]);
            
            // Return stock to inventory
            $orderItem->product->updateStock($returnItem['return_quantity'], 'return', $user->id);
            
            $hasReturns = true;
        }
        
        if ($hasReturns) {
            // Update order status to returned
            $returnedStatus = OrderStatus::where('name', 'returned')->first();
            if ($returnedStatus) {
                $order->update([
                    'order_status_id' => $returnedStatus->id,
                    'delivery_user_id' => $user->id,
                ]);
                
                // Add status history
                $order->orderStatusHistory()->create([
                    'order_status_id' => $returnedStatus->id,
                    'notes' => 'Order items returned',
                    'changed_by' => $user->id,
                ]);
            }
        }
        
        return response()->json(['success' => true, 'message' => 'Return processed successfully!']);
    }
}
