<?php

namespace App\Http\Controllers\Mobile\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Commitment;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access the delivery dashboard.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Delivery-specific statistics
        $stats = [
            'orders_to_deliver' => Order::where('tenant_id', $tenantId)
                ->where('delivery_user_id', $user->id) // Only orders assigned to this delivery user
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'loaded');
                })
                ->count(),
            'in_transit' => Order::where('tenant_id', $tenantId)
                ->where('delivery_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'loaded');
                })
                ->count(),
            'today_delivered' => Order::where('tenant_id', $tenantId)
                ->where('delivery_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'delivered');
                })
                ->whereDate('delivery_date', Carbon::today())
                ->count(),
            'total_deliveries' => Order::where('tenant_id', $tenantId)
                ->where('delivery_user_id', $user->id)
                ->whereHas('orderStatus', function ($q) {
                    $q->where('name', 'delivered');
                })
                ->count(),
            'pending_commitments' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->count(),
            'today_payments' => Payment::where('tenant_id', $tenantId)
                ->where('created_by', $user->id)
                ->whereDate('payment_date', Carbon::today())
                ->sum('amount'),
        ];

        // Orders to deliver with eager loading - only assigned to this delivery user
        $ordersToDeliver = Order::with(['customer', 'orderStatus', 'orderItems.product'])
            ->where('tenant_id', $tenantId)
            ->where('delivery_user_id', $user->id) // Only orders assigned to this delivery user
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'loaded');
            })
            ->latest()
            ->limit(5)
            ->get();

        // My deliveries in transit with eager loading
        $myInTransit = Order::with(['customer', 'orderStatus'])
            ->where('tenant_id', $tenantId)
            ->where('delivery_user_id', $user->id)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'loaded');
            })
            ->latest()
            ->limit(5)
            ->get();

        // Today's deliveries with eager loading
        $todayDeliveries = Order::with(['customer', 'orderStatus'])
            ->where('tenant_id', $tenantId)
            ->where('delivery_user_id', $user->id)
            ->whereHas('orderStatus', function ($q) {
                $q->where('name', 'delivered');
            })
            ->whereDate('delivery_date', Carbon::today())
            ->latest()
            ->limit(5)
            ->get();

        // Recent customers with pending commitments with eager loading
        $debtors = Customer::with(['commitments' => function ($q) {
                $q->where('status', 'active')->orderBy('due_date', 'asc');
            }])
            ->where('tenant_id', $tenantId)
            ->whereHas('commitments', function ($q) {
                $q->where('status', 'active');
            })
            ->limit(5)
            ->get();

        // Recent payments collected with eager loading
        $recentPayments = Payment::with(['order.customer', 'paymentMethod'])
            ->where('tenant_id', $tenantId)
            ->where('created_by', $user->id)
            ->latest()
            ->limit(5)
            ->get();

        return view('mobile.delivery.dashboard', compact(
            'stats',
            'ordersToDeliver',
            'myInTransit',
            'todayDeliveries',
            'debtors',
            'recentPayments'
        ));
    }
} 