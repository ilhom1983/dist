<?php

namespace App\Http\Controllers\Mobile\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Order;
use App\Models\PaymentMethod;
use App\Models\PaymentStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access payments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get payments collected by this delivery user
        $payments = Payment::with(['order.customer', 'paymentMethod', 'paymentStatus'])
            ->where('tenant_id', $tenantId)
            ->where('created_by', $user->id)
            ->latest()
            ->paginate(20);

        // Calculate statistics
        $stats = [
            'total_collected' => Payment::where('tenant_id', $tenantId)
                ->where('created_by', $user->id)
                ->sum('amount'),
            'today_collected' => Payment::where('tenant_id', $tenantId)
                ->where('created_by', $user->id)
                ->whereDate('payment_date', now()->toDateString())
                ->sum('amount'),
            'total_payments' => Payment::where('tenant_id', $tenantId)
                ->where('created_by', $user->id)
                ->count(),
            'today_payments' => Payment::where('tenant_id', $tenantId)
                ->where('created_by', $user->id)
                ->whereDate('payment_date', now()->toDateString())
                ->count(),
        ];

        return view('mobile.delivery.payments.index', compact('payments', 'stats'));
    }

    public function create(Order $order = null)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create payments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // If order is specified, ensure it belongs to the tenant
        if ($order && $order->tenant_id !== $tenantId) {
            abort(403, 'Unauthorized access to order.');
        }

        $paymentMethods = PaymentMethod::active()->get();
        
        // If no order specified, get orders with remaining amounts
        $orders = null;
        if (!$order) {
            $orders = Order::with(['customer'])
                ->where('tenant_id', $tenantId)
                ->where('remaining_amount', '>', 0)
                ->latest()
                ->limit(20)
                ->get();
        }

        return view('mobile.delivery.payments.create', compact('order', 'orders', 'paymentMethods'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create payments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'amount' => 'required|numeric|min:0.01',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'notes' => 'nullable|string|max:500',
        ]);

        $order = Order::findOrFail($request->order_id);
        
        // Ensure order belongs to the tenant
        if ($order->tenant_id !== $tenantId) {
            abort(403, 'Unauthorized access to order.');
        }

        // Validate payment amount
        if ($request->amount > $order->remaining_amount) {
            return redirect()->back()->with('error', 'Payment amount cannot exceed remaining amount.');
        }

        // Get paid status
        $paidStatus = PaymentStatus::where('name', 'paid')->first();
        if (!$paidStatus) {
            return redirect()->back()->with('error', 'System error: Paid status not found. Contact administrator.');
        }

        DB::transaction(function () use ($request, $order, $user, $paidStatus) {
            // Create payment
            $payment = Payment::create([
                'tenant_id' => $user->tenant_id,
                'order_id' => $order->id,
                'amount' => $request->amount,
                'payment_method_id' => $request->payment_method_id,
                'payment_status_id' => $paidStatus->id,
                'payment_date' => now(),
                'notes' => $request->notes,
                'created_by' => $user->id,
            ]);

            // Update order payment amounts
            $order->paid_amount += $request->amount;
            $order->remaining_amount = max(0, $order->total_amount - $order->paid_amount);
            $order->save();

            // If fully paid, update payment status and assign delivery user
            if ($order->remaining_amount <= 0) {
                $order->updatePaymentStatus('paid');
                // Assign delivery user when order becomes fully paid
                $order->update(['delivery_user_id' => $user->id]);
            }
        });

        return redirect()->route('mobile.delivery.payments.index')
            ->with('success', 'Payment of ' . number_format($request->amount, 0, ',', ' ') . ' ₽ collected successfully!');
    }

    public function show(Payment $payment)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view payment details.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure payment belongs to the tenant
        if ($payment->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to payment.');
        }
        
        $payment->load(['order.customer', 'paymentMethod', 'paymentStatus', 'createdBy']);
        
        return view('mobile.delivery.payments.show', compact('payment'));
    }
} 