<?php

namespace App\Http\Controllers\Mobile\Delivery;

use App\Http\Controllers\Controller;
use App\Models\Commitment;
use App\Models\Order;
use Illuminate\Http\Request;

class CommitmentController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access commitments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // Get active commitments
        $commitments = Commitment::with(['customer', 'order', 'createdBy'])
            ->where('tenant_id', $tenantId)
            ->where('status', 'active')
            ->orderBy('due_date', 'asc')
            ->paginate(20);

        // Calculate statistics
        $stats = [
            'total_commitments' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->count(),
            'total_amount' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->sum('remaining_amount'),
            'overdue_commitments' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('due_date', '<', now()->toDateString())
                ->count(),
            'today_due' => Commitment::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('due_date', now()->toDateString())
                ->count(),
        ];

        return view('mobile.delivery.commitments.index', compact('commitments', 'stats'));
    }

    public function create(Order $order = null)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create commitments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        // If order is specified, ensure it belongs to the tenant
        if ($order && $order->tenant_id !== $tenantId) {
            abort(403, 'Unauthorized access to order.');
        }

        // If no order specified, get orders with remaining amounts
        $orders = null;
        if (!$order) {
            $orders = Order::with(['customer'])
                ->where('tenant_id', $tenantId)
                ->where('remaining_amount', '>', 0)
                ->latest()
                ->limit(20)
                ->get();
        }

        return view('mobile.delivery.commitments.create', compact('order', 'orders'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to create commitments.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        $tenantId = $user->tenant_id;

        $request->validate([
            'order_id' => 'required|exists:orders,id',
            'amount' => 'required|numeric|min:0.01',
            'due_date' => 'required|date|after_or_equal:today',
            'notes' => 'nullable|string|max:500',
        ]);

        $order = Order::findOrFail($request->order_id);
        
        // Ensure order belongs to the tenant
        if ($order->tenant_id !== $tenantId) {
            abort(403, 'Unauthorized access to order.');
        }

        // Validate commitment amount
        if ($request->amount > $order->remaining_amount) {
            return redirect()->back()->with('error', 'Commitment amount cannot exceed remaining amount.');
        }

        // Create commitment
        Commitment::create([
            'tenant_id' => $tenantId,
            'customer_id' => $order->customer_id,
            'order_id' => $order->id,
            'amount' => $request->amount,
            'paid_amount' => 0,
            'remaining_amount' => $request->amount,
            'due_date' => $request->due_date,
            'status' => 'active',
            'notes' => $request->notes,
            'created_by' => $user->id,
        ]);

        return redirect()->route('mobile.delivery.commitments.index')
            ->with('success', 'Commitment created successfully for ' . number_format($request->amount, 0, ',', ' ') . ' ₽');
    }

    public function show(Commitment $commitment)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to view commitment details.');
        }
        
        // Check if user has delivery role
        if ($user->role !== 'delivery') {
            return redirect()->route('dashboard')->with('error', 'Access denied. Delivery role required.');
        }
        
        // Ensure commitment belongs to the tenant
        if ($commitment->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized access to commitment.');
        }
        
        $commitment->load(['customer', 'order', 'createdBy']);
        
        return view('mobile.delivery.commitments.show', compact('commitment'));
    }
} 