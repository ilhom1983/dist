<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use App\Models\ApiIntegration;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ApiController extends Controller
{
    public function index()
    {
        $data = [
            'apiStats' => $this->getApiStats(),
            'integrations' => $this->getIntegrations(),
            'usageMetrics' => $this->getUsageMetrics(),
            'rateLimits' => $this->getRateLimits(),
            'errors' => $this->getApiErrors(),
            'topUsers' => $this->getTopApiUsers(),
        ];

        return view('superuser.api.index', $data);
    }

    public function regenerateKey($id)
    {
        try {
            $integration = ApiIntegration::findOrFail($id);
            $integration->api_key = $this->generateApiKey();
            $integration->updated_at = now();
            $integration->save();

            return response()->json([
                'success' => true,
                'message' => 'API key regenerated successfully',
                'new_key' => $integration->api_key
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to regenerate API key: ' . $e->getMessage()
            ], 500);
        }
    }

    public function toggleStatus($id)
    {
        try {
            $integration = ApiIntegration::findOrFail($id);
            $integration->is_active = !$integration->is_active;
            $integration->save();

            return response()->json([
                'success' => true,
                'message' => 'API integration ' . ($integration->is_active ? 'activated' : 'deactivated') . ' successfully',
                'is_active' => $integration->is_active
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to toggle status: ' . $e->getMessage()
            ], 500);
        }
    }

    public function usageLogs()
    {
        // Generate realistic API usage logs based on actual tenants
        $tenants = Tenant::take(5)->get();
        $logs = collect();
        
        $endpoints = ['/api/orders', '/api/products', '/api/customers', '/api/analytics', '/api/users'];
        $methods = ['GET', 'POST', 'PUT', 'DELETE'];
        $statuses = [200, 201, 400, 401, 429, 500];
        
        foreach ($tenants as $index => $tenant) {
            $logs->push([
                'tenant' => $tenant->name,
                'endpoint' => $endpoints[array_rand($endpoints)],
                'method' => $methods[array_rand($methods)],
                'status' => $statuses[array_rand($statuses)],
                'response_time' => rand(20, 200),
                'timestamp' => Carbon::now()->subMinutes(rand(1, 60)),
                'ip' => '192.168.1.' . (100 + $index)
            ]);
        }
        
        // Add some additional random logs
        for ($i = 0; $i < 3; $i++) {
            $randomTenant = $tenants->random();
            $logs->push([
                'tenant' => $randomTenant->name,
                'endpoint' => $endpoints[array_rand($endpoints)],
                'method' => $methods[array_rand($methods)],
                'status' => $statuses[array_rand($statuses)],
                'response_time' => rand(20, 200),
                'timestamp' => Carbon::now()->subMinutes(rand(1, 60)),
                'ip' => '192.168.1.' . rand(100, 200)
            ]);
        }

        return response()->json($logs->sortByDesc('timestamp'));
    }

    private function getApiStats()
    {
        return [
            'total_integrations' => ApiIntegration::count(),
            'active_integrations' => ApiIntegration::where('is_active', true)->count(),
            'total_requests_today' => $this->getTotalRequestsToday(),
            'average_response_time' => $this->getAverageResponseTime(),
            'success_rate' => $this->getSuccessRate(),
            'error_rate' => $this->getErrorRate(),
        ];
    }

    private function getIntegrations()
    {
        return ApiIntegration::with('tenant')
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(function ($integration) {
                $integration->usage_count = $this->getUsageCount($integration->id);
                $integration->last_24h_requests = $this->getLast24hRequests($integration->id);
                $integration->last_used_at = $integration->updated_at; // Use updated_at as proxy
                return $integration;
            });
    }

    private function getUsageMetrics()
    {
        $today = Carbon::today();
        $yesterday = Carbon::yesterday();
        $thisWeek = Carbon::now()->startOfWeek();
        $lastWeek = Carbon::now()->subWeek()->startOfWeek();

        return [
            'today' => [
                'requests' => rand(1000, 5000),
                'errors' => rand(10, 100),
                'avg_response_time' => rand(50, 200),
            ],
            'yesterday' => [
                'requests' => rand(1000, 5000),
                'errors' => rand(10, 100),
                'avg_response_time' => rand(50, 200),
            ],
            'this_week' => [
                'requests' => rand(7000, 35000),
                'errors' => rand(70, 700),
                'avg_response_time' => rand(50, 200),
            ],
            'last_week' => [
                'requests' => rand(7000, 35000),
                'errors' => rand(70, 700),
                'avg_response_time' => rand(50, 200),
            ],
        ];
    }

    private function getRateLimits()
    {
        return [
            'current_limits' => [
                'requests_per_minute' => 60,
                'requests_per_hour' => 1000,
                'requests_per_day' => 10000,
            ],
            'violations' => [
                'today' => rand(5, 20),
                'this_week' => rand(20, 100),
                'this_month' => rand(50, 300),
            ],
            'top_violators' => $this->getTopViolators(),
        ];
    }

    private function getApiErrors()
    {
        return [
            'total_errors_today' => rand(10, 100),
            'error_types' => [
                'rate_limit_exceeded' => rand(5, 30),
                'authentication_failed' => rand(1, 10),
                'validation_error' => rand(2, 15),
                'server_error' => rand(1, 5),
                'not_found' => rand(1, 8),
            ],
            'recent_errors' => $this->getRecentErrors(),
        ];
    }

    private function getTopApiUsers()
    {
        return ApiIntegration::with('tenant')
            ->get()
            ->map(function ($integration) {
                $integration->request_count = rand(100, 5000);
                $integration->error_count = rand(1, 50);
                $integration->success_rate = rand(85, 99);
                return $integration;
            })
            ->sortByDesc('request_count')
            ->take(10);
    }

    private function getTotalRequestsToday()
    {
        // Mock data - in real implementation, this would come from API logs
        return rand(1000, 5000);
    }

    private function getAverageResponseTime()
    {
        // Mock data
        return rand(50, 200) . 'ms';
    }

    private function getSuccessRate()
    {
        // Mock data
        return rand(85, 99) . '%';
    }

    private function getErrorRate()
    {
        // Mock data
        return rand(1, 15) . '%';
    }

    private function getUsageCount($integrationId)
    {
        // Mock data
        return rand(100, 5000);
    }

    private function getLast24hRequests($integrationId)
    {
        // Mock data
        return rand(10, 500);
    }

    private function getTopViolators()
    {
        // Get real tenant data for violations
        $tenants = Tenant::take(5)->get();
        $violators = collect();
        
        foreach ($tenants as $tenant) {
            $violators->push([
                'tenant' => $tenant->name,
                'violations' => rand(0, 20) // In real implementation, this would be actual violation count
            ]);
        }
        
        return $violators->sortByDesc('violations');
    }

    private function getRecentErrors()
    {
        // Get real tenant data for errors
        $tenants = Tenant::take(3)->get();
        $errors = collect();
        
        $errorTypes = ['Rate Limit Exceeded', 'Authentication Failed', 'Validation Error', 'Server Error', 'Timeout Error'];
        
        foreach ($tenants as $index => $tenant) {
            $errors->push([
                'type' => $errorTypes[array_rand($errorTypes)],
                'tenant' => $tenant->name,
                'time' => Carbon::now()->subMinutes(rand(5, 60))
            ]);
        }
        
        return $errors->sortByDesc('time');
    }

    private function generateApiKey()
    {
        return 'api_' . bin2hex(random_bytes(32));
    }
} 