<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class SystemController extends Controller
{
    public function index()
    {
        $data = [
            'systemInfo' => $this->getSystemInfo(),
            'databaseStats' => $this->getDatabaseStats(),
            'storageInfo' => $this->getStorageInfo(),
            'performanceMetrics' => $this->getPerformanceMetrics(),
            'backupStatus' => $this->getBackupStatus(),
            'logFiles' => $this->getLogFiles(),
        ];

        return view('superuser.system.index', $data);
    }

    public function backup()
    {
        try {
            // Create backup filename
            $filename = 'backup_' . Carbon::now()->format('Y-m-d_H-i-s') . '.sql';
            
            // Generate database backup command
            $command = sprintf(
                'mysqldump -u%s -p%s %s > %s',
                config('database.connections.mysql.username'),
                config('database.connections.mysql.password'),
                config('database.connections.mysql.database'),
                storage_path('app/backups/' . $filename)
            );

            // Execute backup
            exec($command, $output, $returnCode);

            if ($returnCode === 0) {
                return response()->json([
                    'success' => true,
                    'message' => 'Backup created successfully',
                    'filename' => $filename
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Backup failed'
                ], 500);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Backup error: ' . $e->getMessage()
            ], 500);
        }
    }

    public function logs($filename = null)
    {
        if ($filename) {
            $logPath = storage_path('logs/' . $filename);
            if (file_exists($logPath)) {
                $content = file_get_contents($logPath);
                return response()->json(['content' => $content]);
            }
            return response()->json(['error' => 'Log file not found'], 404);
        }

        $logs = $this->getLogFiles();
        return response()->json($logs);
    }

    public function clearCache()
    {
        try {
            \Artisan::call('cache:clear');
            \Artisan::call('config:clear');
            \Artisan::call('view:clear');
            \Artisan::call('route:clear');

            return response()->json([
                'success' => true,
                'message' => 'Cache cleared successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Cache clear error: ' . $e->getMessage()
            ], 500);
        }
    }

    public function optimize()
    {
        try {
            \Artisan::call('config:cache');
            \Artisan::call('route:cache');
            \Artisan::call('view:cache');

            return response()->json([
                'success' => true,
                'message' => 'System optimized successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Optimization error: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getSystemInfo()
    {
        return [
            'php_version' => PHP_VERSION,
            'laravel_version' => app()->version(),
            'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'os' => php_uname(),
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'),
        ];
    }

    private function getDatabaseStats()
    {
        $tables = DB::select('SHOW TABLE STATUS');
        $totalSize = 0;
        $totalRows = 0;

        foreach ($tables as $table) {
            $totalSize += $table->Data_length + $table->Index_length;
            $totalRows += $table->Rows;
        }

        return [
            'total_tables' => count($tables),
            'total_size' => $this->formatBytes($totalSize),
            'total_rows' => number_format($totalRows),
            'largest_tables' => collect($tables)
                ->sortByDesc('Data_length')
                ->take(5)
                ->map(function ($table) {
                    return [
                        'name' => $table->Name,
                        'size' => $this->formatBytes($table->Data_length + $table->Index_length),
                        'rows' => number_format($table->Rows),
                    ];
                }),
        ];
    }

    private function getStorageInfo()
    {
        $disk = Storage::disk('local');
        $totalSpace = disk_total_space(storage_path());
        $freeSpace = disk_free_space(storage_path());
        $usedSpace = $totalSpace - $freeSpace;

        return [
            'total_space' => $this->formatBytes($totalSpace),
            'used_space' => $this->formatBytes($usedSpace),
            'free_space' => $this->formatBytes($freeSpace),
            'usage_percentage' => round(($usedSpace / $totalSpace) * 100, 2),
        ];
    }

    private function getPerformanceMetrics()
    {
        return [
            'average_query_time' => $this->getAverageQueryTime(),
            'slow_queries' => $this->getSlowQueries(),
            'cache_hit_rate' => $this->getCacheHitRate(),
            'memory_usage' => $this->getMemoryUsage(),
        ];
    }

    private function getBackupStatus()
    {
        $backupDir = storage_path('app/backups');
        $backups = [];

        if (is_dir($backupDir)) {
            $files = glob($backupDir . '/*.sql');
            foreach ($files as $file) {
                $backups[] = [
                    'filename' => basename($file),
                    'size' => $this->formatBytes(filesize($file)),
                    'created_at' => Carbon::createFromTimestamp(filemtime($file)),
                ];
            }
        }

        return [
            'total_backups' => count($backups),
            'latest_backup' => count($backups) > 0 ? $backups[0] : null,
            'backups' => collect($backups)->sortByDesc('created_at')->take(10),
        ];
    }

    private function getLogFiles()
    {
        $logDir = storage_path('logs');
        $logs = [];

        if (is_dir($logDir)) {
            $files = glob($logDir . '/*.log');
            foreach ($files as $file) {
                $logs[] = [
                    'filename' => basename($file),
                    'size' => $this->formatBytes(filesize($file)),
                    'modified' => Carbon::createFromTimestamp(filemtime($file)),
                ];
            }
        }

        return collect($logs)->sortByDesc('modified');
    }

    private function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }

        return round($bytes, $precision) . ' ' . $units[$i];
    }

    private function getAverageQueryTime()
    {
        // Mock data - in real implementation, this would come from query logs
        return rand(10, 50) . 'ms';
    }

    private function getSlowQueries()
    {
        // Mock data
        return rand(0, 5);
    }

    private function getCacheHitRate()
    {
        // Mock data
        return rand(85, 98) . '%';
    }

    private function getMemoryUsage()
    {
        $memory = memory_get_usage(true);
        $peak = memory_get_peak_usage(true);
        
        return [
            'current' => $this->formatBytes($memory),
            'peak' => $this->formatBytes($peak),
            'limit' => ini_get('memory_limit'),
        ];
    }
} 