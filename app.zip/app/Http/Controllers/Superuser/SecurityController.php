<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SecurityController extends Controller
{
    public function index()
    {
        $data = [
            'securityStats' => $this->getSecurityStats(),
            'failedLogins' => $this->getFailedLogins(),
            'suspiciousActivities' => $this->getSuspiciousActivities(),
            'firewallEvents' => $this->getFirewallEvents(),
            'sslCertificates' => $this->getSslCertificates(),
            'dataBreaches' => $this->getDataBreaches(),
            'securityAlerts' => $this->getSecurityAlerts(),
        ];

        return view('superuser.security.index', $data);
    }

    public function blockIp($ip)
    {
        try {
            // In a real implementation, this would add the IP to a firewall block list
            // For now, we'll just return a success response
            return response()->json([
                'success' => true,
                'message' => "IP address {$ip} has been blocked",
                'ip' => $ip
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to block IP: ' . $e->getMessage()
            ], 500);
        }
    }

    public function unblockIp($ip)
    {
        try {
            // In a real implementation, this would remove the IP from the firewall block list
            return response()->json([
                'success' => true,
                'message' => "IP address {$ip} has been unblocked",
                'ip' => $ip
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to unblock IP: ' . $e->getMessage()
            ], 500);
        }
    }

    public function securityLogs()
    {
        // Mock security logs - in real implementation, this would come from security monitoring system
        $logs = collect([
            [
                'type' => 'failed_login',
                'ip' => '192.168.1.100',
                'user' => 'admin@techcorp.com',
                'timestamp' => Carbon::now()->subMinutes(5),
                'details' => 'Invalid password attempt',
                'severity' => 'medium'
            ],
            [
                'type' => 'suspicious_activity',
                'ip' => '192.168.1.101',
                'user' => 'user@retailstore.com',
                'timestamp' => Carbon::now()->subMinutes(15),
                'details' => 'Multiple failed login attempts',
                'severity' => 'high'
            ],
            [
                'type' => 'api_abuse',
                'ip' => '192.168.1.102',
                'user' => 'api_user@ecommercehub.com',
                'timestamp' => Carbon::now()->subMinutes(30),
                'details' => 'Rate limit exceeded',
                'severity' => 'medium'
            ],
            [
                'type' => 'data_access',
                'ip' => '192.168.1.103',
                'user' => 'admin@techcorp.com',
                'timestamp' => Carbon::now()->subHours(1),
                'details' => 'Bulk data export',
                'severity' => 'low'
            ],
            [
                'type' => 'firewall_block',
                'ip' => '192.168.1.104',
                'user' => null,
                'timestamp' => Carbon::now()->subHours(2),
                'details' => 'Suspicious traffic pattern',
                'severity' => 'high'
            ],
        ]);

        return response()->json($logs);
    }

    private function getSecurityStats()
    {
        return [
            'failed_logins_today' => rand(10, 50),
            'suspicious_activities' => rand(3, 15),
            'blocked_ips' => rand(5, 25),
            'security_alerts' => rand(1, 10),
            'ssl_certificates_expiring' => rand(0, 5),
            'data_breaches' => 0, // Hopefully always 0
            'firewall_events' => rand(20, 100),
            'api_abuse_attempts' => rand(5, 30),
        ];
    }

    private function getFailedLogins()
    {
        // Generate realistic failed login data based on actual tenants
        $tenants = Tenant::take(3)->get();
        $failedLogins = collect();
        
        $locations = ['New York, US', 'London, UK', 'Tokyo, Japan', 'Berlin, Germany', 'Sydney, Australia'];
        $userAgents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15'
        ];
        
        foreach ($tenants as $index => $tenant) {
            $failedLogins->push([
                'ip' => '192.168.1.' . (100 + $index),
                'user' => 'admin@' . strtolower(str_replace(' ', '', $tenant->name)) . '.com',
                'attempts' => rand(3, 10),
                'last_attempt' => Carbon::now()->subMinutes(rand(1, 60)),
                'location' => $locations[array_rand($locations)],
                'user_agent' => $userAgents[array_rand($userAgents)],
            ]);
        }
        
        return $failedLogins->sortByDesc('last_attempt');
    }

    private function getSuspiciousActivities()
    {
        $tenants = Tenant::take(3)->get();
        $activities = collect();
        
        $activityTypes = [
            ['type' => 'multiple_failed_logins', 'details' => '10 failed login attempts in 5 minutes', 'severity' => 'high', 'action_taken' => 'IP temporarily blocked'],
            ['type' => 'unusual_api_usage', 'details' => 'API rate limit exceeded 15 times', 'severity' => 'medium', 'action_taken' => 'Rate limit warning sent'],
            ['type' => 'data_export_attempt', 'details' => 'Large data export request detected', 'severity' => 'low', 'action_taken' => 'Requires approval'],
            ['type' => 'suspicious_ip', 'details' => 'Login attempt from known malicious IP', 'severity' => 'high', 'action_taken' => 'IP blocked'],
            ['type' => 'unusual_activity_pattern', 'details' => 'Unusual user behavior detected', 'severity' => 'medium', 'action_taken' => 'Account flagged for review'],
        ];
        
        foreach ($tenants as $index => $tenant) {
            $activity = $activityTypes[array_rand($activityTypes)];
            $activities->push([
                'type' => $activity['type'],
                'ip' => '192.168.1.' . (100 + $index),
                'user' => 'admin@' . strtolower(str_replace(' ', '', $tenant->name)) . '.com',
                'timestamp' => Carbon::now()->subMinutes(rand(5, 120)),
                'details' => $activity['details'],
                'severity' => $activity['severity'],
                'action_taken' => $activity['action_taken'],
            ]);
        }
        
        return $activities->sortByDesc('timestamp');
    }

    private function getFirewallEvents()
    {
        return collect([
            [
                'ip' => '192.168.1.100',
                'event_type' => 'blocked',
                'timestamp' => Carbon::now()->subMinutes(rand(1, 60)),
                'reason' => 'Suspicious traffic pattern',
                'location' => 'New York, US',
            ],
            [
                'ip' => '192.168.1.101',
                'event_type' => 'blocked',
                'timestamp' => Carbon::now()->subMinutes(rand(1, 60)),
                'reason' => 'Multiple failed authentication attempts',
                'location' => 'London, UK',
            ],
            [
                'ip' => '192.168.1.102',
                'event_type' => 'allowed',
                'timestamp' => Carbon::now()->subMinutes(rand(1, 60)),
                'reason' => 'Legitimate traffic',
                'location' => 'Tokyo, Japan',
            ],
        ])->sortByDesc('timestamp');
    }

    private function getSslCertificates()
    {
        $tenants = Tenant::take(3)->get();
        $certificates = collect();
        
        $issuers = ['Let\'s Encrypt', 'DigiCert', 'Comodo', 'GlobalSign', 'GoDaddy'];
        
        foreach ($tenants as $tenant) {
            $expiresIn = rand(30, 365);
            $certificates->push([
                'domain' => $tenant->domain ?? strtolower(str_replace(' ', '', $tenant->name)) . '.com',
                'expires_at' => Carbon::now()->addDays($expiresIn),
                'status' => $expiresIn < 30 ? 'expiring_soon' : 'valid',
                'issuer' => $issuers[array_rand($issuers)],
            ]);
        }
        
        return $certificates->sortBy('expires_at');
    }

    private function getDataBreaches()
    {
        // Hopefully this is always empty in real implementation
        return collect([]);
    }

    private function getSecurityAlerts()
    {
        $tenants = Tenant::take(2)->get();
        $alerts = collect();
        
        // Generate alerts based on actual tenant data
        foreach ($tenants as $tenant) {
            $alerts->push([
                'type' => 'warning',
                'title' => 'High number of failed login attempts',
                'message' => "Multiple failed login attempts detected from IP 192.168.1." . rand(100, 200),
                'timestamp' => Carbon::now()->subMinutes(rand(10, 60)),
                'severity' => 'medium',
            ]);
        }
        
        // Add some system alerts
        $alerts->push([
            'type' => 'info',
            'title' => 'SSL certificate expiring soon',
            'message' => 'SSL certificate for ' . ($tenants->first()->domain ?? 'example.com') . ' expires in 15 days',
            'timestamp' => Carbon::now()->subHours(2),
            'severity' => 'low',
        ]);
        
        $alerts->push([
            'type' => 'success',
            'title' => 'Security scan completed',
            'message' => 'Automated security scan completed successfully',
            'timestamp' => Carbon::now()->subHours(4),
            'severity' => 'low',
        ]);
        
        return $alerts->sortByDesc('timestamp');
    }
} 