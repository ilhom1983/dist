<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use App\Models\Tenant;
use App\Models\TenantUser;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TenantUserController extends Controller
{
    public function index()
    {
        $users = TenantUser::with(['tenant'])
            ->latest()
            ->paginate(20);
        
        $tenants = Tenant::active()->get();

        return view('superuser.users.index', compact('users', 'tenants'));
    }

    public function create()
    {
        $tenants = Tenant::active()->get();
        $roles = UserRole::active()->get();

        return view('superuser.users.create', compact('tenants', 'roles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'tenant_id' => 'required|exists:tenants,id',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:tenant_users,email',
            'phone' => 'nullable|string|max:255',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|string|exists:user_roles,name',
        ]);

        TenantUser::create([
            'tenant_id' => $request->tenant_id,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'is_active' => true,
        ]);

        return redirect()->route('superuser.users.index')->with('success', 'User created successfully.');
    }

    public function show(TenantUser $user)
    {
        $user->load(['tenant']);
        return view('superuser.users.show', compact('user'));
    }

    public function edit(TenantUser $user)
    {
        $tenants = Tenant::active()->get();
        $roles = UserRole::active()->get();

        return view('superuser.users.edit', compact('user', 'tenants', 'roles'));
    }

    public function update(Request $request, TenantUser $user)
    {
        $request->validate([
            'tenant_id' => 'required|exists:tenants,id',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:tenant_users,email,' . $user->id,
            'phone' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|string|exists:user_roles,name',
            'is_active' => 'boolean',
        ]);

        $data = [
            'tenant_id' => $request->tenant_id,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'role' => $request->role,
            'is_active' => $request->has('is_active'),
        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $user->update($data);

        return redirect()->route('superuser.users.index')->with('success', 'User updated successfully.');
    }

    public function destroy(TenantUser $user)
    {
        $user->delete();

        return redirect()->route('superuser.users.index')->with('success', 'User deleted successfully.');
    }

    public function toggleStatus(TenantUser $user)
    {
        $user->update(['is_active' => !$user->is_active]);

        $status = $user->is_active ? 'activated' : 'deactivated';
        return redirect()->route('superuser.users.index')->with('success', "User {$status} successfully.");
    }
} 