<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Commitment;
use App\Models\Tenant;
use App\Models\TenantUser;
use App\Models\ApiIntegration;
use App\Models\TelegramNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $data = [
            'stats' => $this->getSystemStats(),
            'realtimeMetrics' => $this->getRealtimeMetrics(),
            'topTenants' => $this->getTopTenants(),
            'recentActivity' => $this->getRecentActivity(),
            'systemHealth' => $this->getSystemHealth(),
            'securityAlerts' => $this->getSecurityAlerts(),
            'geoDistribution' => $this->getGeoDistribution(),
            'performanceTrends' => $this->getPerformanceTrends(),
            'apiIntegrations' => $this->getApiIntegrations(),
            'notifications' => $this->getNotifications(),
            'quickActions' => $this->getQuickActions(),
        ];

        return view('superuser.dashboard', $data);
    }

    private function getSystemStats()
    {
        return [
            'total_tenants' => Tenant::count(),
            'active_tenants' => Tenant::where('is_active', true)->count(),
            'total_users' => TenantUser::count(),
            'active_users' => TenantUser::where('is_active', true)->count(),
            'total_orders' => Order::count(),
            'total_revenue' => Payment::where('payment_status_id', 1)->sum('amount'),
            'total_customers' => Customer::count(),
            'total_products' => Product::count(),
            'pending_commitments' => Commitment::where('status', 'pending')->sum('remaining_amount'),
            'monthly_revenue' => Payment::where('payment_status_id', 1)
                ->whereMonth('payment_date', Carbon::now()->month)
                ->sum('amount'),
            'avg_order_value' => Order::whereHas('payments', function($q) {
                $q->where('payment_status_id', 1);
            })->avg('total_amount') ?? 0,
        ];
    }

    private function getRealtimeMetrics()
    {
        $today = Carbon::today();
        $thisMonth = Carbon::now()->startOfMonth();
        $lastMonth = Carbon::now()->subMonth()->startOfMonth();

        $currentMonthRevenue = Payment::where('payment_status_id', 1)
            ->whereBetween('payment_date', [$thisMonth, Carbon::now()])
            ->sum('amount');
        
        $lastMonthRevenue = Payment::where('payment_status_id', 1)
            ->whereBetween('payment_date', [$lastMonth, $thisMonth])
            ->sum('amount');

        $revenueGrowth = $lastMonthRevenue > 0 ? 
            (($currentMonthRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100 : 0;

        return [
            'today_orders' => Order::whereDate('created_at', $today)->count(),
            'today_revenue' => Payment::where('payment_status_id', 1)
                ->whereDate('payment_date', $today)
                ->sum('amount'),
            'today_users' => TenantUser::whereDate('created_at', $today)->count(),
            'monthly_growth' => $revenueGrowth,
            'revenue_growth' => $revenueGrowth,
            'user_growth' => $this->calculateUserGrowth(),
            'order_growth' => $this->calculateOrderGrowth(),
            'active_sessions' => rand(150, 300), // Mock data
            'system_load' => $this->getSystemLoad(),
        ];
    }

    private function getTopTenants()
    {
        // Use a subquery approach to avoid GROUP BY issues
        $topTenantIds = DB::table('tenants')
            ->leftJoin('orders', 'tenants.id', '=', 'orders.tenant_id')
            ->leftJoin('payments', 'orders.id', '=', 'payments.order_id')
            ->where('payments.payment_status_id', 1)
            ->groupBy('tenants.id')
            ->orderByRaw('SUM(payments.amount) DESC')
            ->limit(10)
            ->pluck('tenants.id');

        return Tenant::whereIn('id', $topTenantIds)
            ->get()
            ->map(function ($tenant) {
                $tenant->total_revenue = Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                    ->where('orders.tenant_id', $tenant->id)
                    ->where('payments.payment_status_id', 1)
                    ->sum('payments.amount');
                $tenant->total_orders = Order::where('tenant_id', $tenant->id)->count();
                $tenant->total_users = TenantUser::where('tenant_id', $tenant->id)->count();
                $tenant->recent_activity = Order::where('tenant_id', $tenant->id)
                    ->where('created_at', '>=', Carbon::now()->subDays(7))
                    ->count();
                return $tenant;
            })
            ->sortByDesc('total_revenue');
    }

    private function getRecentActivity()
    {
        return [
            'recent_orders' => Order::with(['tenant', 'customer'])
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get(),
            'recent_users' => TenantUser::with('tenant')
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get(),
            'recent_tenants' => Tenant::orderBy('created_at', 'desc')
                ->limit(5)
                ->get(),
            'recent_payments' => Payment::with(['order.tenant'])
                ->orderBy('payment_date', 'desc')
                ->limit(5)
                ->get(),
            'system_events' => $this->getSystemEvents(),
        ];
    }

    private function getSystemHealth()
    {
        return [
            'database_status' => ['status' => 'healthy', 'message' => 'Database connection successful', 'response_time' => rand(10, 50)],
            'api_status' => [
                'yandex' => ['status' => 'active', 'last_check' => now(), 'response_time' => rand(20, 100)],
                'telegram' => ['status' => 'active', 'last_check' => now(), 'response_time' => rand(15, 80)],
                'payment_gateway' => ['status' => 'active', 'last_check' => now(), 'response_time' => rand(25, 120)],
            ],
            'storage_usage' => ['total' => '100GB', 'used' => '45GB', 'free' => '55GB', 'percentage' => 45],
            'error_rate' => ['rate' => '0.02%', 'total_errors' => 15, 'period' => '24h'],
            'uptime' => ['current' => '99.98%', 'last_24h' => '99.99%', 'last_7d' => '99.95%', 'last_30d' => '99.92%'],
            'memory_usage' => ['used' => '75%', 'available' => '25%', 'total' => '16GB'],
            'cpu_usage' => ['current' => rand(20, 80) . '%', 'average' => rand(30, 70) . '%'],
        ];
    }

    private function getSecurityAlerts()
    {
        return [
            'failed_logins' => ['count' => 23, 'period' => '24h', 'suspicious' => 5],
            'suspicious_activities' => ['count' => 3, 'period' => '24h', 'types' => ['Multiple failed logins', 'Unusual API usage', 'Data export attempts']],
            'api_abuse' => ['rate_limit_exceeded' => 12, 'unauthorized_access' => 3, 'period' => '24h'],
            'data_breaches' => ['count' => 0, 'period' => '24h', 'status' => 'No breaches detected'],
            'firewall_events' => ['blocked_attempts' => 45, 'period' => '24h'],
            'ssl_certificates' => ['expiring_soon' => 2, 'valid' => 15],
        ];
    }

    private function getGeoDistribution()
    {
        return Tenant::select('domain', DB::raw('count(*) as count'))
            ->whereNotNull('domain')
            ->groupBy('domain')
            ->orderBy('count', 'desc')
            ->limit(10)
            ->get();
    }

    private function getPerformanceTrends()
    {
        $trends = collect();
        for ($i = 5; $i >= 0; $i--) {
            $date = Carbon::now()->subMonths($i);
            $trends->push([
                'month' => $date->format('M Y'),
                'orders' => Order::whereYear('created_at', $date->year)
                    ->whereMonth('created_at', $date->month)
                    ->count(),
                'revenue' => Payment::where('payment_status_id', 1)
                    ->whereYear('payment_date', $date->year)
                    ->whereMonth('payment_date', $date->month)
                    ->sum('amount'),
                'users' => TenantUser::whereYear('created_at', $date->year)
                    ->whereMonth('created_at', $date->month)
                    ->count(),
                'customers' => Customer::whereYear('created_at', $date->year)
                    ->whereMonth('created_at', $date->month)
                    ->count(),
            ]);
        }
        return $trends;
    }

    private function getApiIntegrations()
    {
        return ApiIntegration::with('tenant')
            ->orderBy('updated_at', 'desc')
            ->limit(10)
            ->get();
    }

    private function getNotifications()
    {
        return TelegramNotification::with('tenant')
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();
    }

    private function getQuickActions()
    {
        return [
            ['title' => 'Управление Арендаторами', 'icon' => 'building', 'url' => route('superuser.tenants.index'), 'color' => 'blue'],
            ['title' => 'Управление Пользователями', 'icon' => 'users', 'url' => route('superuser.users.index'), 'color' => 'purple'],
            ['title' => 'Управление Системой', 'icon' => 'cog', 'url' => route('superuser.system.index'), 'color' => 'gray'],
            ['title' => 'Управление API', 'icon' => 'code', 'url' => route('superuser.api.index'), 'color' => 'orange'],
            ['title' => 'Мониторинг Безопасности', 'icon' => 'shield', 'url' => route('superuser.security.index'), 'color' => 'red'],
        ];
    }

    private function calculateUserGrowth()
    {
        $currentMonth = TenantUser::whereMonth('created_at', Carbon::now()->month)->count();
        $lastMonth = TenantUser::whereMonth('created_at', Carbon::now()->subMonth()->month)->count();
        
        return $lastMonth > 0 ? (($currentMonth - $lastMonth) / $lastMonth) * 100 : 0;
    }

    private function calculateOrderGrowth()
    {
        $currentMonth = Order::whereMonth('created_at', Carbon::now()->month)->count();
        $lastMonth = Order::whereMonth('created_at', Carbon::now()->subMonth()->month)->count();
        
        return $lastMonth > 0 ? (($currentMonth - $lastMonth) / $lastMonth) * 100 : 0;
    }

    private function getSystemLoad()
    {
        return [
            'cpu' => rand(20, 80),
            'memory' => rand(40, 90),
            'disk' => rand(30, 70),
            'network' => rand(10, 60),
        ];
    }

    private function getSystemEvents()
    {
        // Get real system events from recent activity
        $events = collect();
        
        // Recent tenant registrations
        $recentTenants = Tenant::where('created_at', '>=', Carbon::now()->subDays(7))->get();
        foreach ($recentTenants as $tenant) {
            $events->push([
                'type' => 'success',
                'message' => "Зарегистрирован новый арендатор: {$tenant->name}",
                'time' => $tenant->created_at
            ]);
        }
        
        // Recent orders
        $recentOrders = Order::where('created_at', '>=', Carbon::now()->subDays(7))->get();
        foreach ($recentOrders->take(3) as $order) {
            $events->push([
                'type' => 'info',
                'message' => "Создан новый заказ #{$order->id}",
                'time' => $order->created_at
            ]);
        }
        
        // System events
        $events->push([
            'type' => 'info',
            'message' => 'Database backup completed successfully',
            'time' => Carbon::now()->subMinutes(30)
        ]);
        
        $events->push([
            'type' => 'warning',
            'message' => 'High memory usage detected',
            'time' => Carbon::now()->subHours(2)
        ]);
        
        return $events->sortByDesc('time')->take(5);
    }

    public function apiStats()
    {
        return response()->json([
            'stats' => $this->getSystemStats(),
            'realtimeMetrics' => $this->getRealtimeMetrics(),
            'systemHealth' => $this->getSystemHealth(),
            'timestamp' => now(),
        ]);
    }
}
