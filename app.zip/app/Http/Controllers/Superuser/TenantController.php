<?php

namespace App\Http\Controllers\Superuser;

use App\Http\Controllers\Controller;
use App\Models\Tenant;
use Illuminate\Http\Request;

class TenantController extends Controller
{
    public function index()
    {
        $tenants = Tenant::withCount(['users', 'orders', 'customers', 'products'])
            ->latest()
            ->paginate(20);

        return view('superuser.tenants.index', compact('tenants'));
    }

    public function create()
    {
        return view('superuser.tenants.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'domain' => 'required|string|max:255|unique:tenants,domain',
            'company_name' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'phone' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
        ]);

        $settings = [
            'company_name' => $request->company_name,
            'address' => $request->address,
            'phone' => $request->phone,
            'email' => $request->email,
        ];

        Tenant::create([
            'name' => $request->name,
            'domain' => $request->domain,
            'settings' => $settings,
            'is_active' => true,
        ]);

        return redirect()->route('superuser.tenants.index')->with('success', 'Tenant created successfully.');
    }

    public function show(Tenant $tenant)
    {
        $tenant->load(['users', 'orders', 'customers', 'products']);
        return view('superuser.tenants.show', compact('tenant'));
    }

    public function edit(Tenant $tenant)
    {
        return view('superuser.tenants.edit', compact('tenant'));
    }

    public function update(Request $request, Tenant $tenant)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'domain' => 'required|string|max:255|unique:tenants,domain,' . $tenant->id,
            'company_name' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'phone' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'is_active' => 'boolean',
        ]);

        $settings = [
            'company_name' => $request->company_name,
            'address' => $request->address,
            'phone' => $request->phone,
            'email' => $request->email,
        ];

        $tenant->update([
            'name' => $request->name,
            'domain' => $request->domain,
            'settings' => $settings,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('superuser.tenants.index')->with('success', 'Tenant updated successfully.');
    }

    public function destroy(Tenant $tenant)
    {
        $tenant->delete();

        return redirect()->route('superuser.tenants.index')->with('success', 'Tenant deleted successfully.');
    }
} 