<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;
use App\Models\OrderStatus;
use App\Models\PaymentStatus;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class OrderController extends Controller
{
    use AuthorizesRequests;
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        
        $orders = Order::with(['customer','orderStatus','paymentStatus','salesUser','warehouseUser','deliveryUser'])
            ->where('tenant_id', $user->tenant_id)
            ->latest()
            ->paginate(20);

        return view('admin.orders.index', compact('orders'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        $customers = Customer::where('tenant_id', $user->tenant_id)->active()->get();
        $products = Product::where('tenant_id', $user->tenant_id)->active()->get();
        $orderStatuses = OrderStatus::active()->get();
        $paymentStatuses = PaymentStatus::active()->get();

        return view('admin.orders.create', compact('customers', 'products', 'orderStatuses', 'paymentStatuses'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'order_status_id' => 'required|exists:order_statuses,id',
            'payment_status_id' => 'required|exists:payment_statuses,id',
            'total_amount' => 'required|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        $order = Order::create([
            'tenant_id' => $user->tenant_id,
            'customer_id' => $request->customer_id,
            'sales_user_id' => $user->role === 'sales' ? $user->id : null,
            'order_status_id' => $request->order_status_id,
            'payment_status_id' => $request->payment_status_id,
            'total_amount' => $request->total_amount,
            'notes' => $request->notes,
            'order_date' => now(),
        ]);

        return redirect()->route('orders.index')->with('success', 'Order created successfully.');
    }

    public function show(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        if ($user->tenant_id !== $order->tenant_id) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->load(['customer', 'orderStatus', 'paymentStatus', 'orderItems.product', 'payments']);
        return view('admin.orders.show', compact('order'));
    }

    public function edit(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        if ($user->tenant_id !== $order->tenant_id || (!$user->isAdmin() && !$user->isOperator())) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        $customers = Customer::where('tenant_id', $user->tenant_id)->active()->get();
        $orderStatuses = OrderStatus::active()->get();
        $paymentStatuses = PaymentStatus::active()->get();

        return view('admin.orders.edit', compact('order', 'customers', 'orderStatuses', 'paymentStatuses'));
    }

    public function update(Request $request, Order $order)
    {
        $this->authorize('update', $order);
        
        $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'order_status_id' => 'required|exists:order_statuses,id',
            'payment_status_id' => 'required|exists:payment_statuses,id',
            'total_amount' => 'required|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        $order->update($request->all());

        return redirect()->route('orders.index')->with('success', 'Order updated successfully.');
    }

    public function destroy(Order $order)
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        if ($user->tenant_id !== $order->tenant_id || (!$user->isAdmin() && !$user->isOperator())) {
            abort(403, 'Unauthorized access to order.');
        }
        
        $order->delete();

        return redirect()->route('admin.orders.index')->with('success', 'Order deleted successfully.');
    }

    public function bulkUpdateStatus(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $request->validate([
            'order_ids' => 'required|array|min:1',
            'order_ids.*' => 'exists:orders,id',
            'status' => 'required|exists:order_statuses,name',
            'notes' => 'nullable|string|max:500',
        ]);

        $orderIds = $request->order_ids;
        $statusName = $request->status;
        $notes = $request->notes;

        // Get the status
        $status = \App\Models\OrderStatus::where('name', $statusName)->first();
        if (!$status) {
            return redirect()->back()->with('error', 'Invalid status selected.');
        }

        // Get orders that belong to the tenant
        $orders = \App\Models\Order::whereIn('id', $orderIds)
            ->where('tenant_id', $user->tenant_id)
            ->get();

        if ($orders->isEmpty()) {
            return redirect()->back()->with('error', 'No valid orders found for bulk update.');
        }

        $updatedCount = 0;
        $errors = [];

        foreach ($orders as $order) {
            try {
                // Update order status
                $order->update([
                    'order_status_id' => $status->id,
                ]);

                // Create status history
                $order->orderStatusHistory()->create([
                    'order_status_id' => $status->id,
                    'notes' => $notes,
                    'changed_by' => $user->id,
                ]);

                $updatedCount++;
            } catch (\Exception $e) {
                $errors[] = "Failed to update order #{$order->order_number}: " . $e->getMessage();
            }
        }

        $message = "Successfully updated {$updatedCount} order(s) to '{$statusName}' status.";
        if (!empty($errors)) {
            $message .= " Errors: " . implode(', ', $errors);
        }

        return redirect()->route('admin.orders.index')->with('success', $message);
    }
} 