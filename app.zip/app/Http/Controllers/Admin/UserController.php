<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TenantUser;
use App\Models\SalaryStructure;
use App\Models\SalarySetting;
use App\Models\UserBrandAssignment;
use App\Models\UserTerritoryAssignment;
use App\Models\ProductBrand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Helper method to safely get the authenticated tenant
     */
    private function getAuthenticatedTenant()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return null;
        }
        
        return $user->tenant;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }

        $users = TenantUser::where('tenant_id', $tenant->id)
            ->with(['salesOrders', 'warehouseOrders', 'deliveryOrders'])
            ->orderBy('name')
            ->paginate(15);

        $stats = [
            'total_users' => TenantUser::where('tenant_id', $tenant->id)->count(),
            'active_users' => TenantUser::where('tenant_id', $tenant->id)->where('is_active', true)->count(),
            'sales_users' => TenantUser::where('tenant_id', $tenant->id)->where('role', 'sales')->count(),
            'warehouse_users' => TenantUser::where('tenant_id', $tenant->id)->where('role', 'warehouse')->count(),
            'delivery_users' => TenantUser::where('tenant_id', $tenant->id)->where('role', 'delivery')->count(),
            'manager_users' => TenantUser::where('tenant_id', $tenant->id)->where('role', 'manager')->count(),
        ];

        return view('admin.users.index', compact('users', 'stats'));
    }

    public function show(TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }
        
        $user->load(['salesOrders.orderStatus', 'warehouseOrders.orderStatus', 'deliveryOrders.orderStatus']);
        
        // Get salary structure for this user
        $salaryStructure = SalaryStructure::where('tenant_id', $user->tenant_id)
            ->where('user_role', $user->role)
            ->where('is_active', true)
            ->first();

        // Get recent activity
        $recentOrders = collect()
            ->merge($user->salesOrders->take(5))
            ->merge($user->warehouseOrders->take(5))
            ->merge($user->deliveryOrders->take(5))
            ->sortByDesc('created_at')
            ->take(10);

        return view('admin.users.show', compact('user', 'salaryStructure', 'recentOrders'));
    }

    public function edit(TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }
        
        // Get available roles (excluding superadmin and admin)
        $availableRoles = ['manager', 'sales', 'warehouse', 'delivery'];
        
        // Get managers for assignment
        $managers = TenantUser::where('tenant_id', $tenant->id)
            ->where('role', 'manager')
            ->where('is_active', true)
            ->get();

        // Get all brands for assignment
        $brands = ProductBrand::where('tenant_id', $tenant->id)
            ->where('is_active', true)
            ->get();

        // Get user's assigned brands
        $userAssignedBrands = $user->brandAssignments()
            ->where('is_active', true)
            ->pluck('brand_id')
            ->toArray();

        // Get user's assigned territories
        $userAssignedTerritories = $user->territoryAssignments()
            ->where('is_active', true)
            ->pluck('territory_name')
            ->toArray();

        // Get salary structure for current role
        $currentSalaryStructure = SalaryStructure::where('tenant_id', $tenant->id)
            ->where('user_role', $user->role)
            ->where('is_active', true)
            ->first();

        // Get all salary structures for role selection
        $salaryStructures = SalaryStructure::where('tenant_id', $tenant->id)
            ->where('is_active', true)
            ->get();

        return view('admin.users.edit', compact(
            'user', 
            'availableRoles', 
            'managers', 
            'brands',
            'userAssignedBrands',
            'userAssignedTerritories',
            'currentSalaryStructure', 
            'salaryStructures'
        ));
    }

    public function update(Request $request, TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:tenant_users,email,' . $user->id,
            'phone' => 'nullable|string|max:20',
            'role' => 'required|in:manager,sales,warehouse,delivery',
            'manager_id' => 'nullable|exists:tenant_users,id',
            'is_active' => 'boolean',
            'base_salary' => 'nullable|numeric|min:0',
            'commission_rate' => 'nullable|numeric|min:0|max:100',
            'notes' => 'nullable|string',
            'brands' => 'nullable|array', // Brand assignment is now optional
            'brands.*' => 'exists:product_brands,id',
            'territories' => 'nullable|array', // Territory assignment is optional
            'territories.*' => 'string|max:255',
        ]);

        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }

        // Update user basic info
        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'role' => $request->role,
            'manager_id' => $request->manager_id,
            'is_active' => $request->has('is_active'),
            'notes' => $request->notes,
        ]);

        // Update brand assignments
        $this->updateBrandAssignments($user, $request->brands ?? []);

        // Update territory assignments
        $this->updateTerritoryAssignments($user, $request->territories ?? []);

        // Update or create salary structure for this role
        if ($request->base_salary !== null || $request->commission_rate !== null) {
            $salaryStructure = SalaryStructure::updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'user_role' => $request->role,
                ],
                [
                    'base_salary' => $request->base_salary ?? 0,
                    'commission_rate' => $request->commission_rate ?? 0,
                    'is_active' => true,
                ]
            );
        }

        return redirect()->route('admin.users.index')
            ->with('success', 'Пользователь успешно обновлен.');
    }

    private function updateBrandAssignments(TenantUser $user, array $brandIds)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return;
        }

        // Deactivate all existing brand assignments
        UserBrandAssignment::where('tenant_id', $tenant->id)
            ->where('tenant_user_id', $user->id)
            ->update(['is_active' => false]);

        // Create new brand assignments only if brands are selected
        if (!empty($brandIds)) {
            foreach ($brandIds as $brandId) {
                UserBrandAssignment::updateOrCreate(
                    [
                        'tenant_id' => $tenant->id,
                        'tenant_user_id' => $user->id,
                        'brand_id' => $brandId,
                    ],
                    [
                        'is_active' => true,
                    ]
                );
            }
        }
    }

    private function updateTerritoryAssignments(TenantUser $user, array $territories)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return;
        }

        // Deactivate all existing territory assignments
        UserTerritoryAssignment::where('tenant_id', $tenant->id)
            ->where('tenant_user_id', $user->id)
            ->update(['is_active' => false]);

        // Create new territory assignments
        foreach ($territories as $territory) {
            if (!empty(trim($territory))) {
                UserTerritoryAssignment::updateOrCreate(
                    [
                        'tenant_id' => $tenant->id,
                        'tenant_user_id' => $user->id,
                        'territory_name' => trim($territory),
                    ],
                    [
                        'is_active' => true,
                    ]
                );
            }
        }
    }

    public function toggleStatus(TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return response()->json(['error' => 'Please login to access this page.'], 401);
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }

        $user->update([
            'is_active' => !$user->is_active,
        ]);

        $status = $user->is_active ? 'активирован' : 'деактивирован';

        return response()->json([
            'success' => true,
            'message' => "Пользователь {$user->name} {$status}",
            'is_active' => $user->is_active,
        ]);
    }

    public function resetPassword(TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return response()->json(['error' => 'Please login to access this page.'], 401);
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }

        // Generate a random password
        $newPassword = \Str::random(8);
        
        $user->update([
            'password' => Hash::make($newPassword),
        ]);

        return response()->json([
            'success' => true,
            'message' => "Пароль для {$user->name} сброшен",
            'new_password' => $newPassword,
        ]);
    }

    public function activity(TenantUser $user)
    {
        $tenant = $this->getAuthenticatedTenant();
        
        if (!$tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        // Check if user belongs to the same tenant
        if ($user->tenant_id !== $tenant->id) {
            abort(403, 'У вас нет доступа к этому пользователю');
        }

        $user->load(['salesOrders.orderStatus', 'warehouseOrders.orderStatus', 'deliveryOrders.orderStatus']);

        // Get activity for the last 30 days
        $thirtyDaysAgo = now()->subDays(30);

        $salesActivity = $user->salesOrders()
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->with('orderStatus')
            ->get();

        $warehouseActivity = $user->warehouseOrders()
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->with('orderStatus')
            ->get();

        $deliveryActivity = $user->deliveryOrders()
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->with('orderStatus')
            ->get();

        return response()->json([
            'success' => true,
            'sales_orders' => $salesActivity,
            'warehouse_orders' => $warehouseActivity,
            'delivery_orders' => $deliveryActivity,
        ]);
    }
} 