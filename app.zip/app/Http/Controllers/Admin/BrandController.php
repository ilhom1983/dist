<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProductBrand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;
        $brands = ProductBrand::where('tenant_id', $tenant->id)
            ->withCount('products')
            ->orderBy('name')
            ->paginate(15);

        return view('admin.brands.index', compact('brands'));
    }

    public function create()
    {
        return view('admin.brands.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'website' => 'nullable|url',
            'is_active' => 'boolean',
        ]);

        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;
        
        $brand = ProductBrand::create([
            'tenant_id' => $tenant->id,
            'name' => $request->name,
            'description' => $request->description,
            'website' => $request->website,
            'is_active' => $request->has('is_active'),
        ]);

        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('brands', 'public');
            $brand->logo = $logoPath;
            $brand->save();
        }

        return redirect()->route('admin.brands.index')
            ->with('success', 'Бренд успешно создан.');
    }

    public function show(ProductBrand $brand)
    {
        $this->authorize('view', $brand);
        
        $brand->load(['products' => function($query) {
            $query->withCount('orderItems');
        }]);

        return view('admin.brands.show', compact('brand'));
    }

    public function edit(ProductBrand $brand)
    {
        $this->authorize('update', $brand);
        
        return view('admin.brands.edit', compact('brand'));
    }

    public function update(Request $request, ProductBrand $brand)
    {
        $this->authorize('update', $brand);

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'website' => 'nullable|url',
            'is_active' => 'boolean',
        ]);

        $brand->update([
            'name' => $request->name,
            'description' => $request->description,
            'website' => $request->website,
            'is_active' => $request->has('is_active'),
        ]);

        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('brands', 'public');
            $brand->logo = $logoPath;
            $brand->save();
        }

        return redirect()->route('admin.brands.index')
            ->with('success', 'Бренд успешно обновлен.');
    }

    public function destroy(ProductBrand $brand)
    {
        $this->authorize('delete', $brand);

        if ($brand->products()->count() > 0) {
            return back()->with('error', 'Нельзя удалить бренд, у которого есть товары.');
        }

        $brand->delete();

        return redirect()->route('admin.brands.index')
            ->with('success', 'Бренд успешно удален.');
    }
}
