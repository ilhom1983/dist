<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        $tenantId = $user->tenant_id;
        
        // Get tenant name safely
        $tenant = \App\Models\Tenant::find($tenantId);
        $tenantName = $tenant ? $tenant->name : 'Unknown Tenant';
        
        $payments = Payment::join('orders', 'payments.order_id', '=', 'orders.id')
            ->where('orders.tenant_id', $tenantId)
            ->with(['order.customer', 'paymentMethod', 'paymentStatus'])
            ->orderBy('payment_date', 'desc')
            ->paginate(15);

        $stats = [
            'total_payments' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenantId)->count(),
            'total_amount' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenantId)
                ->where('payments.payment_status_id', 1)
                ->sum('payments.amount'),
            'today_payments' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenantId)
                ->whereDate('payments.payment_date', today())
                ->count(),
            'pending_payments' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenantId)
                ->where('payments.payment_status_id', '!=', 1)
                ->count(),
        ];

        return view('admin.payments.index', compact('payments', 'stats', 'tenantName'));
    }

    public function create()
    {
        return view('admin.payments.create');
    }

    public function store(Request $request)
    {
        // Implementation for creating payment
        return redirect()->route('admin.payments.index')
            ->with('success', 'Платеж создан.');
    }

    public function show(Payment $payment)
    {
        return view('admin.payments.show', compact('payment'));
    }

    public function edit(Payment $payment)
    {
        return view('admin.payments.edit', compact('payment'));
    }

    public function update(Request $request, Payment $payment)
    {
        // Implementation for updating payment
        return redirect()->route('admin.payments.index')
            ->with('success', 'Платеж обновлен.');
    }

    public function destroy(Payment $payment)
    {
        // Implementation for deleting payment
        return redirect()->route('admin.payments.index')
            ->with('success', 'Платеж удален.');
    }
}
