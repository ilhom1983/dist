<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductBrand;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        $tenant = $user->tenant;
        
        // Get accessible brand IDs for the user
        $accessibleBrandIds = $user->getAccessibleBrandIds();
        
        // Build the query
        $query = Product::where('tenant_id', $tenant->id)
                       ->where('is_active', true)
                       ->with(['brand', 'category']);
        
        // Filter by accessible brands if user has restricted access
        if ($user->hasRestrictedBrandAccess()) {
            $query->whereIn('brand_id', $accessibleBrandIds);
        }
        
        // Apply additional filters
        if ($request->has('brand_id') && $request->brand_id) {
            $query->where('brand_id', $request->brand_id);
        }
        
        if ($request->has('category_id') && $request->category_id) {
            $query->where('category_id', $request->category_id);
        }
        
        if ($request->has('search') && $request->search) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }
        
        $products = $query->orderBy('name')->paginate(15);
        
        // Get available brands for filter dropdown
        $availableBrands = ProductBrand::where('tenant_id', $tenant->id)
                                     ->where('is_active', true);
        
        // If user has restricted access, only show accessible brands
        if ($user->hasRestrictedBrandAccess()) {
            $availableBrands->whereIn('id', $accessibleBrandIds);
        }
        
        $availableBrands = $availableBrands->get();
        
        return view('admin.products.index', compact('products', 'availableBrands'));
    }

    public function show(Product $product)
    {
        $user = auth()->guard('tenant')->user();
        
        // Check if user has access to this product's brand
        if (!$user->hasBrandAccess($product->brand_id)) {
            abort(403, 'У вас нет доступа к этому товару');
        }
        
        $product->load(['brand', 'category', 'orderItems']);
        
        return view('admin.products.show', compact('product'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        $tenant = $user->tenant;
        
        // Get accessible brands for product creation
        $accessibleBrandIds = $user->getAccessibleBrandIds();
        
        $brands = ProductBrand::where('tenant_id', $tenant->id)
                             ->where('is_active', true);
        
        // If user has restricted access, only show accessible brands
        if ($user->hasRestrictedBrandAccess()) {
            $brands->whereIn('id', $accessibleBrandIds);
        }
        
        $brands = $brands->get();
        
        return view('admin.products.create', compact('brands'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'brand_id' => 'required|exists:product_brands,id',
            'category_id' => 'nullable|exists:product_categories,id',
            'price' => 'required|numeric|min:0',
            'is_active' => 'boolean',
        ]);
        
        // Check if user has access to the selected brand
        if (!$user->hasBrandAccess($request->brand_id)) {
            return back()->withErrors(['brand_id' => 'У вас нет доступа к этому бренду']);
        }
        
        $product = Product::create([
            'tenant_id' => $user->tenant_id,
            'name' => $request->name,
            'description' => $request->description,
            'brand_id' => $request->brand_id,
            'category_id' => $request->category_id,
            'price' => $request->price,
            'is_active' => $request->has('is_active'),
        ]);
        
        return redirect()->route('admin.products.index')
            ->with('success', 'Товар успешно создан.');
    }
} 