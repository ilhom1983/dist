<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SalaryPayment;
use App\Models\SalaryStructure;
use App\Models\SalarySetting;
use App\Models\CommissionCalculation;
use App\Models\TenantUser;
use Illuminate\Http\Request;
use Carbon\Carbon;

class SalaryController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        $tenantId = $user->tenant_id;
        
        // Get tenant name safely
        $tenant = \App\Models\Tenant::find($tenantId);
        $tenantName = $tenant ? $tenant->name : 'Unknown Tenant';
        
        $currentMonth = Carbon::now()->format('Y-m');
        
        $salaryPayments = SalaryPayment::where('tenant_id', $tenantId)
            ->with('tenantUser')
            ->orderBy('payment_date', 'desc')
            ->paginate(15);

        $salaryStructures = SalaryStructure::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();

        $salarySettings = SalarySetting::where('tenant_id', $tenantId)->first();

        $stats = [
            'total_payments' => SalaryPayment::where('tenant_id', $tenantId)->count(),
            'this_month_payments' => SalaryPayment::where('tenant_id', $tenantId)
                ->where('month', $currentMonth)
                ->count(),
            'total_amount' => SalaryPayment::where('tenant_id', $tenantId)
                ->where('status', 'paid')
                ->sum('total_amount'),
            'pending_payments' => SalaryPayment::where('tenant_id', $tenantId)
                ->where('status', 'pending')
                ->count(),
        ];

        return view('admin.salaries.index', compact('salaryPayments', 'salaryStructures', 'salarySettings', 'stats', 'tenantName'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        $tenantId = $user->tenant_id;
        
        // Get tenant name safely
        $tenant = \App\Models\Tenant::find($tenantId);
        $tenantName = $tenant ? $tenant->name : 'Unknown Tenant';
        
        $employees = TenantUser::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();
        
        $salaryStructures = SalaryStructure::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();

        return view('admin.salaries.create', compact('employees', 'salaryStructures', 'tenantName'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'tenant_user_id' => 'required|exists:tenant_users,id',
            'month' => 'required|date_format:Y-m',
            'base_salary' => 'required|numeric|min:0',
            'commission_amount' => 'nullable|numeric|min:0',
            'bonus_amount' => 'nullable|numeric|min:0',
            'deductions' => 'nullable|numeric|min:0',
            'payment_date' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        $tenantId = auth()->guard('tenant')->user()->tenant_id;
        
        // Calculate total amount
        $totalAmount = $request->base_salary + 
                      ($request->commission_amount ?? 0) + 
                      ($request->bonus_amount ?? 0) - 
                      ($request->deductions ?? 0);

        $salaryPayment = SalaryPayment::create([
            'tenant_id' => $tenantId,
            'tenant_user_id' => $request->tenant_user_id,
            'month' => $request->month,
            'base_salary' => $request->base_salary,
            'commission_amount' => $request->commission_amount ?? 0,
            'bonus_amount' => $request->bonus_amount ?? 0,
            'deductions' => $request->deductions ?? 0,
            'total_amount' => $totalAmount,
            'payment_date' => $request->payment_date ?? now(),
            'status' => 'paid',
            'notes' => $request->notes,
        ]);

        return redirect()->route('admin.salaries.index')
            ->with('success', 'Зарплата успешно создана.');
    }

    public function show(SalaryPayment $salary)
    {
        $this->authorize('view', $salary);
        
        $salary->load('tenantUser');
        
        return view('admin.salaries.show', compact('salary'));
    }

    public function edit(SalaryPayment $salary)
    {
        $this->authorize('update', $salary);
        
        $tenantId = auth()->guard('tenant')->user()->tenant_id;
        $employees = TenantUser::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();
        
        $salaryStructures = SalaryStructure::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();

        return view('admin.salaries.edit', compact('salary', 'employees', 'salaryStructures'));
    }

    public function update(Request $request, SalaryPayment $salary)
    {
        $this->authorize('update', $salary);

        $request->validate([
            'tenant_user_id' => 'required|exists:tenant_users,id',
            'month' => 'required|date_format:Y-m',
            'base_salary' => 'required|numeric|min:0',
            'commission_amount' => 'nullable|numeric|min:0',
            'bonus_amount' => 'nullable|numeric|min:0',
            'deductions' => 'nullable|numeric|min:0',
            'payment_date' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        // Calculate total amount
        $totalAmount = $request->base_salary + 
                      ($request->commission_amount ?? 0) + 
                      ($request->bonus_amount ?? 0) - 
                      ($request->deductions ?? 0);

        $salary->update([
            'tenant_user_id' => $request->tenant_user_id,
            'month' => $request->month,
            'base_salary' => $request->base_salary,
            'commission_amount' => $request->commission_amount ?? 0,
            'bonus_amount' => $request->bonus_amount ?? 0,
            'deductions' => $request->deductions ?? 0,
            'total_amount' => $totalAmount,
            'payment_date' => $request->payment_date ?? $salary->payment_date,
            'notes' => $request->notes,
        ]);

        return redirect()->route('admin.salaries.index')
            ->with('success', 'Зарплата успешно обновлена.');
    }

    public function destroy(SalaryPayment $salary)
    {
        $this->authorize('delete', $salary);

        $salary->delete();

        return redirect()->route('admin.salaries.index')
            ->with('success', 'Зарплата успешно удалена.');
    }

    public function calculateSalary(Request $request)
    {
        $request->validate([
            'tenant_user_id' => 'required|exists:tenant_users,id',
            'month' => 'required|date_format:Y-m',
        ]);

        $tenantId = auth()->guard('tenant')->user()->tenant_id;
        $user = TenantUser::find($request->tenant_user_id);
        $month = $request->month;

        $salaryStructure = SalaryStructure::where('tenant_id', $tenantId)
            ->where('user_role', $user->role)
            ->where('is_active', true)
            ->first();

        if (!$salaryStructure) {
            return response()->json(['error' => 'Структура зарплаты не найдена для роли: ' . $user->role]);
        }

        $commission = CommissionCalculation::where('tenant_id', $tenantId)
            ->where('tenant_user_id', $user->id)
            ->where('month', $month)
            ->first();

        $salarySettings = SalarySetting::where('tenant_id', $tenantId)->first();

        $baseSalary = $salaryStructure->base_salary;
        $commissionAmount = $commission ? $commission->commission_amount : 0;
        $bonusAmount = 0;
        $deductions = 0;

        $totalAmount = $baseSalary + $commissionAmount + $bonusAmount - $deductions;

        return response()->json([
            'base_salary' => $baseSalary,
            'commission_amount' => $commissionAmount,
            'bonus_amount' => $bonusAmount,
            'deductions' => $deductions,
            'total_amount' => $totalAmount,
        ]);
    }

    public function calculateAll(Request $request)
    {
        $request->validate([
            'month' => 'required|date_format:Y-m',
            'include_attendance_bonus' => 'boolean',
            'include_overtime_bonus' => 'boolean',
            'include_tax_deductions' => 'boolean',
        ]);

        $tenantId = auth()->guard('tenant')->user()->tenant_id;
        $month = $request->month;
        
        $employees = TenantUser::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->get();

        $results = [];
        $salarySettings = SalarySetting::where('tenant_id', $tenantId)->first();

        foreach ($employees as $employee) {
            $salaryStructure = SalaryStructure::where('tenant_id', $tenantId)
                ->where('user_role', $employee->role)
                ->where('is_active', true)
                ->first();

            if (!$salaryStructure) {
                continue;
            }

            $commission = CommissionCalculation::where('tenant_id', $tenantId)
                ->where('tenant_user_id', $employee->id)
                ->where('month', $month)
                ->first();

            $baseSalary = $salaryStructure->base_salary;
            $commissionAmount = $commission ? $commission->commission_amount : 0;
            $bonusAmount = 0;
            $deductions = 0;

            if ($request->include_attendance_bonus && $salarySettings) {
                $bonusAmount += $salarySettings->attendance_bonus ?? 0;
            }

            if ($request->include_overtime_bonus && $salarySettings) {
                $overtimeRate = $salarySettings->overtime_rate ?? 0;
                $overtimeBonus = ($baseSalary * $overtimeRate) / 100;
                $bonusAmount += $overtimeBonus;
            }

            if ($request->include_tax_deductions && $salarySettings) {
                $taxRate = $salarySettings->tax_rate ?? 0;
                $taxAmount = ($baseSalary + $commissionAmount + $bonusAmount) * ($taxRate / 100);
                $deductions += $taxAmount;
            }

            $totalAmount = $baseSalary + $commissionAmount + $bonusAmount - $deductions;

            $results[] = [
                'user_id' => $employee->id,
                'employee_name' => $employee->name,
                'role' => $employee->role,
                'base_salary' => $baseSalary,
                'commission_amount' => $commissionAmount,
                'bonus_amount' => $bonusAmount,
                'deductions' => $deductions,
                'total_amount' => $totalAmount,
            ];
        }

        return response()->json([
            'success' => true,
            'results' => $results,
            'message' => 'Расчет завершен для ' . count($results) . ' сотрудников',
        ]);
    }

    public function createAll(Request $request)
    {
        $request->validate([
            'month' => 'required|date_format:Y-m',
            'payment_date' => 'required|date',
            'results' => 'required|array',
        ]);

        $tenantId = auth()->guard('tenant')->user()->tenant_id;
        $month = $request->month;
        $paymentDate = $request->payment_date;
        $results = $request->results;

        $createdCount = 0;
        $errors = [];

        foreach ($results as $result) {
            try {
                $existingPayment = SalaryPayment::where('tenant_id', $tenantId)
                    ->where('tenant_user_id', $result['user_id'])
                    ->where('month', $month)
                    ->first();

                if ($existingPayment) {
                    $errors[] = "Выплата для {$result['employee_name']} за {$month} уже существует";
                    continue;
                }

                SalaryPayment::create([
                    'tenant_id' => $tenantId,
                    'tenant_user_id' => $result['user_id'],
                    'month' => $month,
                    'base_salary' => $result['base_salary'],
                    'commission_amount' => $result['commission_amount'],
                    'bonus_amount' => $result['bonus_amount'],
                    'deductions' => $result['deductions'],
                    'total_amount' => $result['total_amount'],
                    'payment_date' => $paymentDate,
                    'status' => 'pending',
                    'notes' => 'Автоматически рассчитано',
                ]);

                $createdCount++;
            } catch (\Exception $e) {
                $errors[] = "Ошибка при создании выплаты для {$result['employee_name']}: " . $e->getMessage();
            }
        }

        return response()->json([
            'success' => true,
            'created_count' => $createdCount,
            'errors' => $errors,
            'message' => "Создано {$createdCount} выплат" . (count($errors) > 0 ? " (ошибок: " . count($errors) . ")" : ""),
        ]);
    }
}
