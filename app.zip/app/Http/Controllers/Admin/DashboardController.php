<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tenant;
use App\Models\TenantUser;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Payment;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;

        $data = [
            'tenant' => $tenant,
            'stats' => $this->getStats($tenant),
            'realtimeMetrics' => $this->getRealtimeMetrics($tenant),
            'recentOrders' => $this->getRecentOrders($tenant),
            'topProducts' => $this->getTopProducts($tenant),
            'recentCustomers' => $this->getRecentCustomers($tenant),
            'salesTrends' => $this->getSalesTrends($tenant),
            'userActivity' => $this->getUserActivity($tenant),
            'quickActions' => $this->getQuickActions($tenant),
            'systemHealth' => $this->getSystemHealth($tenant),
            'brands' => $this->getBrands($tenant),
            'categories' => $this->getCategories($tenant),
            'deliveries' => $this->getDeliveries($tenant),
            'payments' => $this->getPayments($tenant),
            'salaries' => $this->getSalaries($tenant),
        ];

        return view('admin.dashboard', $data);
    }

    private function getStats($tenant)
    {
        $today = Carbon::today();
        $thisMonth = Carbon::now()->startOfMonth();

        return [
            'total_orders' => Order::where('tenant_id', $tenant->id)->count(),
            'active_orders' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->whereNotIn('name', ['cancelled', 'closed']);
                })
                ->count(),
            'cancelled_orders' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->where('name', 'cancelled');
                })
                ->where('created_at', '>=', now()->subMonths(12)) // Last 12 months
                ->count(),
            'returned_orders' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->where('name', 'returned');
                })
                ->where('created_at', '>=', now()->subMonths(12)) // Last 12 months
                ->count(),
            'total_revenue' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenant->id)
                ->where('payments.payment_status_id', 1)
                ->sum('payments.amount'),
            'total_customers' => Customer::where('tenant_id', $tenant->id)->count(),
            'total_products' => Product::where('tenant_id', $tenant->id)->count(),
            'today_orders' => Order::where('tenant_id', $tenant->id)
                ->whereDate('created_at', $today)
                ->count(),
            'today_revenue' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenant->id)
                ->where('payments.payment_status_id', 1)
                ->whereDate('payments.payment_date', $today)
                ->sum('payments.amount'),
            'monthly_orders' => Order::where('tenant_id', $tenant->id)
                ->where('created_at', '>=', $thisMonth)
                ->count(),
            'monthly_revenue' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                ->where('orders.tenant_id', $tenant->id)
                ->where('payments.payment_status_id', 1)
                ->where('payments.payment_date', '>=', $thisMonth)
                ->sum('payments.amount'),
        ];
    }

    private function getRealtimeMetrics($tenant)
    {
        $lastMonth = Carbon::now()->subMonth();
        $thisMonth = Carbon::now()->startOfMonth();

        $currentMonthOrders = Order::where('tenant_id', $tenant->id)
            ->where('created_at', '>=', $thisMonth)
            ->count();
        $lastMonthOrders = Order::where('tenant_id', $tenant->id)
            ->where('created_at', '>=', $lastMonth)
            ->where('created_at', '<', $thisMonth)
            ->count();

        $currentMonthRevenue = Payment::join('orders', 'payments.order_id', '=', 'orders.id')
            ->where('orders.tenant_id', $tenant->id)
            ->where('payments.payment_status_id', 1)
            ->where('payments.payment_date', '>=', $thisMonth)
            ->sum('payments.amount');
        $lastMonthRevenue = Payment::join('orders', 'payments.order_id', '=', 'orders.id')
            ->where('orders.tenant_id', $tenant->id)
            ->where('payments.payment_status_id', 1)
            ->where('payments.payment_date', '>=', $lastMonth)
            ->where('payments.payment_date', '<', $thisMonth)
            ->sum('payments.amount');

        return [
            'order_growth' => $lastMonthOrders > 0 ? (($currentMonthOrders - $lastMonthOrders) / $lastMonthOrders) * 100 : 0,
            'revenue_growth' => $lastMonthRevenue > 0 ? (($currentMonthRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100 : 0,
            'today_orders' => Order::where('tenant_id', $tenant->id)
                ->whereDate('created_at', Carbon::today())
                ->count(),
            'pending_orders' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->whereIn('name', ['pending', 'approved']);
                })
                ->count(),
            'active_users' => TenantUser::where('tenant_id', $tenant->id)
                ->where('is_active', true)
                ->count(),
        ];
    }

    private function getRecentOrders($tenant)
    {
        return Order::with(['customer', 'orderItems.product'])
            ->where('tenant_id', $tenant->id)
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();
    }

    private function getTopProducts($tenant)
    {
        return Product::where('tenant_id', $tenant->id)
            ->withCount(['orderItems as total_orders' => function($query) {
                $query->join('orders', 'order_items.order_id', '=', 'orders.id')
                    ->join('order_statuses', 'orders.order_status_id', '=', 'order_statuses.id')
                    ->whereNotIn('order_statuses.name', ['cancelled', 'returned']);
            }])
            ->orderBy('total_orders', 'desc')
            ->limit(5)
            ->get();
    }

    private function getRecentCustomers($tenant)
    {
        return Customer::where('tenant_id', $tenant->id)
            ->withCount('orders')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
    }

    private function getSalesTrends($tenant)
    {
        $trends = collect();
        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);
            $trends->push([
                'date' => $date->format('M d'),
                'orders' => Order::where('tenant_id', $tenant->id)
                    ->whereDate('created_at', $date)
                    ->count(),
                'revenue' => Payment::join('orders', 'payments.order_id', '=', 'orders.id')
                    ->where('orders.tenant_id', $tenant->id)
                    ->where('payments.payment_status_id', 1)
                    ->whereDate('payments.payment_date', $date)
                    ->sum('payments.amount'),
            ]);
        }
        return $trends;
    }

    private function getUserActivity($tenant)
    {
        return TenantUser::where('tenant_id', $tenant->id)
            ->where('is_active', true)
            ->withCount(['salesOrders' => function($query) {
                $query->where('created_at', '>=', Carbon::now()->subDays(7));
            }])
            ->withCount(['warehouseOrders' => function($query) {
                $query->where('created_at', '>=', Carbon::now()->subDays(7));
            }])
            ->withCount(['deliveryOrders' => function($query) {
                $query->where('created_at', '>=', Carbon::now()->subDays(7));
            }])
            ->get()
            ->map(function($user) {
                $user->total_orders = $user->sales_orders_count + $user->warehouse_orders_count + $user->delivery_orders_count;
                return $user;
            })
            ->sortByDesc('total_orders')
            ->take(5);
    }

    private function getQuickActions($tenant)
    {
        return [
            ['title' => 'Управление Заказами', 'icon' => 'shopping-cart', 'url' => route('admin.orders.index'), 'color' => 'blue'],
            ['title' => 'Управление Клиентами', 'icon' => 'users', 'url' => route('admin.customers.index'), 'color' => 'green'],
            ['title' => 'Управление Товарами', 'icon' => 'box', 'url' => route('admin.products.index'), 'color' => 'purple'],
            ['title' => 'Управление Пользователями', 'icon' => 'user-cog', 'url' => route('admin.users.index'), 'color' => 'indigo'],
            ['title' => 'Бренды', 'icon' => 'tag', 'url' => route('admin.brands.index'), 'color' => 'indigo'],
            ['title' => 'Категории', 'icon' => 'folder', 'url' => route('admin.categories.index'), 'color' => 'teal'],
            ['title' => 'Доставка', 'icon' => 'truck', 'url' => route('admin.deliveries.index'), 'color' => 'orange'],
            ['title' => 'Платежи', 'icon' => 'credit-card', 'url' => route('admin.payments.index'), 'color' => 'emerald'],
            ['title' => 'Зарплаты', 'icon' => 'money-bill', 'url' => route('admin.salaries.index'), 'color' => 'yellow'],
            ['title' => 'Отчеты', 'icon' => 'chart-bar', 'url' => route('admin.reports.index'), 'color' => 'pink'],
            ['title' => 'Настройки', 'icon' => 'cog', 'url' => route('admin.settings.index'), 'color' => 'gray'],
        ];
    }

    private function getSystemHealth($tenant)
    {
        return [
            'database_status' => ['status' => 'healthy', 'response_time' => rand(10, 50)],
            'api_status' => [
                'yandex' => ['status' => 'active', 'last_check' => now(), 'response_time' => rand(20, 100)],
                'telegram' => ['status' => 'active', 'last_check' => now(), 'response_time' => rand(15, 80)],
            ],
            'storage_usage' => ['total' => '50GB', 'used' => '25GB', 'free' => '25GB', 'percentage' => 50],
            'error_rate' => ['rate' => '0.01%', 'total_errors' => 5, 'period' => '24h'],
            'uptime' => ['current' => '99.99%', 'last_24h' => '99.99%', 'last_7d' => '99.95%'],
        ];
    }

    private function getBrands($tenant)
    {
        return \App\Models\ProductBrand::where('tenant_id', $tenant->id)
            ->withCount('products')
            ->orderBy('name')
            ->limit(5)
            ->get();
    }

    private function getCategories($tenant)
    {
        return \App\Models\ProductCategory::where('tenant_id', $tenant->id)
            ->withCount('products')
            ->orderBy('name')
            ->limit(5)
            ->get();
    }

    private function getDeliveries($tenant)
    {
        return Order::where('tenant_id', $tenant->id)
            ->whereHas('orderStatus', function($query) {
                $query->whereIn('name', ['approved', 'loaded']);
            })
            ->with(['deliveryUser', 'customer'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
    }

    private function getPayments($tenant)
    {
        return Payment::join('orders', 'payments.order_id', '=', 'orders.id')
            ->where('orders.tenant_id', $tenant->id)
            ->with(['order.customer', 'paymentMethod'])
            ->orderBy('payment_date', 'desc')
            ->limit(5)
            ->get();
    }

    private function getSalaries($tenant)
    {
        return \App\Models\SalaryPayment::where('tenant_id', $tenant->id)
            ->with('employee')
            ->orderBy('payment_date', 'desc')
            ->limit(5)
            ->get();
    }
}
