<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;
        $categories = ProductCategory::where('tenant_id', $tenant->id)
            ->withCount('products')
            ->orderBy('name')
            ->paginate(15);

        return view('admin.categories.index', compact('categories'));
    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;
        
        ProductCategory::create([
            'tenant_id' => $tenant->id,
            'name' => $request->name,
            'description' => $request->description,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('admin.categories.index')
            ->with('success', 'Категория успешно создана.');
    }

    public function show(ProductCategory $category)
    {
        $this->authorize('view', $category);
        
        $category->load(['products' => function($query) {
            $query->withCount('orderItems');
        }]);

        return view('admin.categories.show', compact('category'));
    }

    public function edit(ProductCategory $category)
    {
        $this->authorize('update', $category);
        
        return view('admin.categories.edit', compact('category'));
    }

    public function update(Request $request, ProductCategory $category)
    {
        $this->authorize('update', $category);

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $category->update([
            'name' => $request->name,
            'description' => $request->description,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('admin.categories.index')
            ->with('success', 'Категория успешно обновлена.');
    }

    public function destroy(ProductCategory $category)
    {
        $this->authorize('delete', $category);

        if ($category->products()->count() > 0) {
            return back()->with('error', 'Нельзя удалить категорию, у которой есть товары.');
        }

        $category->delete();

        return redirect()->route('admin.categories.index')
            ->with('success', 'Категория успешно удалена.');
    }
}
