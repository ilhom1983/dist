<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class DeliveryController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user || !$user->tenant) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }
        
        $tenant = $user->tenant;
        
        $deliveries = Order::where('tenant_id', $tenant->id)
            ->whereHas('orderStatus', function($query) {
                $query->whereIn('name', ['approved', 'loaded', 'delivered']);
            })
            ->with(['customer', 'deliveryUser', 'orderStatus'])
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        $stats = [
            'total_deliveries' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->whereIn('name', ['approved', 'loaded', 'delivered']);
                })->count(),
            'pending_deliveries' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->where('name', 'approved');
                })->count(),
            'in_transit' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->where('name', 'loaded');
                })->count(),
            'delivered_today' => Order::where('tenant_id', $tenant->id)
                ->whereHas('orderStatus', function($query) {
                    $query->where('name', 'delivered');
                })
                ->whereDate('updated_at', today())
                ->count(),
        ];

        return view('admin.deliveries.index', compact('deliveries', 'stats'));
    }

    public function create()
    {
        return view('admin.deliveries.create');
    }

    public function store(Request $request)
    {
        // Implementation for creating delivery
        return redirect()->route('admin.deliveries.index')
            ->with('success', 'Доставка создана.');
    }

    public function show(Order $delivery)
    {
        return view('admin.deliveries.show', compact('delivery'));
    }

    public function edit(Order $delivery)
    {
        $user = auth()->guard('tenant')->user();
        
        // Get orders for dropdown
        $orders = Order::where('tenant_id', $user->tenant_id)
            ->with('customer')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Get delivery users
        $deliveryUsers = \App\Models\TenantUser::where('tenant_id', $user->tenant_id)
            ->where('role', 'delivery')
            ->get();
        
        return view('admin.deliveries.edit', compact('delivery', 'orders', 'deliveryUsers'));
    }

    public function update(Request $request, Order $delivery)
    {
        // Implementation for updating delivery
        return redirect()->route('admin.deliveries.index')
            ->with('success', 'Доставка обновлена.');
    }

    public function destroy(Order $delivery)
    {
        // Implementation for deleting delivery
        return redirect()->route('admin.deliveries.index')
            ->with('success', 'Доставка удалена.');
    }
}
