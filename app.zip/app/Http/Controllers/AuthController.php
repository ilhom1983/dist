<?php

namespace App\Http\Controllers;

use App\Models\Superuser;
use App\Models\TenantUser;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        // Add debugging
        \Log::info('Login attempt', [
            'email' => $request->email,
            'has_password' => $request->has('password'),
            'remember' => $request->has('remember'),
            'all_data' => $request->all()
        ]);

        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $email = $request->email;
        $password = $request->password;

        \Log::info('Starting authentication for email: ' . $email);

        // Try tenant user authentication first (since most users are tenant users)
        $tenantUser = TenantUser::where('email', $email)->first();
        
        if ($tenantUser) {
            \Log::info('Found tenant user', ['user_id' => $tenantUser->id, 'is_active' => $tenantUser->is_active]);
            
            if (Hash::check($password, $tenantUser->password) && $tenantUser->is_active) {
                // Check if tenant is active
                $tenant = $tenantUser->tenant;
                if ($tenant && $tenant->is_active) {
                    Auth::guard('tenant')->login($tenantUser);
                    
                    // Set remember me if requested
                    if ($request->has('remember')) {
                        Auth::guard('tenant')->setRememberDuration(60 * 24 * 30); // 30 days
                    }
                    
                    \Log::info('Tenant user login successful', ['user_id' => $tenantUser->id, 'role' => $tenantUser->role]);
                    
                    // Redirect based on user role
                    $redirectUrl = $this->getRedirectUrlByRole($tenantUser);
                    return redirect()->intended($redirectUrl)->with('success', 'Добро пожаловать, ' . $tenantUser->name . '!');
                } else {
                    \Log::info('Tenant is not active', ['tenant_id' => $tenant->id ?? 'null']);
                    return back()->withErrors([
                        'email' => 'Ваш аккаунт неактивен. Обратитесь к администратору.',
                    ]);
                }
            } else {
                \Log::info('Tenant user password check failed or user inactive');
            }
        } else {
            \Log::info('No tenant user found for email: ' . $email);
        }

        // If tenant authentication fails, try superuser
        $superuser = Superuser::where('email', $email)->first();
        
        if ($superuser) {
            \Log::info('Found superuser', ['user_id' => $superuser->id, 'is_active' => $superuser->is_active]);
            
            if (Hash::check($password, $superuser->password) && $superuser->is_active) {
                Auth::guard('superuser')->login($superuser);
                
                // Set remember me if requested
                if ($request->has('remember')) {
                    Auth::guard('superuser')->setRememberDuration(60 * 24 * 30); // 30 days
                }
                
                \Log::info('Superuser login successful', ['user_id' => $superuser->id]);
                
                return redirect()->intended('/superuser/dashboard')->with('success', 'Добро пожаловать, ' . $superuser->name . '!');
            } else {
                \Log::info('Superuser password check failed or user inactive');
            }
        } else {
            \Log::info('No superuser found for email: ' . $email);
        }

        // If both authentication attempts fail
        \Log::info('All authentication attempts failed for email: ' . $email);
        return back()->withErrors([
            'email' => 'Неверные учетные данные. Проверьте email и пароль.',
        ]);
    }

    /**
     * Get redirect URL based on user role
     */
    private function getRedirectUrlByRole($user)
    {
        switch ($user->role) {
            case 'admin':
                return '/admin/dashboard';
            case 'operator':
                return '/operator/dashboard';
            case 'sales':
                // Sales users - redirect to new sales dashboard
                return '/mobile/sales';
            case 'manager':
            case 'warehouse':
            case 'delivery':
                // Mobile users - redirect to mobile dashboard or API endpoint
                return '/mobile/dashboard';
            default:
                return '/dashboard';
        }
    }

    public function logout(Request $request)
    {
        if (Auth::guard('superuser')->check()) {
            $user = Auth::guard('superuser')->user();
            Auth::guard('superuser')->logout();
        } elseif (Auth::guard('tenant')->check()) {
            $user = Auth::guard('tenant')->user();
            Auth::guard('tenant')->logout();
        }

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login')->with('success', 'Вы успешно вышли из системы.');
    }

    public function apiLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
            'tenant_id' => 'required',
        ]);

        $email = $request->email;
        $password = $request->password;
        $tenantId = $request->tenant_id;

        // Try tenant user authentication
        $tenantUser = TenantUser::where('email', $email)
            ->where('tenant_id', $tenantId)
            ->first();

        if ($tenantUser && Hash::check($password, $tenantUser->password) && $tenantUser->is_active) {
            $tenant = $tenantUser->tenant;
            if ($tenant && $tenant->is_active) {
                $token = $tenantUser->createToken('mobile-app')->plainTextToken;
                
                return response()->json([
                    'success' => true,
                    'token' => $token,
                    'user' => [
                        'id' => $tenantUser->id,
                        'name' => $tenantUser->name,
                        'email' => $tenantUser->email,
                        'role' => $tenantUser->role,
                        'tenant_id' => $tenantUser->tenant_id,
                        'tenant_name' => $tenant->name,
                    ],
                    'message' => 'Успешный вход в систему',
                ]);
            }
        }

        return response()->json([
            'success' => false,
            'message' => 'Неверные учетные данные',
        ], 401);
    }

    public function apiLogout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        
        return response()->json([
            'success' => true,
            'message' => 'Успешный выход из системы',
        ]);
    }
}
