<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\CustomerGroup;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index()
    {
        $user = auth()->guard('tenant')->user();
        $customers = Customer::with(['customerGroup'])
            ->where('tenant_id', $user->tenant_id)
            ->latest()
            ->paginate(20);

        return view('admin.customers.index', compact('customers'));
    }

    public function create()
    {
        $user = auth()->guard('tenant')->user();
        $customerGroups = CustomerGroup::where('tenant_id', $user->tenant_id)->active()->get();

        return view('admin.customers.create', compact('customerGroups'));
    }

    public function store(Request $request)
    {
        $user = auth()->guard('tenant')->user();
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'required|string|max:255',
            'address' => 'required|string',
            'city' => 'nullable|string|max:255',
            'customer_group_id' => 'nullable|exists:customer_groups,id',
        ]);

        Customer::create([
            'tenant_id' => $user->tenant_id,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'city' => $request->city,
            'customer_group_id' => $request->customer_group_id,
            'is_active' => true,
        ]);

        return redirect()->route('customers.index')->with('success', 'Customer created successfully.');
    }

    public function show(Customer $customer)
    {
        $this->authorize('view', $customer);
        
        $customer->load(['customerGroup', 'orders', 'commitments']);
        return view('admin.customers.show', compact('customer'));
    }

    public function edit(Customer $customer)
    {
        $this->authorize('update', $customer);
        
        $user = auth()->guard('tenant')->user();
        $customerGroups = CustomerGroup::where('tenant_id', $user->tenant_id)->active()->get();

        return view('admin.customers.edit', compact('customer', 'customerGroups'));
    }

    public function update(Request $request, Customer $customer)
    {
        $this->authorize('update', $customer);
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'required|string|max:255',
            'address' => 'required|string',
            'city' => 'nullable|string|max:255',
            'customer_group_id' => 'nullable|exists:customer_groups,id',
        ]);

        $customer->update($request->all());

        return redirect()->route('customers.index')->with('success', 'Customer updated successfully.');
    }

    public function destroy(Customer $customer)
    {
        $this->authorize('delete', $customer);
        
        $customer->delete();

        return redirect()->route('customers.index')->with('success', 'Customer deleted successfully.');
    }
} 