<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\ProductBrand;

class CheckBrandAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\Response)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\Response
     */
    public function handle(Request $request, Closure $next)
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return $next($request);
        }

        // If user has no brands assigned, they have access to all brands
        if (!$user->hasAnyBrandAssigned()) {
            return $next($request);
        }

        // Check if the request is for a specific brand
        $brandId = $request->route('brand') ?? $request->input('brand_id');
        
        if ($brandId) {
            if (!$user->hasBrandAccess($brandId)) {
                return response()->json([
                    'error' => 'У вас нет доступа к этому бренду'
                ], 403);
            }
        }

        return $next($request);
    }
} 