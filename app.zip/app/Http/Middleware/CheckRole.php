<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        $user = auth()->guard('tenant')->user();
        
        if (!$user) {
            return redirect()->route('login');
        }
        
        // Check if user has the required role
        $hasAccess = false;
        
        switch ($role) {
            case 'admin':
                // Allow superadmin and admin roles
                $hasAccess = $user->isAdmin();
                break;
            case 'operator':
                // Allow superadmin, admin, and operator roles
                $hasAccess = $user->isOperator();
                break;
            case 'manager':
                // Allow superadmin, admin, operator, and manager roles
                $hasAccess = $user->isManager();
                break;
            default:
                // For other roles, do exact match
                $hasAccess = $user->role === $role;
                break;
        }
        
        if (!$hasAccess) {
            // Log the access attempt for debugging
            \Log::warning('Access denied', [
                'user_id' => $user->id,
                'user_role' => $user->role,
                'required_role' => $role,
                'url' => $request->url(),
                'is_admin' => $user->isAdmin(),
                'is_operator' => $user->isOperator(),
                'is_manager' => $user->isManager()
            ]);
            
            abort(403, 'Unauthorized access. Required role: ' . $role . ', User role: ' . $user->role);
        }
        
        return $next($request);
    }
}
