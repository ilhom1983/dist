<?php

namespace App\Policies;

use App\Models\Order;
use App\Models\TenantUser;
use Illuminate\Auth\Access\HandlesAuthorization;

class OrderPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(TenantUser $user)
    {
        // Allow all authenticated tenant users to view orders
        return true;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(TenantUser $user, Order $order)
    {
        // Check tenant access - all users can view orders from their tenant        return $user->tenant_id === $order->tenant_id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(TenantUser $user)
    {
        return $user->isAdmin() || $user->isOperator();
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(TenantUser $user, Order $order)
    {
        $result = $user->tenant_id === $order->tenant_id && ($user->isAdmin() || $user->isOperator());
        \Log::info('OrderPolicy::update', [
            'user_id' => $user->id,
            'user_tenant_id' => $user->tenant_id,
            'user_role' => $user->role,
            'is_admin' => $user->isAdmin(),
            'is_operator' => $user->isOperator(),
            'order_id' => $order->id,
            'order_tenant_id' => $order->tenant_id,
            'result' => $result
        ]);
        return $result;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(TenantUser $user, Order $order)
    {
        return $user->tenant_id === $order->tenant_id && $user->isAdmin();
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(TenantUser $user, Order $order)
    {
        return $user->tenant_id === $order->tenant_id && $user->isAdmin();
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(TenantUser $user, Order $order)
    {
        return $user->tenant_id === $order->tenant_id && $user->isAdmin();
    }
}
