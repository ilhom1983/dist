<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Брендами - {{ auth()->guard('tenant')->user()->tenant->name }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="brandsData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Брендами</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.brands.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                        <i class="fas fa-plus mr-2"></i>Добавить Бренд
                    </a>
                    <span class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Analytics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Брендов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $brands->total() }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-tag"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Активных</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $brands->where('is_active', true)->count() }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">С Товарами</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $brands->where('products_count', '>', 0)->count() }}</p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-box"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Без Товаров</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $brands->where('products_count', 0)->count() }}</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <input type="text" 
                           x-model="search" 
                           @input="filterBrands()"
                           placeholder="Поиск по названию бренда..." 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div class="flex gap-2">
                    <select x-model="statusFilter" @change="filterBrands()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все статусы</option>
                        <option value="active">Активные</option>
                        <option value="inactive">Неактивные</option>
                    </select>
                    <select x-model="sortBy" @change="filterBrands()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="name">По названию</option>
                        <option value="products_count">По количеству товаров</option>
                        <option value="created_at">По дате создания</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Brands Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Список Брендов</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Бренд</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Товары</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Статус</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Создан</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Действия</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200" x-ref="brandsTable">
                        @forelse($brands as $brand)
                        <tr class="brand-row hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    @if($brand->logo)
                                        <img class="h-10 w-10 rounded-full object-cover mr-3" src="{{ asset('storage/' . $brand->logo) }}" alt="{{ $brand->name }}">
                                    @else
                                        <div class="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                                            <i class="fas fa-tag text-gray-600"></i>
                                        </div>
                                    @endif
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">{{ $brand->name }}</div>
                                        @if($brand->description)
                                            <div class="text-sm text-gray-500">{{ Str::limit($brand->description, 50) }}</div>
                                        @endif
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    {{ $brand->products_count }} товаров
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    @if($brand->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    {{ $brand->is_active ? 'Активный' : 'Неактивный' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $brand->created_at->format('d.m.Y') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex items-center justify-end space-x-2">
                                    <a href="{{ route('admin.brands.show', $brand) }}" class="text-blue-600 hover:text-blue-900" title="Просмотр">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('admin.brands.edit', $brand) }}" class="text-indigo-600 hover:text-indigo-900" title="Редактировать">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button @click="deleteBrand({{ $brand->id }}, '{{ $brand->name }}')" class="text-red-600 hover:text-red-900" title="Удалить">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                                <i class="fas fa-tag text-4xl mb-4"></i>
                                <p class="text-lg">Нет брендов</p>
                                <p class="text-sm">Создайте первый бренд для начала работы</p>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            @if($brands->hasPages())
            <div class="px-6 py-4 border-t border-gray-200">
                {{ $brands->links() }}
            </div>
            @endif
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                    <i class="fas fa-exclamation-triangle text-red-600"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mt-4">Удалить бренд?</h3>
                <div class="mt-2 px-7 py-3">
                    <p class="text-sm text-gray-500">
                        Вы уверены, что хотите удалить бренд "<span x-text="brandToDelete"></span>"?
                        Это действие нельзя отменить.
                    </p>
                </div>
                <div class="flex justify-center space-x-4 mt-4">
                    <button @click="showDeleteModal = false" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Отмена
                    </button>
                    <button @click="confirmDelete()" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                        Удалить
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function brandsData() {
            return {
                search: '',
                statusFilter: '',
                sortBy: 'name',
                showDeleteModal: false,
                brandToDelete: '',
                brandToDeleteId: null,
                
                filterBrands() {
                    // Client-side filtering logic
                    const rows = this.$refs.brandsTable.querySelectorAll('.brand-row');
                    rows.forEach(row => {
                        const name = row.querySelector('td:first-child').textContent.toLowerCase();
                        const status = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                        
                        const matchesSearch = !this.search || name.includes(this.search.toLowerCase());
                        const matchesStatus = !this.statusFilter || 
                            (this.statusFilter === 'active' && status.includes('активный')) ||
                            (this.statusFilter === 'inactive' && status.includes('неактивный'));
                        
                        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
                    });
                },
                
                deleteBrand(id, name) {
                    this.brandToDelete = name;
                    this.brandToDeleteId = id;
                    this.showDeleteModal = true;
                },
                
                confirmDelete() {
                    if (this.brandToDeleteId) {
                        fetch(`/admin/brands/${this.brandToDeleteId}`, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Accept': 'application/json',
                            },
                        }).then(response => {
                            if (response.ok) {
                                window.location.reload();
                            } else {
                                alert('Ошибка при удалении бренда');
                            }
                        });
                    }
                    this.showDeleteModal = false;
                }
            }
        }
    </script>
</body>
</html> 