@extends('layouts.admin')

@section('title', 'Детали Товара')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Детали Товара</h1>
            <p class="text-gray-600 mt-2">Подробная информация о товаре</p>
        </div>
        <div class="flex space-x-3">
            <a href="{{ route('admin.products.edit', $product) }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                <i class="fas fa-edit mr-2"></i>Редактировать
            </a>
            <a href="{{ route('admin.products.index') }}" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>Назад
            </a>
        </div>
    </div>

    <!-- Product Info Cards -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <!-- Basic Info -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Основная Информация</h3>
            <div class="space-y-3">
                <div>
                    <label class="text-sm font-medium text-gray-500">Название</label>
                    <p class="text-gray-900">{{ $product->name }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">SKU</label>
                    <p class="text-gray-900">{{ $product->sku ?? 'Не указан' }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Штрих-код</label>
                    <p class="text-gray-900">{{ $product->barcode ?? 'Не указан' }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Описание</label>
                    <p class="text-gray-900">{{ $product->description ?? 'Не указано' }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Статус</label>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        {{ $product->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                        {{ $product->is_active ? 'Активен' : 'Неактивен' }}
                    </span>
                </div>
            </div>
        </div>

        <!-- Pricing -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Ценообразование</h3>
            <div class="space-y-3">
                <div>
                    <label class="text-sm font-medium text-gray-500">Текущая цена</label>
                    <p class="text-lg font-semibold text-gray-900">{{ number_format($product->price, 0, ',', ' ') }} Сум</p>
                </div>
                @if($product->old_price)
                    <div>
                        <label class="text-sm font-medium text-gray-500">Старая цена</label>
                        <p class="text-gray-500 line-through">{{ number_format($product->old_price, 0, ',', ' ') }} Сум</p>
                    </div>
                @endif
                @if($product->cost_price)
                    <div>
                        <label class="text-sm font-medium text-gray-500">Себестоимость</label>
                        <p class="text-gray-900">{{ number_format($product->cost_price, 0, ',', ' ') }} Сум</p>
                    </div>
                @endif
                @if($product->old_price && $product->price)
                    <div>
                        <label class="text-sm font-medium text-gray-500">Скидка</label>
                        @php
                            $discount = (($product->old_price - $product->price) / $product->old_price) * 100;
                        @endphp
                        <p class="text-green-600 font-medium">{{ number_format($discount, 1) }}%</p>
                    </div>
                @endif
            </div>
        </div>

        <!-- Inventory -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Складской учет</h3>
            <div class="space-y-3">
                <div>
                    <label class="text-sm font-medium text-gray-500">Количество на складе</label>
                    <p class="text-lg font-semibold text-gray-900">{{ $product->stock_quantity ?? 0 }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Минимальный запас</label>
                    <p class="text-gray-900">{{ $product->min_stock ?? 0 }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Отслеживание остатков</label>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        {{ $product->track_stock ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ $product->track_stock ? 'Включено' : 'Отключено' }}
                    </span>
                </div>
                @if($product->track_stock && $product->stock_quantity <= $product->min_stock)
                    <div class="bg-red-50 border border-red-200 rounded-lg p-3">
                        <p class="text-red-800 text-sm font-medium">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            Низкий запас! Требуется пополнение.
                        </p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Product Image and Details -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Product Image -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Изображение товара</h3>
            @if($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" 
                     class="w-full h-64 object-cover rounded-lg">
            @else
                <div class="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                    <div class="text-center">
                        <i class="fas fa-image text-gray-400 text-4xl mb-2"></i>
                        <p class="text-gray-500">Изображение не загружено</p>
                    </div>
                </div>
            @endif
        </div>

        <!-- Classification -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Классификация</h3>
            <div class="space-y-3">
                <div>
                    <label class="text-sm font-medium text-gray-500">Бренд</label>
                    @if($product->brand)
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {{ $product->brand->name }}
                        </span>
                    @else
                        <p class="text-gray-500">Не указан</p>
                    @endif
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Категория</label>
                    @if($product->category)
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            {{ $product->category->name }}
                        </span>
                    @else
                        <p class="text-gray-500">Не указана</p>
                    @endif
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Рекомендуемый</label>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        {{ $product->is_featured ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ $product->is_featured ? 'Да' : 'Нет' }}
                    </span>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">На распродаже</label>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        {{ $product->is_on_sale ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800' }}">
                        {{ $product->is_on_sale ? 'Да' : 'Нет' }}
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Information -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Physical Properties -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Физические характеристики</h3>
            <div class="space-y-3">
                <div>
                    <label class="text-sm font-medium text-gray-500">Вес</label>
                    <p class="text-gray-900">{{ $product->weight ? $product->weight . ' кг' : 'Не указан' }}</p>
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-500">Размеры</label>
                    <p class="text-gray-900">{{ $product->dimensions ?? 'Не указаны' }}</p>
                </div>
            </div>
        </div>

        <!-- Notes -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Заметки</h3>
            <div>
                @if($product->notes)
                    <p class="text-gray-700">{{ $product->notes }}</p>
                @else
                    <p class="text-gray-500">Заметки отсутствуют</p>
                @endif
            </div>
        </div>
    </div>

    <!-- Timestamps -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Системная информация</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-medium text-gray-500">Дата создания</label>
                <p class="text-gray-900">{{ $product->created_at->format('d.m.Y H:i') }}</p>
            </div>
            <div>
                <label class="text-sm font-medium text-gray-500">Последнее обновление</label>
                <p class="text-gray-900">{{ $product->updated_at->format('d.m.Y H:i') }}</p>
            </div>
        </div>
    </div>
</div>
@endsection 