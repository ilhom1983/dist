@extends("layouts.admin")

@section("content")
<div class="py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="md:flex md:items-center md:justify-between">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Edit Salary Payment
                </h2>
            </div>
        </div>

        <div class="mt-8">
            <div class="bg-white shadow sm:rounded-lg">
                <form method="POST" action="{{ route("admin.salaries.update", $salaryPayment) }}" class="px-4 py-5 sm:p-6">
                    @csrf
                    @method("PUT")
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="tenant_user_id" class="block text-sm font-medium text-gray-700">Employee</label>
                            <select id="tenant_user_id" name="tenant_user_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ $salaryPayment->tenant_user_id == $user->id ? "selected" : "" }}>{{ $user->name }} ({{ $user->role }})</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="month" class="block text-sm font-medium text-gray-700">Month</label>
                            <input type="month" id="month" name="month" value="{{ $salaryPayment->month }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="base_salary" class="block text-sm font-medium text-gray-700">Base Salary</label>
                            <input type="number" step="0.01" id="base_salary" name="base_salary" value="{{ $salaryPayment->base_salary }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="commission" class="block text-sm font-medium text-gray-700">Commission</label>
                            <input type="number" step="0.01" id="commission" name="commission" value="{{ $salaryPayment->commission }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="bonus" class="block text-sm font-medium text-gray-700">Bonus</label>
                            <input type="number" step="0.01" id="bonus" name="bonus" value="{{ $salaryPayment->bonus }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="deductions" class="block text-sm font-medium text-gray-700">Deductions</label>
                            <input type="number" step="0.01" id="deductions" name="deductions" value="{{ $salaryPayment->deductions }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="total_amount" class="block text-sm font-medium text-gray-700">Total Amount</label>
                            <input type="number" step="0.01" id="total_amount" name="total_amount" value="{{ $salaryPayment->total_amount }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="payment_date" class="block text-sm font-medium text-gray-700">Payment Date</label>
                            <input type="date" id="payment_date" name="payment_date" value="{{ $salaryPayment->payment_date ? $salaryPayment->payment_date->format("Y-m-d") : "" }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                            <select id="status" name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="pending" {{ $salaryPayment->status === "pending" ? "selected" : "" }}>Pending</option>
                                <option value="paid" {{ $salaryPayment->status === "paid" ? "selected" : "" }}>Paid</option>
                                <option value="cancelled" {{ $salaryPayment->status === "cancelled" ? "selected" : "" }}>Cancelled</option>
                            </select>
                        </div>

                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700">Notes</label>
                            <textarea id="notes" name="notes" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">{{ $salaryPayment->notes }}</textarea>
                        </div>
                    </div>

                    <div class="mt-6 flex items-center justify-end space-x-3">
                        <a href="{{ route("admin.salaries.show", $salaryPayment) }}" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Cancel
                        </a>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Update Salary Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
