<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать Выплату Зарплаты - {{ $tenantName }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="salaryForm()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.salaries.index') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Зарплатам
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Создать Выплату Зарплаты</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <form action="{{ route('admin.salaries.store') }}" method="POST" @submit="validateForm">
                @csrf
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Employee Selection -->
                    <div>
                        <label for="tenant_user_id" class="block text-sm font-medium text-gray-700 mb-2">
                            Сотрудник <span class="text-red-500">*</span>
                        </label>
                        <select id="tenant_user_id" name="tenant_user_id" required
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">Выберите сотрудника</option>
                            @foreach($employees as $employee)
                                <option value="{{ $employee->id }}">{{ $employee->name }} ({{ $employee->role }})</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Month -->
                    <div>
                        <label for="month" class="block text-sm font-medium text-gray-700 mb-2">
                            Месяц <span class="text-red-500">*</span>
                        </label>
                        <input type="month" id="month" name="month" required
                               value="{{ now()->format('Y-m') }}"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Base Salary -->
                    <div>
                        <label for="base_salary" class="block text-sm font-medium text-gray-700 mb-2">
                            Базовая Зарплата (Сум) <span class="text-red-500">*</span>
                        </label>
                        <input type="number" id="base_salary" name="base_salary" required min="0" step="1000"
                               x-model="baseSalary" @input="calculateTotal"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Commission Amount -->
                    <div>
                        <label for="commission_amount" class="block text-sm font-medium text-gray-700 mb-2">
                            Комиссия (Сум)
                        </label>
                        <input type="number" id="commission_amount" name="commission_amount" min="0" step="1000"
                               x-model="commissionAmount" @input="calculateTotal"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Bonus Amount -->
                    <div>
                        <label for="bonus_amount" class="block text-sm font-medium text-gray-700 mb-2">
                            Бонус (Сум)
                        </label>
                        <input type="number" id="bonus_amount" name="bonus_amount" min="0" step="1000"
                               x-model="bonusAmount" @input="calculateTotal"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Deductions -->
                    <div>
                        <label for="deductions" class="block text-sm font-medium text-gray-700 mb-2">
                            Вычеты (Сум)
                        </label>
                        <input type="number" id="deductions" name="deductions" min="0" step="1000"
                               x-model="deductions" @input="calculateTotal"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Payment Date -->
                    <div>
                        <label for="payment_date" class="block text-sm font-medium text-gray-700 mb-2">
                            Дата Выплаты
                        </label>
                        <input type="date" id="payment_date" name="payment_date"
                               value="{{ now()->format('Y-m-d') }}"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                </div>

                <!-- Total Amount Display -->
                <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                    <div class="flex justify-between items-center">
                        <span class="text-lg font-medium text-gray-700">Итого к выплате:</span>
                        <span class="text-2xl font-bold text-green-600" x-text="formatCurrency(totalAmount)">0 Сум</span>
                    </div>
                </div>

                <!-- Notes -->
                <div class="mt-6">
                    <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">
                        Примечания
                    </label>
                    <textarea id="notes" name="notes" rows="3"
                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Дополнительная информация о выплате..."></textarea>
                </div>

                <!-- Form Actions -->
                <div class="mt-8 flex justify-end space-x-4">
                    <a href="{{ route('admin.salaries.index') }}" 
                       class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        Отмена
                    </a>
                    <button type="submit" 
                            class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        Создать Выплату
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function salaryForm() {
            return {
                baseSalary: 0,
                commissionAmount: 0,
                bonusAmount: 0,
                deductions: 0,
                totalAmount: 0,
                
                calculateTotal() {
                    this.totalAmount = parseFloat(this.baseSalary || 0) + 
                                      parseFloat(this.commissionAmount || 0) + 
                                      parseFloat(this.bonusAmount || 0) - 
                                      parseFloat(this.deductions || 0);
                },
                
                formatCurrency(amount) {
                    return new Intl.NumberFormat('ru-RU').format(amount) + ' Сум';
                },
                
                validateForm(event) {
                    if (!this.baseSalary || this.baseSalary <= 0) {
                        event.preventDefault();
                        alert('Базовая зарплата должна быть больше 0');
                        return false;
                    }
                    
                    if (this.totalAmount < 0) {
                        event.preventDefault();
                        alert('Итоговая сумма не может быть отрицательной');
                        return false;
                    }
                    
                    return true;
                }
            }
        }
    </script>
</body>
</html> 