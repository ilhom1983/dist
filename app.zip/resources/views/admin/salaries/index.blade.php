<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Зарплатами - {{ $tenantName }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body class="bg-gray-50" x-data="salaryData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Зарплатами</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <button @click="showCalculationModal = true" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                        <i class="fas fa-calculator mr-2"></i>Рассчитать Зарплаты
                    </button>
                    <a href="{{ route('admin.salaries.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                        <i class="fas fa-plus mr-2"></i>Добавить Зарплату
                    </a>
                    <span class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Analytics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Выплат</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['total_payments'] }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-money-bill"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Этот Месяц</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['this_month_payments'] }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-calendar"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Общая Сумма</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_amount'], 0) }} Сум</p>
                    </div>
                    <div class="text-emerald-500 text-3xl">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Ожидают Выплаты</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['pending_payments'] }}</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <input type="text" 
                           x-model="search" 
                           @input="filterSalaries()"
                           placeholder="Поиск по сотруднику..." 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div class="flex gap-2">
                    <select x-model="statusFilter" @change="filterSalaries()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все статусы</option>
                        <option value="paid">Выплачено</option>
                        <option value="pending">Ожидает</option>
                    </select>
                    <select x-model="monthFilter" @change="filterSalaries()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все месяцы</option>
                        @foreach(range(0, 11) as $i)
                            @php $date = now()->subMonths($i); @endphp
                            <option value="{{ $date->format('Y-m') }}">{{ $date->format('M Y') }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <!-- Salary Payments Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Выплаты Зарплат</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Сотрудник</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Месяц</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Базовая Зарплата</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Комиссия</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Бонус</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Вычеты</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Итого</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Статус</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Дата Выплаты</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Действия</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200" x-ref="salaryTable">
                        @forelse($salaryPayments as $salary)
                        <tr class="salary-row hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-bold mr-3">
                                        {{ strtoupper(substr($salary->tenantUser->name ?? 'С', 0, 2)) }}
                                    </div>
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">{{ $salary->tenantUser->name ?? 'Сотрудник' }}</div>
                                        <div class="text-sm text-gray-500">{{ $salary->tenantUser->role ?? 'Роль' }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ \Carbon\Carbon::createFromFormat('Y-m', $salary->month)->format('M Y') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ number_format($salary->base_salary, 0) }} Сум
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ number_format($salary->commission_amount, 0) }} Сум
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ number_format($salary->bonus_amount, 0) }} Сум
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ number_format($salary->deductions, 0) }} Сум
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="text-sm font-medium text-gray-900">{{ number_format($salary->total_amount, 0) }} Сум</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    @if($salary->status === 'paid') bg-green-100 text-green-800 @else bg-yellow-100 text-yellow-800 @endif">
                                    {{ $salary->status === 'paid' ? 'Выплачено' : 'Ожидает' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $salary->payment_date ? $salary->payment_date->format('d.m.Y') : '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex items-center justify-end space-x-2">
                                    <a href="{{ route('admin.salaries.show', $salary) }}" class="text-blue-600 hover:text-blue-900" title="Просмотр">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('admin.salaries.edit', $salary) }}" class="text-indigo-600 hover:text-indigo-900" title="Редактировать">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button @click="deleteSalary({{ $salary->id }}, '{{ $salary->tenantUser->name ?? 'Сотрудник' }}')" class="text-red-600 hover:text-red-900" title="Удалить">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="px-6 py-12 text-center text-gray-500">
                                <i class="fas fa-money-bill text-4xl mb-4"></i>
                                <p class="text-lg">Нет выплат зарплат</p>
                                <p class="text-sm">Создайте первую выплату для начала работы</p>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            @if($salaryPayments->hasPages())
            <div class="px-6 py-4 border-t border-gray-200">
                {{ $salaryPayments->links() }}
            </div>
            @endif
        </div>
    </div>

    <!-- Salary Calculation Modal -->
    <div x-show="showCalculationModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-11/12 max-w-4xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-medium text-gray-900">Массовый Расчет Зарплат</h3>
                    <button @click="showCalculationModal = false" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <!-- Calculation Form -->
                <div class="mb-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Месяц для расчета</label>
                            <input type="month" x-model="calculationMonth" 
                                   value="{{ now()->format('Y-m') }}"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Дата выплаты</label>
                            <input type="date" x-model="paymentDate" 
                                   value="{{ now()->format('Y-m-d') }}"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Настройки расчета</label>
                        <div class="space-y-2">
                            <label class="flex items-center">
                                <input type="checkbox" x-model="includeAttendanceBonus" class="mr-2">
                                <span class="text-sm">Включить бонус за посещаемость</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" x-model="includeOvertimeBonus" class="mr-2">
                                <span class="text-sm">Включить бонус за сверхурочные</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" x-model="includeTaxDeductions" class="mr-2">
                                <span class="text-sm">Включить налоговые вычеты</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Calculation Results -->
                <div x-show="calculationResults.length > 0" class="mb-6">
                    <h4 class="text-md font-medium text-gray-900 mb-3">Результаты расчета:</h4>
                    <div class="max-h-64 overflow-y-auto border border-gray-200 rounded-lg">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Сотрудник</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Роль</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Базовая</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Комиссия</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Бонус</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Вычеты</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Итого</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <template x-for="result in calculationResults" :key="result.user_id">
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-4 py-2 text-sm text-gray-900" x-text="result.employee_name"></td>
                                        <td class="px-4 py-2 text-sm text-gray-500" x-text="result.role"></td>
                                        <td class="px-4 py-2 text-sm text-gray-900" x-text="formatCurrency(result.base_salary)"></td>
                                        <td class="px-4 py-2 text-sm text-gray-900" x-text="formatCurrency(result.commission_amount)"></td>
                                        <td class="px-4 py-2 text-sm text-gray-900" x-text="formatCurrency(result.bonus_amount)"></td>
                                        <td class="px-4 py-2 text-sm text-gray-900" x-text="formatCurrency(result.deductions)"></td>
                                        <td class="px-4 py-2 text-sm font-medium text-gray-900" x-text="formatCurrency(result.total_amount)"></td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex justify-end space-x-3">
                    <button @click="showCalculationModal = false" class="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50">
                        Отмена
                    </button>
                    <button @click="calculateSalaries()" 
                            :disabled="isCalculating"
                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50">
                        <span x-show="!isCalculating">Рассчитать</span>
                        <span x-show="isCalculating">
                            <i class="fas fa-spinner fa-spin mr-2"></i>Расчет...
                        </span>
                    </button>
                    <button @click="createSalaryPayments()" 
                            x-show="calculationResults.length > 0"
                            :disabled="isCreating"
                            class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50">
                        <span x-show="!isCreating">Создать Выплаты</span>
                        <span x-show="isCreating">
                            <i class="fas fa-spinner fa-spin mr-2"></i>Создание...
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                    <i class="fas fa-exclamation-triangle text-red-600"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mt-4">Удалить выплату?</h3>
                <div class="mt-2 px-7 py-3">
                    <p class="text-sm text-gray-500">
                        Вы уверены, что хотите удалить выплату для "<span x-text="salaryToDelete"></span>"?
                        Это действие нельзя отменить.
                    </p>
                </div>
                <div class="flex justify-center space-x-4 mt-4">
                    <button @click="showDeleteModal = false" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Отмена
                    </button>
                    <button @click="confirmDelete()" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                        Удалить
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function salaryData() {
            return {
                search: '',
                statusFilter: '',
                monthFilter: '',
                showDeleteModal: false,
                showCalculationModal: false,
                salaryToDelete: '',
                salaryToDeleteId: null,
                calculationMonth: '{{ now()->format("Y-m") }}',
                paymentDate: '{{ now()->format("Y-m-d") }}',
                includeAttendanceBonus: true,
                includeOvertimeBonus: true,
                includeTaxDeductions: true,
                calculationResults: [],
                isCalculating: false,
                isCreating: false,
                
                filterSalaries() {
                    // Client-side filtering logic
                    const rows = this.$refs.salaryTable.querySelectorAll('.salary-row');
                    rows.forEach(row => {
                        const employeeName = row.querySelector('td:first-child').textContent.toLowerCase();
                        const status = row.querySelector('td:nth-child(8)').textContent.toLowerCase();
                        const month = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                        
                        const matchesSearch = !this.search || employeeName.includes(this.search.toLowerCase());
                        const matchesStatus = !this.statusFilter || 
                            (this.statusFilter === 'paid' && status.includes('выплачено')) ||
                            (this.statusFilter === 'pending' && status.includes('ожидает'));
                        const matchesMonth = !this.monthFilter || month.includes(this.monthFilter.toLowerCase());
                        
                        row.style.display = matchesSearch && matchesStatus && matchesMonth ? '' : 'none';
                    });
                },
                
                deleteSalary(id, name) {
                    this.salaryToDelete = name;
                    this.salaryToDeleteId = id;
                    this.showDeleteModal = true;
                },
                
                confirmDelete() {
                    if (this.salaryToDeleteId) {
                        fetch(`/admin/salaries/${this.salaryToDeleteId}`, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Accept': 'application/json',
                            },
                        }).then(response => {
                            if (response.ok) {
                                window.location.reload();
                            } else {
                                alert('Ошибка при удалении выплаты');
                            }
                        });
                    }
                    this.showDeleteModal = false;
                },

                calculateSalaries() {
                    this.isCalculating = true;
                    
                    fetch('/admin/salaries/calculate-all', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                            'Accept': 'application/json',
                        },
                        body: JSON.stringify({
                            month: this.calculationMonth,
                            include_attendance_bonus: this.includeAttendanceBonus,
                            include_overtime_bonus: this.includeOvertimeBonus,
                            include_tax_deductions: this.includeTaxDeductions,
                        }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        this.isCalculating = false;
                        if (data.success) {
                            this.calculationResults = data.results;
                        } else {
                            alert('Ошибка при расчете: ' + data.message);
                        }
                    })
                    .catch(error => {
                        this.isCalculating = false;
                        alert('Ошибка при расчете зарплат');
                        console.error('Error:', error);
                    });
                },

                createSalaryPayments() {
                    this.isCreating = true;
                    
                    fetch('/admin/salaries/create-all', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                            'Accept': 'application/json',
                        },
                        body: JSON.stringify({
                            month: this.calculationMonth,
                            payment_date: this.paymentDate,
                            results: this.calculationResults,
                        }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        this.isCreating = false;
                        if (data.success) {
                            alert('Выплаты успешно созданы!');
                            window.location.reload();
                        } else {
                            alert('Ошибка при создании выплат: ' + data.message);
                        }
                    })
                    .catch(error => {
                        this.isCreating = false;
                        alert('Ошибка при создании выплат');
                        console.error('Error:', error);
                    });
                },

                formatCurrency(amount) {
                    return new Intl.NumberFormat('ru-RU').format(amount) + ' Сум';
                }
            }
        }
    </script>
</body>
</html> 