@extends("layouts.admin")

@section("content")
<div class="py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="md:flex md:items-center md:justify-between">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Edit Delivery #{{ $delivery->id }}
                </h2>
            </div>
        </div>

        <div class="mt-8">
            <div class="bg-white shadow sm:rounded-lg">
                <form method="POST" action="{{ route("admin.deliveries.update", $delivery) }}" class="px-4 py-5 sm:p-6">
                    @csrf
                    @method("PUT")
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="order_id" class="block text-sm font-medium text-gray-700">Order</label>
                            <select id="order_id" name="order_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                @foreach($orders as $order)
                                    <option value="{{ $order->id }}" {{ $delivery->order_id == $order->id ? "selected" : "" }}>Order #{{ $order->id }} - {{ $order->customer->name ?? "Unknown" }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="delivery_user_id" class="block text-sm font-medium text-gray-700">Delivery User</label>
                            <select id="delivery_user_id" name="delivery_user_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="">Select delivery user</option>
                                @foreach($deliveryUsers as $user)
                                    <option value="{{ $user->id }}" {{ $delivery->delivery_user_id == $user->id ? "selected" : "" }}>{{ $user->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="delivery_date" class="block text-sm font-medium text-gray-700">Delivery Date</label>
                            <input type="date" id="delivery_date" name="delivery_date" value="{{ $delivery->delivery_date ? $delivery->delivery_date->format("Y-m-d") : "" }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="delivery_time" class="block text-sm font-medium text-gray-700">Delivery Time</label>
                            <input type="time" id="delivery_time" name="delivery_time" value="{{ $delivery->delivery_time }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                            <select id="status" name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="scheduled" {{ $delivery->status === "scheduled" ? "selected" : "" }}>Scheduled</option>
                                <option value="in_progress" {{ $delivery->status === "in_progress" ? "selected" : "" }}>In Progress</option>
                                <option value="delivered" {{ $delivery->status === "delivered" ? "selected" : "" }}>Delivered</option>
                                <option value="failed" {{ $delivery->status === "failed" ? "selected" : "" }}>Failed</option>
                            </select>
                        </div>

                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700">Notes</label>
                            <textarea id="notes" name="notes" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">{{ $delivery->notes }}</textarea>
                        </div>
                    </div>

                    <div class="mt-6 flex items-center justify-end space-x-3">
                        <a href="{{ route("admin.deliveries.show", $delivery) }}" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Cancel
                        </a>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Update Delivery
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
