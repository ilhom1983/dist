<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель Администратора - {{ $tenant->name }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .status-healthy { background-color: #10b981; }
        .status-warning { background-color: #f59e0b; }
        .status-error { background-color: #ef4444; }
    </style>
</head>
<body class="bg-gray-50" x-data="dashboardData()">
    <!-- Navigation Header -->
    <nav class="gradient-bg text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-building text-2xl"></i>
                    <div>
                        <h1 class="text-2xl font-bold">{{ $tenant->name }}</h1>
                        <p class="text-sm opacity-90">Панель Администратора</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2">
                        <span class="status-indicator status-healthy"></span>
                        <span class="text-sm">Система Онлайн</span>
                    </div>
                    <div class="text-sm">
                        <span x-text="new Date().toLocaleTimeString()"></span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-sm">{{ auth()->guard('tenant')->user()->name }}</span>
                        <form action="{{ route('logout') }}" method="POST" class="inline">
                            @csrf
                            <button type="submit" class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                                <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Quick Actions -->
        <div class="mb-8">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Быстрые Действия</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                @foreach($quickActions as $action)
                <a href="{{ $action['url'] }}" class="bg-white rounded-lg shadow-md p-4 text-center card-hover">
                    <div class="text-2xl mb-2">
                        <i class="fas fa-{{ $action['icon'] }} text-{{ $action['color'] }}-500"></i>
                    </div>
                    <div class="text-sm font-medium text-gray-700">{{ $action['title'] }}</div>
                </a>
                @endforeach
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Total Orders -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Заказов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_orders']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $realtimeMetrics['pending_orders'] }} ожидают
                        </p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>

            <!-- Active Orders -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Активные Заказы</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['active_orders']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-check mr-1"></i>В работе
                        </p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>

            <!-- Cancelled Orders -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Отмененные Заказы</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['cancelled_orders']) }}</p>
                        <p class="text-sm text-red-600 mt-1">
                            <i class="fas fa-times mr-1"></i>За последние 12 месяцев
                        </p>
                    </div>
                    <div class="text-red-500 text-3xl">
                        <i class="fas fa-times-circle"></i>
                    </div>
                </div>
            </div>

            <!-- Returned Orders -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Возвраты</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['returned_orders']) }}</p>
                        <p class="text-sm text-orange-600 mt-1">
                            <i class="fas fa-undo mr-1"></i>За последние 12 месяцев
                        </p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-undo"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Additional Metrics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <!-- Total Revenue -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Общий Доход</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_revenue'], 0) }} Сум</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ number_format($realtimeMetrics['revenue_growth'], 1) }}% в этом месяце
                        </p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>

            <!-- Total Customers -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Клиентов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_customers']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $recentCustomers->count() }} новых
                        </p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <!-- Total Products -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Товаров</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_products']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $topProducts->count() }} популярных
                        </p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-box"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts and Analytics -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Sales Trends Chart -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Тренды Продаж</h3>
                <canvas id="salesChart" width="400" height="200"></canvas>
            </div>

            <!-- System Health -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Состояние Системы</h3>
                <div class="space-y-4">
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">База Данных</span>
                        <div class="flex items-center">
                            <span class="status-indicator status-healthy"></span>
                            <span class="text-sm text-green-600">{{ $systemHealth['database_status']['response_time'] }}ms</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">API Сервисы</span>
                        <div class="flex items-center">
                            <span class="status-indicator status-healthy"></span>
                            <span class="text-sm text-green-600">Все Активны</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Использование Хранилища</span>
                        <div class="flex items-center">
                            <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: {{ $systemHealth['storage_usage']['percentage'] }}%"></div>
                            </div>
                            <span class="text-sm text-gray-600">{{ $systemHealth['storage_usage']['percentage'] }}%</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Время Работы</span>
                        <span class="text-sm text-green-600">{{ $systemHealth['uptime']['current'] }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders and Top Products -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Recent Orders -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Последние Заказы</h3>
                <div class="space-y-3">
                    @forelse($recentOrders->take(5) as $order)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                #{{ $order->id }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $order->customer->name ?? 'Клиент' }}</p>
                                <p class="text-sm text-gray-600">{{ $order->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($order->total_amount ?? 0, 0) }} Сум</p>
                            <p class="text-sm text-gray-600">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                    @if($order->orderStatus && in_array($order->orderStatus->name, ['delivered', 'paid', 'closed'])) bg-green-100 text-green-800
                                    @elseif($order->orderStatus && in_array($order->orderStatus->name, ['pending', 'approved'])) bg-yellow-100 text-yellow-800
                                    @elseif($order->orderStatus && in_array($order->orderStatus->name, ['loaded'])) bg-blue-100 text-blue-800
                                    @elseif($order->orderStatus && in_array($order->orderStatus->name, ['cancelled', 'returned'])) bg-red-100 text-red-800
                                    @else bg-gray-100 text-gray-800 @endif">
                                    @if($order->orderStatus && $order->orderStatus->name === 'pending') Ожидает
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'approved') Одобрен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'cancelled') Отменен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'loaded') Загружен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'delivered') Доставлен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'paid') Оплачен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'returned') Возвращен
                                    @elseif($order->orderStatus && $order->orderStatus->name === 'closed') Закрыт
                                    @else {{ $order->orderStatus ? ucfirst($order->orderStatus->name) : 'Неизвестно' }}
                                    @endif
                                </span>
                            </p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-shopping-cart text-4xl mb-4"></i>
                        <p>Нет заказов</p>
                    </div>
                    @endforelse
                </div>
            </div>

            <!-- Top Products -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Популярные Товары</h3>
                <div class="space-y-3">
                    @forelse($topProducts as $product)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm">
                                <i class="fas fa-box"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $product->name }}</p>
                                <p class="text-sm text-gray-600">{{ $product->total_orders }} заказов</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($product->price ?? 0, 0) }} Сум</p>
                            <p class="text-sm text-gray-600">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                    @if($product->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    {{ $product->is_active ? 'Активный' : 'Неактивный' }}
                                </span>
                            </p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-box text-4xl mb-4"></i>
                        <p>Нет товаров</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Recent Customers and User Activity -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Recent Customers -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Новые Клиенты</h3>
                <div class="space-y-3">
                    @forelse($recentCustomers as $customer)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                {{ strtoupper(substr($customer->name ?? 'К', 0, 1)) }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $customer->name ?? 'Клиент' }}</p>
                                <p class="text-sm text-gray-600">{{ $customer->email ?? 'Нет email' }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ $customer->orders_count }} заказов</p>
                            <p class="text-sm text-gray-600">{{ $customer->created_at->diffForHumans() }}</p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-users text-4xl mb-4"></i>
                        <p>Нет клиентов</p>
                    </div>
                    @endforelse
                </div>
            </div>

            <!-- User Activity -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Активность Пользователей</h3>
                <div class="space-y-3">
                    @forelse($userActivity as $user)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                {{ strtoupper(substr($user->name, 0, 2)) }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $user->name }}</p>
                                <p class="text-sm text-gray-600">{{ $user->role ?? 'Пользователь' }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ $user->total_orders }} заказов</p>
                            <p class="text-sm text-gray-600">За неделю</p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-user-clock text-4xl mb-4"></i>
                        <p>Нет активности</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Cancelled and Returned Orders -->
        @if($stats['cancelled_orders'] > 0 || $stats['returned_orders'] > 0)
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Recent Cancelled Orders -->
            @if($stats['cancelled_orders'] > 0)
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-red-500">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">
                    <i class="fas fa-times-circle text-red-500 mr-2"></i>Отмененные Заказы
                </h3>
                <div class="space-y-3">
                    @php
                        $cancelledOrders = $recentOrders->where('orderStatus.name', 'cancelled')->take(5);
                    @endphp
                    @forelse($cancelledOrders as $order)
                    <div class="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                #{{ $order->id }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $order->customer->name ?? 'Клиент' }}</p>
                                <p class="text-sm text-gray-600">{{ $order->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($order->total_amount ?? 0, 0) }} Сум</p>
                            <p class="text-sm text-red-600">
                                <i class="fas fa-times mr-1"></i>Отменен
                            </p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-times-circle text-4xl mb-4 text-red-300"></i>
                        <p>Нет отмененных заказов</p>
                    </div>
                    @endforelse
                </div>
            </div>
            @endif

            <!-- Recent Returned Orders -->
            @if($stats['returned_orders'] > 0)
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">
                    <i class="fas fa-undo text-orange-500 mr-2"></i>Возвраты
                </h3>
                <div class="space-y-3">
                    @php
                        $returnedOrders = $recentOrders->where('orderStatus.name', 'returned')->take(5);
                    @endphp
                    @forelse($returnedOrders as $order)
                    <div class="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                #{{ $order->id }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $order->customer->name ?? 'Клиент' }}</p>
                                <p class="text-sm text-gray-600">{{ $order->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($order->total_amount ?? 0, 0) }} Сум</p>
                            <p class="text-sm text-orange-600">
                                <i class="fas fa-undo mr-1"></i>Возвращен
                            </p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-undo text-4xl mb-4 text-orange-300"></i>
                        <p>Нет возвратов</p>
                    </div>
                    @endforelse
                </div>
            </div>
            @endif
        </div>
        @endif

        <!-- Additional Sections -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Brands and Categories -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Бренды и Категории</h3>
                <div class="grid grid-cols-2 gap-4">
                    <!-- Brands -->
                    <div>
                        <h4 class="font-medium text-gray-700 mb-2">Бренды</h4>
                        <div class="space-y-2">
                            @forelse($brands as $brand)
                            <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                <span class="text-sm font-medium">{{ $brand->name }}</span>
                                <span class="text-xs text-gray-500">{{ $brand->products_count }} товаров</span>
                            </div>
                            @empty
                            <p class="text-sm text-gray-500">Нет брендов</p>
                            @endforelse
                        </div>
                    </div>
                    <!-- Categories -->
                    <div>
                        <h4 class="font-medium text-gray-700 mb-2">Категории</h4>
                        <div class="space-y-2">
                            @forelse($categories as $category)
                            <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                <span class="text-sm font-medium">{{ $category->name }}</span>
                                <span class="text-xs text-gray-500">{{ $category->products_count }} товаров</span>
                            </div>
                            @empty
                            <p class="text-sm text-gray-500">Нет категорий</p>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

            <!-- Deliveries -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Активные Доставки</h3>
                <div class="space-y-3">
                    @forelse($deliveries as $delivery)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm">
                                <i class="fas fa-truck"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">Заказ #{{ $delivery->order_number }}</p>
                                <p class="text-sm text-gray-600">{{ $delivery->customer->name ?? 'Клиент' }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-medium text-gray-800">{{ $delivery->deliveryUser->name ?? 'Не назначен' }}</p>
                            <p class="text-xs text-gray-600">{{ $delivery->orderStatus->name ?? 'Статус' }}</p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-truck text-4xl mb-4"></i>
                        <p>Нет активных доставок</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Payments and Salaries -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Recent Payments -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Последние Платежи</h3>
                <div class="space-y-3">
                    @forelse($payments as $payment)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center text-white text-sm">
                                <i class="fas fa-credit-card"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $payment->order->customer->name ?? 'Клиент' }}</p>
                                <p class="text-sm text-gray-600">{{ $payment->paymentMethod->name ?? 'Метод' }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($payment->amount, 0) }} Сум</p>
                            <p class="text-sm text-gray-600">{{ $payment->payment_date->diffForHumans() }}</p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-credit-card text-4xl mb-4"></i>
                        <p>Нет платежей</p>
                    </div>
                    @endforelse
                </div>
            </div>

            <!-- Recent Salaries -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Последние Зарплаты</h3>
                <div class="space-y-3">
                    @forelse($salaries as $salary)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white text-sm">
                                <i class="fas fa-money-bill"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $salary->employee->name ?? 'Сотрудник' }}</p>
                                <p class="text-sm text-gray-600">{{ $salary->payment_method ?? 'Метод' }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($salary->amount, 0) }} Сум</p>
                            <p class="text-sm text-gray-600">{{ $salary->payment_date->diffForHumans() }}</p>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-money-bill text-4xl mb-4"></i>
                        <p>Нет зарплат</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    <script>
        function dashboardData() {
            return {
                init() {
                    this.initCharts();
                    this.startAutoRefresh();
                },
                
                initCharts() {
                    const ctx = document.getElementById('salesChart').getContext('2d');
                    const salesData = @json($salesTrends);
                    
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: salesData.map(item => item.date),
                            datasets: [{
                                label: 'Доход (Сум)',
                                data: salesData.map(item => item.revenue),
                                borderColor: 'rgb(59, 130, 246)',
                                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                                tension: 0.4
                            }, {
                                label: 'Заказы',
                                data: salesData.map(item => item.orders),
                                borderColor: 'rgb(16, 185, 129)',
                                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'top',
                                },
                                title: {
                                    display: false
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                },
                
                startAutoRefresh() {
                    setInterval(() => {
                        // Auto refresh every 30 seconds
                        // You can add AJAX calls here to refresh data
                    }, 30000);
                }
            }
        }
    </script>
</body>
</html> 