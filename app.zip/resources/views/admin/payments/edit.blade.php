@extends("layouts.admin")

@section("content")
<div class="py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="md:flex md:items-center md:justify-between">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Edit Payment #{{ $payment->id }}
                </h2>
            </div>
        </div>

        <div class="mt-8">
            <div class="bg-white shadow sm:rounded-lg">
                <form method="POST" action="{{ route("admin.payments.update", $payment) }}" class="px-4 py-5 sm:p-6">
                    @csrf
                    @method("PUT")
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="order_id" class="block text-sm font-medium text-gray-700">Order</label>
                            <select id="order_id" name="order_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                @foreach($orders as $order)
                                    <option value="{{ $order->id }}" {{ $payment->order_id == $order->id ? "selected" : "" }}>Order #{{ $order->id }} - {{ $order->customer->name ?? "Unknown" }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="amount" class="block text-sm font-medium text-gray-700">Amount</label>
                            <input type="number" step="0.01" id="amount" name="amount" value="{{ $payment->amount }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="payment_method" class="block text-sm font-medium text-gray-700">Payment Method</label>
                            <select id="payment_method" name="payment_method" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="cash" {{ $payment->payment_method === "cash" ? "selected" : "" }}>Cash</option>
                                <option value="card" {{ $payment->payment_method === "card" ? "selected" : "" }}>Card</option>
                                <option value="bank_transfer" {{ $payment->payment_method === "bank_transfer" ? "selected" : "" }}>Bank Transfer</option>
                                <option value="check" {{ $payment->payment_method === "check" ? "selected" : "" }}>Check</option>
                            </select>
                        </div>

                        <div>
                            <label for="payment_date" class="block text-sm font-medium text-gray-700">Payment Date</label>
                            <input type="date" id="payment_date" name="payment_date" value="{{ $payment->payment_date ? $payment->payment_date->format("Y-m-d") : "" }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        </div>

                        <div>
                            <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                            <select id="status" name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="pending" {{ $payment->status === "pending" ? "selected" : "" }}>Pending</option>
                                <option value="completed" {{ $payment->status === "completed" ? "selected" : "" }}>Completed</option>
                                <option value="failed" {{ $payment->status === "failed" ? "selected" : "" }}>Failed</option>
                                <option value="refunded" {{ $payment->status === "refunded" ? "selected" : "" }}>Refunded</option>
                            </select>
                        </div>

                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700">Notes</label>
                            <textarea id="notes" name="notes" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">{{ $payment->notes }}</textarea>
                        </div>
                    </div>

                    <div class="mt-6 flex items-center justify-end space-x-3">
                        <a href="{{ route("admin.payments.show", $payment) }}" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Cancel
                        </a>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Update Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
