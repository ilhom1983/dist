<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Пользователями - {{ auth()->guard('tenant')->user()->tenant->name }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="userData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('admin.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Пользователями</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Analytics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-6 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Пользователей</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['total_users'] }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Активных</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['active_users'] }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Менеджеров</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['manager_users'] }}</p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-user-tie"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Продавцов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['sales_users'] }}</p>
                    </div>
                    <div class="text-emerald-500 text-3xl">
                        <i class="fas fa-user-tag"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Склада</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['warehouse_users'] }}</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-warehouse"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Доставки</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $stats['delivery_users'] }}</p>
                    </div>
                    <div class="text-red-500 text-3xl">
                        <i class="fas fa-truck"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <input type="text" 
                           x-model="search" 
                           @input="filterUsers()"
                           placeholder="Поиск по имени или email..." 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div class="flex gap-2">
                    <select x-model="roleFilter" @change="filterUsers()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все роли</option>
                        <option value="manager">Менеджер</option>
                        <option value="sales">Продавец</option>
                        <option value="warehouse">Склад</option>
                        <option value="delivery">Доставка</option>
                    </select>
                    <select x-model="statusFilter" @change="filterUsers()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все статусы</option>
                        <option value="active">Активные</option>
                        <option value="inactive">Неактивные</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Список Пользователей</h3>
                <p class="text-sm text-gray-600 mt-1">Управление пользователями в вашей организации</p>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Пользователь</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Роль</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Бренды</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Территории</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Менеджер</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Активность</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Статус</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Действия</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200" x-ref="userTable">
                        @forelse($users as $user)
                        <tr class="user-row hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-bold mr-3">
                                        {{ strtoupper(substr($user->name, 0, 2)) }}
                                    </div>
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">{{ $user->name }}</div>
                                        <div class="text-sm text-gray-500">{{ $user->email }}</div>
                                        @if($user->phone)
                                            <div class="text-sm text-gray-500">{{ $user->phone }}</div>
                                        @endif
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    @if($user->role === 'manager') bg-purple-100 text-purple-800
                                    @elseif($user->role === 'sales') bg-emerald-100 text-emerald-800
                                    @elseif($user->role === 'warehouse') bg-orange-100 text-orange-800
                                    @elseif($user->role === 'delivery') bg-red-100 text-red-800
                                    @else bg-gray-100 text-gray-800 @endif">
                                    @if($user->role === 'manager') Менеджер
                                    @elseif($user->role === 'sales') Продавец
                                    @elseif($user->role === 'warehouse') Склад
                                    @elseif($user->role === 'delivery') Доставка
                                    @else {{ ucfirst($user->role) }}
                                    @endif
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $assignedBrands = $user->brandAssignments()->where('is_active', true)->with('brand')->get();
                                @endphp
                                @if($assignedBrands->count() > 0)
                                    <div class="space-y-1">
                                        @foreach($assignedBrands->take(2) as $brandAssignment)
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                {{ $brandAssignment->brand->name }}
                                            </span>
                                        @endforeach
                                        @if($assignedBrands->count() > 2)
                                            <span class="text-xs text-gray-500">+{{ $assignedBrands->count() - 2 }} еще</span>
                                        @endif
                                    </div>
                                @else
                                    <span class="text-xs text-green-600 font-medium">Все бренды</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $assignedTerritories = $user->territoryAssignments()->where('is_active', true)->get();
                                @endphp
                                @if($assignedTerritories->count() > 0)
                                    <div class="space-y-1">
                                        @foreach($assignedTerritories->take(2) as $territoryAssignment)
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                {{ $territoryAssignment->territory_name }}
                                            </span>
                                        @endforeach
                                        @if($assignedTerritories->count() > 2)
                                            <span class="text-xs text-gray-500">+{{ $assignedTerritories->count() - 2 }} еще</span>
                                        @endif
                                    </div>
                                @else
                                    <span class="text-xs text-gray-500">Не назначены</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $user->manager ? $user->manager->name : 'Не назначен' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">
                                    @php
                                        $totalOrders = $user->salesOrders->count() + $user->warehouseOrders->count() + $user->deliveryOrders->count();
                                    @endphp
                                    {{ $totalOrders }} заказов
                                </div>
                                <div class="text-sm text-gray-500">
                                    Последний: {{ $user->updated_at->diffForHumans() }}
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    @if($user->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    {{ $user->is_active ? 'Активный' : 'Неактивный' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex items-center justify-end space-x-2">
                                    <a href="{{ route('admin.users.show', $user) }}" class="text-blue-600 hover:text-blue-900" title="Просмотр">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('admin.users.edit', $user) }}" class="text-indigo-600 hover:text-indigo-900" title="Редактировать">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button @click="toggleUserStatus({{ $user->id }}, '{{ $user->name }}')" 
                                            class="text-yellow-600 hover:text-yellow-900" 
                                            title="{{ $user->is_active ? 'Деактивировать' : 'Активировать' }}">
                                        <i class="fas fa-{{ $user->is_active ? 'pause' : 'play' }}"></i>
                                    </button>
                                    <button @click="resetUserPassword({{ $user->id }}, '{{ $user->name }}')" 
                                            class="text-orange-600 hover:text-orange-900" 
                                            title="Сбросить пароль">
                                        <i class="fas fa-key"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                <i class="fas fa-users text-4xl mb-4"></i>
                                <p class="text-lg">Нет пользователей</p>
                                <p class="text-sm">Пользователи будут добавлены суперадминистратором</p>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            @if($users->hasPages())
            <div class="px-6 py-4 border-t border-gray-200">
                {{ $users->links() }}
            </div>
            @endif
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div x-show="showPasswordModal" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-orange-100">
                    <i class="fas fa-key text-orange-600"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mt-4">Новый пароль</h3>
                <div class="mt-2 px-7 py-3">
                    <p class="text-sm text-gray-500 mb-3">
                        Новый пароль для пользователя "<span x-text="passwordUser"></span>":
                    </p>
                    <div class="bg-gray-100 p-3 rounded-lg">
                        <code class="text-lg font-mono text-gray-800" x-text="newPassword"></code>
                    </div>
                    <p class="text-xs text-gray-500 mt-2">
                        Сохраните этот пароль! Он больше не будет показан.
                    </p>
                </div>
                <div class="flex justify-center space-x-4 mt-4">
                    <button @click="showPasswordModal = false" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Закрыть
                    </button>
                    <button @click="copyPassword()" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Копировать
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function userData() {
            return {
                search: '',
                roleFilter: '',
                statusFilter: '',
                showPasswordModal: false,
                passwordUser: '',
                newPassword: '',
                
                filterUsers() {
                    // Client-side filtering logic
                    const rows = this.$refs.userTable.querySelectorAll('.user-row');
                    rows.forEach(row => {
                        const userName = row.querySelector('td:first-child').textContent.toLowerCase();
                        const role = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                        const status = row.querySelector('td:nth-child(6)').textContent.toLowerCase();
                        
                        const matchesSearch = !this.search || userName.includes(this.search.toLowerCase());
                        const matchesRole = !this.roleFilter || role.includes(this.roleFilter.toLowerCase());
                        const matchesStatus = !this.statusFilter || 
                            (this.statusFilter === 'active' && status.includes('активный')) ||
                            (this.statusFilter === 'inactive' && status.includes('неактивный'));
                        
                        row.style.display = matchesSearch && matchesRole && matchesStatus ? '' : 'none';
                    });
                },
                
                toggleUserStatus(userId, userName) {
                    if (confirm(`Вы уверены, что хотите изменить статус пользователя "${userName}"?`)) {
                        fetch(`/admin/users/${userId}/toggle-status`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Accept': 'application/json',
                            },
                        }).then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                window.location.reload();
                            } else {
                                alert('Ошибка при изменении статуса');
                            }
                        });
                    }
                },
                
                resetUserPassword(userId, userName) {
                    if (confirm(`Вы уверены, что хотите сбросить пароль для пользователя "${userName}"?`)) {
                        fetch(`/admin/users/${userId}/reset-password`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Accept': 'application/json',
                            },
                        }).then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                this.passwordUser = userName;
                                this.newPassword = data.new_password;
                                this.showPasswordModal = true;
                            } else {
                                alert('Ошибка при сбросе пароля');
                            }
                        });
                    }
                },
                
                copyPassword() {
                    navigator.clipboard.writeText(this.newPassword).then(() => {
                        alert('Пароль скопирован в буфер обмена');
                    });
                }
            }
        }
    </script>
</body>
</html> 