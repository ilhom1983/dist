@extends('layouts.mobile')

@section('title', 'Order Details')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="mb-6">
        <a href="{{ route('mobile.sales.orders.index') }}" class="text-blue-600 hover:text-blue-800">
            ← Back to Orders
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h1 class="text-2xl font-bold text-gray-800 mb-4">Order #{{ $order->order_number }}</h1>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Order Info -->
            <div>
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Order Information</h2>
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Order Number:</span>
                        <span class="font-medium">{{ $order->order_number }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Order Date:</span>
                        <span class="font-medium">{{ $order->order_date->format('M d, Y') }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Status:</span>
                        <span class="px-2 py-1 text-sm rounded-full 
                            @if($order->orderStatus->name === 'pending') bg-yellow-100 text-yellow-800
                            @elseif($order->orderStatus->name === 'processing') bg-blue-100 text-blue-800
                            @elseif($order->orderStatus->name === 'shipped') bg-purple-100 text-purple-800
                            @elseif($order->orderStatus->name === 'delivered') bg-green-100 text-green-800
                            @elseif($order->orderStatus->name === 'cancelled') bg-red-100 text-red-800
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ ucfirst($order->orderStatus->name) }}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Payment Status:</span>
                        <span class="px-2 py-1 text-sm rounded-full 
                            @if($order->paymentStatus->name === 'pending') bg-yellow-100 text-yellow-800
                            @elseif($order->paymentStatus->name === 'paid') bg-green-100 text-green-800
                            @elseif($order->paymentStatus->name === 'overdue') bg-red-100 text-red-800
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ ucfirst($order->paymentStatus->name) }}
                        </span>
                    </div>
                </div>
            </div>

            <!-- Customer Info -->
            <div>
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Customer Information</h2>
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Name:</span>
                        <span class="font-medium">{{ $order->customer->name }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Phone:</span>
                        <span class="font-medium">{{ $order->customer->phone }}</span>
                    </div>
                    @if($order->customer->email)
                    <div class="flex justify-between">
                        <span class="text-gray-600">Email:</span>
                        <span class="font-medium">{{ $order->customer->email }}</span>
                    </div>
                    @endif
                    <div class="flex justify-between">
                        <span class="text-gray-600">Address:</span>
                        <span class="font-medium">{{ $order->customer->address }}</span>
                    </div>
                    @if($order->customer->city)
                    <div class="flex justify-between">
                        <span class="text-gray-600">City:</span>
                        <span class="font-medium">{{ $order->customer->city }}</span>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Order Items -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-lg font-semibold text-gray-700 mb-4">Order Items</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($order->orderItems as $item)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">{{ $item->product->name }}</div>
                            @if($item->product->brand)
                            <div class="text-sm text-gray-500">{{ $item->product->brand->name }}</div>
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $item->quantity }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ number_format($item->unit_price, 2) }} ₸</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ number_format($item->total_price, 2) }} ₸</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Order Summary -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-lg font-semibold text-gray-700 mb-4">Order Summary</h2>
        <div class="space-y-3">
            <div class="flex justify-between text-lg">
                <span class="font-semibold">Total Amount:</span>
                <span class="font-bold text-green-600">{{ number_format($order->total_amount, 2) }} ₸</span>
            </div>
            <div class="flex justify-between">
                <span class="text-gray-600">Remaining Amount:</span>
                <span class="font-medium">{{ number_format($order->remaining_amount, 2) }} ₸</span>
            </div>
            @if($order->notes)
            <div class="mt-4">
                <span class="text-gray-600">Notes:</span>
                <p class="text-gray-800 mt-1">{{ $order->notes }}</p>
            </div>
            @endif
        </div>
    </div>

    <!-- Location Information -->
    @if($order->latitude && $order->longitude)
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-lg font-semibold text-gray-700 mb-4">Location Information</h2>
        <div class="space-y-3">
            <div class="flex justify-between">
                <span class="text-gray-600">Coordinates:</span>
                <span class="font-medium">{{ $order->latitude }}, {{ $order->longitude }}</span>
            </div>
            <div class="mt-4">
                <a href="https://yandex.ru/maps/?pt={{ $order->longitude }},{{ $order->latitude }}&z=16" 
                   target="_blank" 
                   class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700">
                    <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path>
                    </svg>
                    Open in Yandex Maps
                </a>
            </div>
        </div>
    </div>
    @endif

    <!-- Payments -->
    @if($order->payments->count() > 0)
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-lg font-semibold text-gray-700 mb-4">Payment History</h2>
        <div class="space-y-3">
            @foreach($order->payments as $payment)
            <div class="border-b border-gray-200 pb-3 last:border-b-0">
                <div class="flex justify-between items-center">
                    <div>
                        <div class="font-medium">{{ $payment->payment_method->name }}</div>
                        <div class="text-sm text-gray-500">{{ $payment->payment_date->format('M d, Y H:i') }}</div>
                    </div>
                    <div class="text-right">
                        <div class="font-medium text-green-600">{{ number_format($payment->amount, 2) }} ₸</div>
                        <div class="text-sm text-gray-500">{{ ucfirst($payment->status) }}</div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif
</div>

<!-- Fixed Bottom Navigation -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
    <div class="flex justify-around">
        <a href="{{ route('mobile.sales.dashboard') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5a2 2 0 012-2h4a2 2 0 012 2v6H8V5z"></path>
            </svg>
            <span class="text-xs mt-1">Dashboard</span>
        </a>
        <a href="{{ route('mobile.sales.customers.index') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <span class="text-xs mt-1">Customers</span>
        </a>
        <a href="{{ route('mobile.sales.orders.index') }}" class="flex flex-col items-center text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <span class="text-xs mt-1">Orders</span>
        </a>
        <a href="{{ route('mobile.sales.debtors.index') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
            </svg>
            <span class="text-xs mt-1">Debtors</span>
        </a>
    </div>
</div>
@endsection 