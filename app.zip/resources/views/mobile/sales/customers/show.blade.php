@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">{{ $customer->name }}</h1>
                    <p class="text-sm text-gray-600">Детали клиента</p>
                </div>
                <a href="{{ route('mobile.sales.customers.index') }}" class="text-blue-600 text-sm font-medium">
                    Назад
                </a>
            </div>
        </div>
    </div>

    <!-- Customer Info -->
    <div class="p-4">
        <div class="bg-white rounded-lg shadow-sm p-4 mb-4">
            <!-- Storefront Image -->
            @if($customer->image)
            <div class="mb-4">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Фото магазина</h3>
                <div class="relative">
                    @php
                        $imageUrl = asset('storage/' . $customer->image);
                        $imageExists = \Storage::disk('public')->exists($customer->image);
                    @endphp
                    
                    @if($imageExists)
                        <img src="{{ $imageUrl }}" 
                             alt="Storefront of {{ $customer->name }}"
                             class="w-full h-48 object-cover rounded-lg">
                    @else
                        <div class="w-full h-48 bg-gray-100 rounded-lg flex items-center justify-center">
                            <div class="text-center">
                                <svg class="w-12 h-12 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <p class="text-sm text-gray-500">Изображение недоступно</p>
                            </div>
                        </div>
                    @endif
                    
                    <div class="absolute top-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                        <svg class="w-3 h-3 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        </svg>
                        Магазин
                    </div>
                </div>
            </div>
            @endif

            <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <span class="text-lg font-medium text-blue-600">{{ substr($customer->name, 0, 2) }}</span>
                </div>
                <div class="ml-3">
                    <h2 class="text-lg font-semibold text-gray-900">{{ $customer->name }}</h2>
                    @if($customer->customerGroup)
                    <p class="text-sm text-gray-500">{{ $customer->customerGroup->name }}</p>
                    @endif
                </div>
            </div>

            <!-- Contact Info -->
            <div class="space-y-3">
                <div class="flex items-center">
                    <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                    </svg>
                    <span class="text-sm text-gray-900">{{ $customer->phone }}</span>
                </div>
                
                @if($customer->email)
                <div class="flex items-center">
                    <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                    <span class="text-sm text-gray-900">{{ $customer->email }}</span>
                </div>
                @endif
                
                <div class="flex items-start">
                    <svg class="w-5 h-5 text-gray-400 mr-3 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                    <div>
                        <p class="text-sm text-gray-900">{{ $customer->address }}</p>
                        @if($customer->city)
                        <p class="text-sm text-gray-500">{{ $customer->city }}</p>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Location Actions -->
            @if($customer->latitude && $customer->longitude)
            <div class="mt-4 pt-4 border-t border-gray-200">
                <a href="https://yandex.ru/maps/?pt={{ $customer->longitude }},{{ $customer->latitude }}&z=16" 
                   target="_blank"
                   class="flex items-center justify-center w-full bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m-6 3l6-3"></path>
                    </svg>
                    Открыть в Яндекс.Картах
                </a>
            </div>
            @endif
        </div>

        <!-- Orders -->
        @if($customer->orders->count() > 0)
        <div class="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-3">Заказы ({{ $customer->orders->count() }})</h3>
            <div class="space-y-3">
                @foreach($customer->orders->take(5) as $order)
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                        <p class="text-sm font-medium text-gray-900">{{ $order->order_number }}</p>
                        <p class="text-xs text-gray-500">{{ $order->order_date->format('d.m.Y') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900">{{ number_format($order->total_amount, 0, ',', ' ') }} ₽</p>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                            @if($order->orderStatus->name === 'delivered') bg-green-100 text-green-800
                            @elseif($order->orderStatus->name === 'pending') bg-yellow-100 text-yellow-800
                            @else bg-gray-100 text-gray-800 @endif">
                            {{ $order->orderStatus->name }}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>
            @if($customer->orders->count() > 5)
            <div class="mt-3 text-center">
                <a href="{{ route('mobile.sales.orders.index') }}?customer={{ $customer->id }}" class="text-sm text-blue-600">
                    Показать все заказы
                </a>
            </div>
            @endif
        </div>
        @endif

        <!-- Commitments -->
        @if($customer->commitments->count() > 0)
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-3">Долги ({{ $customer->commitments->count() }})</h3>
            <div class="space-y-3">
                @foreach($customer->commitments->take(3) as $commitment)
                <div class="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                        <p class="text-sm font-medium text-gray-900">{{ number_format($commitment->remaining_amount, 0, ',', ' ') }} ₽</p>
                        <p class="text-xs text-gray-500">Срок: {{ $commitment->due_date->format('d.m.Y') }}</p>
                    </div>
                    <div class="text-right">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                            @if($commitment->status === 'overdue') bg-red-100 text-red-800
                            @else bg-yellow-100 text-yellow-800 @endif">
                            {{ $commitment->status }}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.sales.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.sales.customers.index') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                </svg>
                <span class="text-xs mt-1">Клиенты</span>
            </a>
            <a href="{{ route('mobile.sales.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.sales.debtors.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <span class="text-xs mt-1">Долги</span>
            </a>
        </div>
    </div>
</div>
@endsection 