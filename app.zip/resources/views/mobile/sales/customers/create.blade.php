@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Новый клиент</h1>
                    <p class="text-sm text-gray-600">Добавить клиента</p>
                </div>
                <a href="{{ route('mobile.sales.customers.index') }}" class="text-blue-600 text-sm font-medium">
                    Отмена
                </a>
            </div>
        </div>
    </div>

    <!-- Form -->
    <form action="{{ route('mobile.sales.customers.store') }}" method="POST" enctype="multipart/form-data" class="p-4">
        @csrf
        
        @if(session('success'))
            <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                {{ session('success') }}
            </div>
        @endif
        
        @if(session('error'))
            <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                {{ session('error') }}
            </div>
        @endif
        
        <!-- Location Status -->
        <div id="locationStatus" class="mb-4 p-3 rounded-lg bg-blue-50 border border-blue-200">
            <div class="flex items-center">
                <svg class="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
                <span class="text-sm text-blue-800">Получение местоположения...</span>
            </div>
        </div>

        <!-- Name -->
        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Имя клиента *</label>
            <input type="text" name="name" id="name" required 
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                   placeholder="Введите имя клиента">
            @error('name')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- Phone -->
        <div class="mb-4">
            <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">Телефон *</label>
            <input type="tel" name="phone" id="phone" required 
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                   placeholder="+7 (999) 123-45-67">
            @error('phone')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- Email -->
        <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input type="email" name="email" id="email" 
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                   placeholder="client@example.com">
            @error('email')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- Address -->
        <div class="mb-4">
            <label for="address" class="block text-sm font-medium text-gray-700 mb-2">Адрес *</label>
            <textarea name="address" id="address" rows="3" required 
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Введите полный адрес"></textarea>
            @error('address')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- City -->
        <div class="mb-4">
            <label for="city" class="block text-sm font-medium text-gray-700 mb-2">Город</label>
            <input type="text" name="city" id="city" 
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                   placeholder="Введите город">
            @error('city')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- Customer Group -->
        @if($customerGroups->count() > 0)
        <div class="mb-4" x-data="searchableDropdown({
            options: @json($customerGroups->map(function($group) {
                return ['id' => $group->id, 'text' => $group->name];
            })),
            placeholder: 'Выберите группу',
            name: 'customer_group_id',
            required: false
        })">
            <label for="customer_group_id" class="block text-sm font-medium text-gray-700 mb-2">Группа клиентов</label>
            
            <!-- Search Input -->
            <div class="relative">
                <input type="text" 
                       x-ref="searchInput"
                       @input="filterOptions()"
                       @focus="openDropdown()"
                       @click="openDropdown()"
                       :placeholder="selectedOption ? selectedOption.text : placeholder"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       :class="{ 'bg-gray-50': selectedOption }">
                
                <!-- Dropdown Arrow -->
                <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                    <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </div>
            </div>
            
            <!-- Hidden Input for Form Submission -->
            <input type="hidden" name="customer_group_id" :value="selectedOption ? selectedOption.id : ''">
            
            <!-- Dropdown Options -->
            <div x-show="isOpen" 
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0 transform scale-95"
                 x-transition:enter-end="opacity-100 transform scale-100"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100 transform scale-100"
                 x-transition:leave-end="opacity-0 transform scale-95"
                 @click.away="closeDropdown()"
                 class="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                <template x-for="option in filteredOptions" :key="option.id">
                    <div @click="selectOption(option)"
                         class="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                         :class="{ 'bg-blue-50 text-blue-700': selectedOption && selectedOption.id === option.id }">
                        <span x-text="option.text"></span>
                    </div>
                </template>
                <div x-show="filteredOptions.length === 0" class="px-3 py-2 text-sm text-gray-500">
                    Ничего не найдено
                </div>
            </div>
            
            @error('customer_group_id')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>
        @endif

        <!-- Customer Image Capture -->
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Фото магазина *</label>
            <div class="space-y-3">
                <!-- Image Preview -->
                <div id="imagePreview" class="relative bg-gray-100 rounded-lg overflow-hidden" style="display: none;">
                    <img id="capturedImage" class="w-full h-64 object-cover" alt="Captured storefront">
                    <button type="button" onclick="retakePhoto()" 
                            class="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full hover:bg-red-700">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                    </button>
                </div>
                
                <!-- Web Camera Preview (Fallback) -->
                <div id="cameraPreview" class="relative bg-gray-100 rounded-lg overflow-hidden" style="display: none;">
                    <video id="video" class="w-full h-64 object-cover" autoplay></video>
                    <div class="absolute inset-0 flex items-center justify-center">
                        <div class="bg-black bg-opacity-50 text-white px-4 py-2 rounded-lg">
                            <span id="cameraStatus">Подготовка камеры...</span>
                        </div>
                    </div>
                </div>
                
                <!-- Hybrid Photo Controls -->
                <div id="photoControls" class="space-y-2">
                    <!-- Primary: Native Mobile Features -->
                    <div class="flex space-x-2">
                        <button type="button" onclick="openNativeCamera()" id="nativeCameraBtn"
                                class="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg text-sm font-medium hover:bg-blue-700">
                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                            Сделать фото
                        </button>
                        <button type="button" onclick="openGallery()" id="galleryBtn"
                                class="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg text-sm font-medium hover:bg-green-700">
                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                            Из галереи
                        </button>
                    </div>
                    
                    <!-- Fallback: Web Camera -->
                    <div id="webCameraFallback" class="text-center" style="display: none;">
                        <div class="text-xs text-gray-500 mb-2">Нативные функции недоступны</div>
                        <button type="button" onclick="startWebCamera()" id="webCameraBtn"
                                class="w-full bg-orange-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-orange-700">
                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                            </svg>
                            Веб-камера
                        </button>
                    </div>
                    
                    <!-- Web Camera Capture Button -->
                    <button type="button" onclick="captureWebPhoto()" id="captureBtn"
                            class="w-full bg-green-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-700"
                            style="display: none;">
                        <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                        </svg>
                        Сделать фото
                    </button>
                </div>
                
                <!-- Hidden file inputs -->
                <input type="file" name="image" id="imageInput" accept="image/*" style="display: none;" required>
                <input type="file" id="nativeCameraInput" accept="image/*" capture="environment" style="display: none;">
                <input type="file" id="galleryInput" accept="image/*" style="display: none;">
                
                <!-- Status message -->
                <div id="imageStatus" class="text-sm text-gray-600"></div>
            </div>
            @error('image')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <!-- Hidden Location Fields -->
        <input type="hidden" name="latitude" id="latitude">
        <input type="hidden" name="longitude" id="longitude">

        <!-- Submit Button -->
        <div class="mt-6">
            <button type="submit" id="submitBtn"
                    class="w-full bg-gray-400 text-white py-3 px-4 rounded-lg font-medium focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 cursor-not-allowed"
                    disabled>
                <span id="submitText">Создать клиента</span>
                <span id="submitLoading" class="hidden">
                    <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Создание...
                </span>
            </button>
        </div>
    </form>

    <!-- Location Permission Modal -->
    <div id="locationModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg p-6 max-w-sm w-full">
                <div class="text-center">
                    <svg class="mx-auto h-12 w-12 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                    </svg>
                    <h3 class="mt-4 text-lg font-medium text-gray-900">Требуется доступ к местоположению</h3>
                    <p class="mt-2 text-sm text-gray-500">
                        Для создания клиента необходимо получить ваше местоположение. Это требуется для создания маршрута в Яндекс.Навигаторе.
                    </p>
                    <div class="mt-6">
                        <button type="button" onclick="requestLocation()" 
                                class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
                            Разрешить доступ
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let locationCaptured = false;
let imageCaptured = false;
let stream = null;
let canvas = null;
let video = null;

// Alpine.js Searchable Dropdown Component
function searchableDropdown(config) {
    return {
        options: config.options || [],
        placeholder: config.placeholder || 'Выберите опцию',
        name: config.name || '',
        required: config.required || false,
        onSelect: config.onSelect || null,
        isOpen: false,
        selectedOption: null,
        searchTerm: '',
        filteredOptions: [],
        
        init() {
            this.filteredOptions = [...this.options];
        },
        
        filterOptions() {
            const searchTerm = this.$refs.searchInput.value.toLowerCase();
            this.searchTerm = searchTerm;
            
            if (searchTerm === '') {
                this.filteredOptions = [...this.options];
            } else {
                this.filteredOptions = this.options.filter(option => 
                    option.text.toLowerCase().includes(searchTerm)
                );
            }
        },
        
        openDropdown() {
            this.isOpen = true;
            this.$nextTick(() => {
                this.$refs.searchInput.focus();
            });
        },
        
        closeDropdown() {
            this.isOpen = false;
            this.searchTerm = '';
            this.filterOptions();
        },
        
        selectOption(option) {
            this.selectedOption = option;
            this.closeDropdown();
            
            if (this.onSelect) {
                this.onSelect.call(this, option);
            }
        }
    };
}

// Hybrid Photo Capture Functions
let stream = null;
let canvas = null;
let video = null;

// Check device capabilities on page load
document.addEventListener('DOMContentLoaded', function() {
    checkDeviceCapabilities();
    checkLocationPermission();
    
    // Set up native file input event listeners
    const nativeCameraInput = document.getElementById('nativeCameraInput');
    const galleryInput = document.getElementById('galleryInput');
    
    handleFileSelection(nativeCameraInput, 'с камеры');
    handleFileSelection(galleryInput, 'из галереи');
    
    // Add form validation
    document.querySelector('form').addEventListener('submit', function(e) {
        if (!locationCaptured) {
            e.preventDefault();
            alert('Необходимо получить местоположение для создания клиента.');
            return false;
        }
        if (!imageCaptured) {
            e.preventDefault();
            alert('Необходимо сделать фото магазина для создания клиента.');
            return false;
        }
        
        // Additional validation for image file
        const imageInput = document.getElementById('imageInput');
        if (!imageInput.files || imageInput.files.length === 0) {
            e.preventDefault();
            alert('Ошибка: файл изображения не найден. Попробуйте сделать фото еще раз.');
            return false;
        }
        
        const file = imageInput.files[0];
        if (!file.type.startsWith('image/')) {
            e.preventDefault();
            alert('Ошибка: выбранный файл не является изображением. Попробуйте сделать фото еще раз.');
            return false;
        }
        
        // Show loading state
        const submitBtn = document.getElementById('submitBtn');
        const submitText = document.getElementById('submitText');
        const submitLoading = document.getElementById('submitLoading');
        
        submitBtn.disabled = true;
        submitText.classList.add('hidden');
        submitLoading.classList.remove('hidden');
    });
});

function checkDeviceCapabilities() {
    // Check if native file input with capture is supported
    const testInput = document.createElement('input');
    testInput.type = 'file';
    testInput.accept = 'image/*';
    testInput.capture = 'environment';
    
    const hasNativeCamera = testInput.capture !== undefined;
    const hasFileAPI = 'File' in window && 'FileReader' in window;
    
    if (!hasNativeCamera || !hasFileAPI) {
        // Show web camera fallback
        document.getElementById('webCameraFallback').style.display = 'block';
        updateImageStatus('info', 'Используйте веб-камеру для фото');
    } else {
        updateImageStatus('info', 'Выберите способ получения фото');
    }
}

// Native Mobile Functions
function openNativeCamera() {
    const nativeInput = document.getElementById('nativeCameraInput');
    nativeInput.click();
}

function openGallery() {
    const galleryInput = document.getElementById('galleryInput');
    galleryInput.click();
}

// Handle native camera/gallery file selection
function handleFileSelection(input, source) {
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        if (!file.type.startsWith('image/')) {
            updateImageStatus('error', 'Выбранный файл не является изображением');
            return;
        }
        
        // Set the file to the main image input
        const mainInput = document.getElementById('imageInput');
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        mainInput.files = dataTransfer.files;
        
        // Show preview
        const capturedImage = document.getElementById('capturedImage');
        capturedImage.src = URL.createObjectURL(file);
        
        // Hide camera preview and show image preview
        document.getElementById('cameraPreview').style.display = 'none';
        document.getElementById('imagePreview').style.display = 'block';
        
        // Hide web camera controls
        document.getElementById('captureBtn').style.display = 'none';
        
        imageCaptured = true;
        updateImageStatus('success', `Фото ${source} загружено`);
        
        // Enable submit button if location is also captured
        if (locationCaptured) {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.disabled = false;
            submitBtn.className = 'w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2';
        }
    });
}

// Web Camera Functions (Fallback)
function startWebCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        updateImageStatus('error', 'Веб-камера не поддерживается в этом браузере');
        return;
    }

    updateImageStatus('loading', 'Запуск веб-камеры...');
    
    // Try to get rear camera (environment-facing)
    navigator.mediaDevices.getUserMedia({ 
        video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
        } 
    })
    .then(function(mediaStream) {
        stream = mediaStream;
        video = document.getElementById('video');
        video.srcObject = stream;
        
        video.onloadedmetadata = function() {
            document.getElementById('cameraPreview').style.display = 'block';
            document.getElementById('captureBtn').style.display = 'block';
            updateImageStatus('success', 'Веб-камера готова');
        };
        
        video.onerror = function() {
            updateImageStatus('error', 'Ошибка загрузки веб-камеры');
        };
    })
    .catch(function(error) {
        console.error('Web camera error:', error);
        updateImageStatus('error', 'Не удалось получить доступ к веб-камере: ' + error.message);
    });
}

function captureWebPhoto() {
    if (!video || !stream) {
        updateImageStatus('error', 'Веб-камера не запущена');
        return;
    }

    // Check if video is ready
    if (video.videoWidth === 0 || video.videoHeight === 0) {
        updateImageStatus('error', 'Видео еще не готово. Подождите немного и попробуйте снова.');
        return;
    }

    // Create canvas to capture the image
    canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to blob with error handling
    canvas.toBlob(function(blob) {
        if (!blob) {
            updateImageStatus('error', 'Ошибка при создании изображения. Попробуйте еще раз.');
            return;
        }
        
        // Create file input and set the captured image
        const fileInput = document.getElementById('imageInput');
        
        // Ensure the blob has the correct MIME type
        const correctedBlob = new Blob([blob], { type: 'image/jpeg' });
        const file = new File([correctedBlob], 'storefront_' + Date.now() + '.jpg', { 
            type: 'image/jpeg',
            lastModified: Date.now()
        });
        
        // Create a FileList-like object using DataTransfer
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;
        
        // Verify the file was properly set
        if (fileInput.files.length === 0) {
            updateImageStatus('error', 'Ошибка при создании файла изображения. Попробуйте еще раз.');
            return;
        }
        
        // Trigger change event to ensure form recognizes the file
        const changeEvent = new Event('change', { bubbles: true });
        fileInput.dispatchEvent(changeEvent);
        
        // Show captured image
        const capturedImage = document.getElementById('capturedImage');
        capturedImage.src = URL.createObjectURL(correctedBlob);
        
        // Hide camera preview and show image preview
        document.getElementById('cameraPreview').style.display = 'none';
        document.getElementById('imagePreview').style.display = 'block';
        document.getElementById('captureBtn').style.display = 'none';
        
        // Stop camera stream
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
        
        imageCaptured = true;
        updateImageStatus('success', 'Фото магазина сделано');
        
        // Enable submit button if location is also captured
        if (locationCaptured) {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.disabled = false;
            submitBtn.className = 'w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2';
        }
    }, 'image/jpeg', 0.8);
}

function retakePhoto() {
    // Reset image capture state
    imageCaptured = false;
    
    // Hide image preview
    document.getElementById('imagePreview').style.display = 'none';
    
    // Clear file input
    document.getElementById('imageInput').value = '';
    
    // Show photo controls
    document.getElementById('photoControls').style.display = 'block';
    
    // Hide web camera controls
    document.getElementById('captureBtn').style.display = 'none';
    
    // Disable submit button
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.className = 'w-full bg-gray-400 text-white py-3 px-4 rounded-lg font-medium focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 cursor-not-allowed';
    
    updateImageStatus('info', 'Выберите способ получения фото');
}

function updateImageStatus(status, message) {
    const statusDiv = document.getElementById('imageStatus');
    let textColor;
    
    switch(status) {
        case 'loading':
            textColor = 'text-blue-600';
            break;
        case 'success':
            textColor = 'text-green-600';
            break;
        case 'error':
            textColor = 'text-red-600';
            break;
        case 'info':
            textColor = 'text-gray-600';
            break;
        default:
            textColor = 'text-gray-600';
    }
    
    statusDiv.className = `text-sm ${textColor}`;
    statusDiv.textContent = message;
}

// Check location permission on page load
function checkLocationPermission() {
    if (!navigator.geolocation) {
        updateLocationStatus('error', 'Геолокация не поддерживается в этом браузере');
        return;
    }

    navigator.permissions.query({name: 'geolocation'}).then(function(result) {
        if (result.state === 'granted') {
            captureLocation();
        } else if (result.state === 'prompt') {
            showLocationModal();
        } else {
            updateLocationStatus('error', 'Доступ к местоположению запрещен. Необходимо разрешить доступ для создания клиента.');
            // Show modal to request permission again
            setTimeout(() => {
                showLocationModal();
            }, 1000);
        }
    });
}
    if (!navigator.geolocation) {
        updateLocationStatus('error', 'Геолокация не поддерживается в этом браузере');
        return;
    }

    navigator.permissions.query({name: 'geolocation'}).then(function(result) {
        if (result.state === 'granted') {
            captureLocation();
        } else if (result.state === 'prompt') {
            showLocationModal();
        } else {
            updateLocationStatus('error', 'Доступ к местоположению запрещен. Необходимо разрешить доступ для создания клиента.');
            // Show modal to request permission again
            setTimeout(() => {
                showLocationModal();
            }, 1000);
        }
    });
}

function showLocationModal() {
    document.getElementById('locationModal').classList.remove('hidden');
}

function closeLocationModal() {
    // Don't allow closing the modal - location is required
    // The modal will stay open until location is granted
}

function requestLocation() {
    closeLocationModal();
    captureLocation();
}

function captureLocation() {
    updateLocationStatus('loading', 'Получение местоположения...');
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            
            document.getElementById('latitude').value = latitude;
            document.getElementById('longitude').value = longitude;
            
            locationCaptured = true;
            updateLocationStatus('success', 'Местоположение получено');
            
            // Enable submit button if image is also captured
            if (imageCaptured) {
                const submitBtn = document.getElementById('submitBtn');
                submitBtn.disabled = false;
                submitBtn.className = 'w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2';
            }
        },
        function(error) {
            let errorMessage = 'Ошибка получения местоположения';
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage = 'Доступ к местоположению запрещен. Необходимо разрешить доступ для создания клиента.';
                    // Show modal again for permission denied
                    setTimeout(() => {
                        showLocationModal();
                    }, 1000);
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage = 'Информация о местоположении недоступна. Попробуйте еще раз.';
                    break;
                case error.TIMEOUT:
                    errorMessage = 'Превышено время ожидания. Попробуйте еще раз.';
                    break;
            }
            updateLocationStatus('error', errorMessage);
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        }
    );
}

function updateLocationStatus(status, message) {
    const statusDiv = document.getElementById('locationStatus');
    let bgColor, textColor, icon;
    
    switch(status) {
        case 'loading':
            bgColor = 'bg-blue-50';
            textColor = 'text-blue-800';
            icon = `<svg class="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>`;
            break;
        case 'success':
            bgColor = 'bg-green-50';
            textColor = 'text-green-800';
            icon = `<svg class="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>`;
            break;
        case 'error':
            bgColor = 'bg-red-50';
            textColor = 'text-red-800';
            icon = `<svg class="w-5 h-5 text-red-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>`;
            break;
        case 'skipped':
            bgColor = 'bg-yellow-50';
            textColor = 'text-yellow-800';
            icon = `<svg class="w-5 h-5 text-yellow-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
            </svg>`;
            break;
    }
    
    statusDiv.className = `mb-4 p-3 rounded-lg ${bgColor} border ${bgColor.replace('50', '200')}`;
    statusDiv.innerHTML = `
        <div class="flex items-center">
            ${icon}
            <span class="text-sm ${textColor}">${message}</span>
        </div>
    `;
}
</script>
@endsection 