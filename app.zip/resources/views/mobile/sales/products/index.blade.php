@extends('layouts.mobile')

@section('title', 'Products')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Products</h1>
        <p class="text-gray-600 mt-2">Browse available products</p>
    </div>

    <!-- Search -->
    <div class="mb-6">
        <div class="relative">
            <input type="text" 
                   id="search" 
                   placeholder="Search products..." 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
            </div>
        </div>
    </div>

    <!-- Products Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="products-grid">
        @forelse($products as $product)
        <div class="bg-white rounded-lg shadow-md overflow-hidden product-card" 
             data-name="{{ strtolower($product->name) }}"
             data-category="{{ strtolower($product->category->name ?? '') }}"
             data-brand="{{ strtolower($product->brand->name ?? '') }}">
            <div class="p-4">
                <div class="flex justify-between items-start mb-3">
                    <div class="flex-1">
                        <h3 class="text-lg font-semibold text-gray-800 mb-1">{{ $product->name }}</h3>
                        @if($product->brand)
                        <p class="text-sm text-gray-600">{{ $product->brand->name }}</p>
                        @endif
                        @if($product->category)
                        <p class="text-sm text-gray-500">{{ $product->category->name }}</p>
                        @endif
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-green-600">{{ number_format($product->price, 2) }} ₸</div>
                        @if($product->stock_quantity > 0)
                        <div class="text-sm text-green-600">In Stock</div>
                        @else
                        <div class="text-sm text-red-600">Out of Stock</div>
                        @endif
                    </div>
                </div>
                
                @if($product->description)
                <p class="text-gray-600 text-sm mb-3 line-clamp-2">{{ $product->description }}</p>
                @endif
                
                <div class="flex justify-between items-center">
                    <div class="text-sm text-gray-500">
                        SKU: {{ $product->sku }}
                    </div>
                    <a href="{{ route('mobile.sales.products.show', $product) }}" 
                       class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        View Details →
                    </a>
                </div>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-12">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
            </svg>
            <h3 class="mt-2 text-sm font-medium text-gray-900">No products found</h3>
            <p class="mt-1 text-sm text-gray-500">No products are available at the moment.</p>
        </div>
        @endforelse
    </div>

    <!-- Pagination -->
    @if($products->hasPages())
    <div class="mt-8">
        {{ $products->links() }}
    </div>
    @endif
</div>

<!-- Fixed Bottom Navigation -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
    <div class="flex justify-around">
        <a href="{{ route('mobile.sales.dashboard') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5a2 2 0 012-2h4a2 2 0 012 2v6H8V5z"></path>
            </svg>
            <span class="text-xs mt-1">Dashboard</span>
        </a>
        <a href="{{ route('mobile.sales.customers.index') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <span class="text-xs mt-1">Customers</span>
        </a>
        <a href="{{ route('mobile.sales.orders.index') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <span class="text-xs mt-1">Orders</span>
        </a>
        <a href="{{ route('mobile.sales.debtors.index') }}" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
            </svg>
            <span class="text-xs mt-1">Debtors</span>
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search');
    const productCards = document.querySelectorAll('.product-card');
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        productCards.forEach(card => {
            const name = card.dataset.name;
            const category = card.dataset.category;
            const brand = card.dataset.brand;
            
            if (name.includes(searchTerm) || category.includes(searchTerm) || brand.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});
</script>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
@endsection 