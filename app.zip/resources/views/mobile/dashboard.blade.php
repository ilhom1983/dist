<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мобильная панель - {{ auth()->guard('tenant')->user()->tenant->name }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <h1 class="text-xl font-semibold text-gray-900">Мобильная панель</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</span>
                    <form action="{{ route('tenant.logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Welcome Message -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 rounded-lg">
                    <i class="fas fa-user text-blue-600"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-lg font-semibold text-gray-900">Добро пожаловать, {{ auth()->guard('tenant')->user()->name }}!</h2>
                    <p class="text-gray-600">{{ auth()->guard('tenant')->user()->tenant->name }}</p>
                </div>
            </div>
        </div>

        <!-- Role-based Actions -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @if(auth()->guard('tenant')->user()->role === 'manager')
                <!-- Manager Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Управление командой</h3>
                    <div class="space-y-3">
                        <a href="#" class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                            <i class="fas fa-users text-blue-600 mr-3"></i>
                            <span>Моя команда</span>
                        </a>
                        <a href="#" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                            <i class="fas fa-chart-line text-green-600 mr-3"></i>
                            <span>Отчеты</span>
                        </a>
                        <a href="#" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                            <i class="fas fa-tasks text-purple-600 mr-3"></i>
                            <span>Задачи</span>
                        </a>
                    </div>
                </div>
            @endif

            @if(auth()->guard('tenant')->user()->role === 'sales')
                <!-- Sales Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Продажи</h3>
                    <div class="space-y-3">
                        <a href="#" class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                            <i class="fas fa-shopping-cart text-blue-600 mr-3"></i>
                            <span>Новый заказ</span>
                        </a>
                        <a href="#" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                            <i class="fas fa-users text-green-600 mr-3"></i>
                            <span>Клиенты</span>
                        </a>
                        <a href="#" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                            <i class="fas fa-box text-purple-600 mr-3"></i>
                            <span>Товары</span>
                        </a>
                    </div>
                </div>
            @endif

            @if(auth()->guard('tenant')->user()->role === 'warehouse')
                <!-- Warehouse Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Склад</h3>
                    <div class="space-y-3">
                        <a href="{{ route('mobile.warehouse.inventory.index') }}" class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                            <i class="fas fa-boxes text-blue-600 mr-3"></i>
                            <span>Остатки</span>
                        </a>
                        <a href="{{ route('mobile.warehouse.orders.index') }}" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                            <i class="fas fa-truck text-green-600 mr-3"></i>
                            <span>Отгрузки</span>
                        </a>
                        <a href="{{ route('mobile.warehouse.products.index') }}" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                            <i class="fas fa-plus text-purple-600 mr-3"></i>
                            <span>Товары</span>
                        </a>
                    </div>
                </div>
            @endif

            @if(auth()->guard('tenant')->user()->role === 'delivery')
                <!-- Delivery Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Доставка</h3>
                    <div class="space-y-3">
                        <a href="{{ route('mobile.delivery.orders.index') }}" class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                            <i class="fas fa-route text-blue-600 mr-3"></i>
                            <span>Заказы</span>
                        </a>
                        <a href="{{ route('mobile.delivery.debtors.index') }}" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                            <i class="fas fa-check text-green-600 mr-3"></i>
                            <span>Должники</span>
                        </a>
                        <a href="{{ route('mobile.delivery.payments.index') }}" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                            <i class="fas fa-clock text-purple-600 mr-3"></i>
                            <span>Платежи</span>
                        </a>
                    </div>
                </div>
            @endif

            <!-- Common Actions -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Общие функции</h3>
                <div class="space-y-3">
                    <a href="#" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <i class="fas fa-bell text-gray-600 mr-3"></i>
                        <span>Уведомления</span>
                    </a>
                    <a href="#" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <i class="fas fa-cog text-gray-600 mr-3"></i>
                        <span>Настройки</span>
                    </a>
                    <a href="#" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <i class="fas fa-question-circle text-gray-600 mr-3"></i>
                        <span>Помощь</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            @if(auth()->guard('tenant')->user()->role === 'sales' && isset($roleData))
                <!-- Sales Stats -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-blue-100 rounded-lg">
                            <i class="fas fa-shopping-cart text-blue-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Всего заказов</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['my_orders'] ?? 0 }}</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-green-100 rounded-lg">
                            <i class="fas fa-check-circle text-green-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Активные</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['my_active_orders'] ?? 0 }}</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-red-100 rounded-lg">
                            <i class="fas fa-times-circle text-red-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Отменено</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['my_cancelled_orders'] ?? 0 }}</p>
                            <p class="text-xs text-gray-400">Текущий месяц</p>
                        </div>
                    </div>
                </div>

                @if(isset($roleData['my_returned_orders']) && $roleData['my_returned_orders'] > 0)
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-orange-100 rounded-lg">
                            <i class="fas fa-undo text-orange-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Возвраты</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['my_returned_orders'] }}</p>
                            <p class="text-xs text-gray-400">Текущий месяц</p>
                        </div>
                    </div>
                </div>
                @endif
            @elseif(auth()->guard('tenant')->user()->role === 'manager' && isset($roleData))
                <!-- Manager Stats -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-blue-100 rounded-lg">
                            <i class="fas fa-users text-blue-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Всего заказов</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['total_team_orders'] ?? 0 }}</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-yellow-100 rounded-lg">
                            <i class="fas fa-clock text-yellow-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">На одобрении</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['pending_approvals'] ?? 0 }}</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-red-100 rounded-lg">
                            <i class="fas fa-times-circle text-red-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Отменено</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['team_cancelled_orders'] ?? 0 }}</p>
                            <p class="text-xs text-gray-400">Текущий месяц</p>
                        </div>
                    </div>
                </div>

                @if(isset($roleData['team_returned_orders']) && $roleData['team_returned_orders'] > 0)
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-orange-100 rounded-lg">
                            <i class="fas fa-undo text-orange-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Возвраты</p>
                            <p class="text-2xl font-semibold text-gray-900">{{ $roleData['team_returned_orders'] }}</p>
                            <p class="text-xs text-gray-400">Текущий месяц</p>
                        </div>
                    </div>
                </div>
                @endif
            @else
                <!-- Default Stats -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-blue-100 rounded-lg">
                            <i class="fas fa-shopping-cart text-blue-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Заказов сегодня</p>
                            <p class="text-2xl font-semibold text-gray-900">0</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-green-100 rounded-lg">
                            <i class="fas fa-check-circle text-green-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Выполнено</p>
                            <p class="text-2xl font-semibold text-gray-900">0</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="p-2 bg-orange-100 rounded-lg">
                            <i class="fas fa-clock text-orange-600"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">В ожидании</p>
                            <p class="text-2xl font-semibold text-gray-900">0</p>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</body>
</html> 