@extends('layouts.mobile')

@section('title', 'Детали заказа')
@section('header-title', 'Детали заказа')

@section('content')
<div class="min-h-screen bg-gray-50 pb-20">
    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="mx-3 mt-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="mx-3 mt-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
            {{ session('error') }}
        </div>
    @endif

    <!-- Order Header -->
    <div class="bg-white border-b px-3 py-4">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-lg font-semibold text-gray-900">Заказ #{{ $order->order_number }}</h1>
                <p class="text-sm text-gray-600">{{ $order->customer->name ?? 'Неизвестный клиент' }}</p>
            </div>
            <div class="text-right">
                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                    @if($order->orderStatus->name === 'approved') bg-orange-100 text-orange-800
                    @elseif($order->orderStatus->name === 'loaded') bg-blue-100 text-blue-800
                    @else bg-gray-100 text-gray-800 @endif">
                    {{ ucfirst($order->orderStatus->name) }}
                </span>
            </div>
        </div>
    </div>

    <!-- Order Details -->
    <div class="p-3 space-y-3">
        <!-- Customer Info -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Информация о клиенте</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Имя:</span>
                    <span class="font-medium">{{ $order->customer->name }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Телефон:</span>
                    <span class="font-medium">{{ $order->customer->phone }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Адрес:</span>
                    <span class="font-medium text-right">{{ $order->customer->address }}</span>
                </div>
            </div>
        </div>

        <!-- Order Info -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Информация о заказе</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Дата заказа:</span>
                    <span class="font-medium">{{ $order->order_date->format('d.m.Y H:i') }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Статус:</span>
                    <span class="font-medium">{{ ucfirst($order->orderStatus->name) }}</span>
                </div>
                @if($order->salesUser)
                <div class="flex justify-between">
                    <span class="text-gray-600">Продавец:</span>
                    <span class="font-medium">{{ $order->salesUser->name }}</span>
                </div>
                @endif
                @if($order->warehouseUser)
                <div class="flex justify-between">
                    <span class="text-gray-600">Склад:</span>
                    <span class="font-medium">{{ $order->warehouseUser->name }}</span>
                </div>
                @endif
                @if($order->deliveryUser)
                <div class="flex justify-between">
                    <span class="text-gray-600">Доставка:</span>
                    <span class="font-medium">{{ $order->deliveryUser->name }}</span>
                </div>
                @endif
            </div>
        </div>

        <!-- Order Items -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Товары ({{ $order->orderItems->count() }})</h3>
            <div class="space-y-2">
                @foreach($order->orderItems as $item)
                <div class="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900 truncate">{{ $item->product->name }}</p>
                        <p class="text-xs text-gray-500">SKU: {{ $item->product->sku }}</p>
                    </div>
                    <div class="text-right ml-2">
                        <p class="text-sm font-medium text-gray-900">{{ $item->quantity }} шт.</p>
                        <p class="text-xs text-gray-500">{{ number_format($item->unit_price, 0, ',', ' ') }} ₽</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <!-- Order Totals -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Итого</h3>
            <div class="space-y-1 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Сумма заказа:</span>
                    <span class="font-medium">{{ number_format($order->total_amount, 0, ',', ' ') }} ₽</span>
                </div>
                @if($order->discount_amount > 0)
                <div class="flex justify-between">
                    <span class="text-gray-600">Скидка:</span>
                    <span class="font-medium text-red-600">-{{ number_format($order->discount_amount, 0, ',', ' ') }} ₽</span>
                </div>
                @endif
                @if($order->shipping_amount > 0)
                <div class="flex justify-between">
                    <span class="text-gray-600">Доставка:</span>
                    <span class="font-medium">{{ number_format($order->shipping_amount, 0, ',', ' ') }} ₽</span>
                </div>
                @endif
                <div class="flex justify-between pt-2 border-t border-gray-200">
                    <span class="text-gray-900 font-medium">К оплате:</span>
                    <span class="text-gray-900 font-bold">{{ number_format($order->total_amount, 0, ',', ' ') }} ₽</span>
                </div>
            </div>
        </div>

        <!-- Notes -->
        @if($order->notes)
        <div class="bg-white rounded-lg shadow-sm p-3">
            <h3 class="text-sm font-medium text-gray-900 mb-2">Примечания</h3>
            <p class="text-sm text-gray-700">{{ $order->notes }}</p>
        </div>
        @endif

        <!-- Action Buttons -->
        <div class="bg-white rounded-lg shadow-sm p-3">
            @if($order->orderStatus->name === 'approved')
            <div class="space-y-2">
                <a href="{{ route('mobile.warehouse.orders.load-form', $order) }}" 
                   class="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                    Загрузить заказ
                </a>
            </div>
            @elseif($order->orderStatus->name === 'loaded')
            <div class="space-y-2">
                <p class="text-sm text-gray-600 text-center">Заказ уже загружен</p>
                @if(!$order->delivery_user_id)
                <p class="text-xs text-orange-600 text-center">Ожидает назначения доставщика</p>
                @else
                <p class="text-xs text-green-600 text-center">Назначен доставщику: {{ $order->deliveryUser->name }}</p>
                @endif
            </div>
            @endif
        </div>
    </div>
</div>
@endsection 