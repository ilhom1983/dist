@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Склад</h1>
                    <p class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</p>
                </div>
                <div class="text-right">
                    <p class="text-xs text-gray-500">{{ now()->format('d.m.Y') }}</p>
                    <p class="text-xs text-gray-500">{{ now()->format('H:i') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="mx-4 mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="mx-4 mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {{ session('error') }}
        </div>
    @endif

    <!-- Quick Stats -->
    <div class="p-4 grid grid-cols-2 gap-4">
        <!-- Orders to Load -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">К загрузке</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['orders_to_load'] }}</p>
                </div>
            </div>
        </div>

        <!-- Low Stock Alerts -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-yellow-100 rounded-lg">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Низкий запас</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['low_stock_alerts'] }}</p>
                </div>
            </div>
        </div>

        <!-- Out of Stock -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-red-100 rounded-lg">
                    <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Нет в наличии</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['out_of_stock'] }}</p>
                </div>
            </div>
        </div>

        <!-- Today's Loaded -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-green-100 rounded-lg">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Загружено сегодня</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['today_loaded_orders'] }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="p-4">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Быстрые действия</h2>
        <div class="grid grid-cols-2 gap-4">
            <a href="{{ route('mobile.warehouse.orders.index') }}" 
               class="bg-blue-600 text-white p-4 rounded-lg text-center hover:bg-blue-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
                <p class="font-medium">Заказы к загрузке</p>
                <p class="text-sm opacity-90">{{ $stats['orders_to_load'] }} заказов</p>
            </a>

            <a href="{{ route('mobile.warehouse.inventory.index') }}" 
               class="bg-green-600 text-white p-4 rounded-lg text-center hover:bg-green-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
                <p class="font-medium">Остатки</p>
                <p class="text-sm opacity-90">{{ $stats['total_products'] }} товаров</p>
            </a>

            <a href="{{ route('mobile.warehouse.inventory.index', ['stock_status' => 'low_stock']) }}" 
               class="bg-yellow-600 text-white p-4 rounded-lg text-center hover:bg-yellow-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                </svg>
                <p class="font-medium">Низкий запас</p>
                <p class="text-sm opacity-90">{{ $stats['low_stock_alerts'] }} товаров</p>
            </a>

            <a href="{{ route('mobile.warehouse.products.index') }}" 
               class="bg-purple-600 text-white p-4 rounded-lg text-center hover:bg-purple-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
                <p class="font-medium">Поиск товаров</p>
                <p class="text-sm opacity-90">Быстрый поиск</p>
            </a>
        </div>
    </div>

    <!-- Recent Orders to Load -->
    @if($ordersToLoad->count() > 0)
    <div class="p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Заказы к загрузке</h2>
            <a href="{{ route('mobile.warehouse.orders.index') }}" class="text-blue-600 text-sm font-medium">
                Все заказы
            </a>
        </div>
        <div class="space-y-3">
            @foreach($ordersToLoad as $order)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $order->order_number }}</p>
                        <p class="text-sm text-gray-500">{{ $order->customer->name }}</p>
                        <p class="text-xs text-gray-400">{{ $order->order_date->format('d.m.Y H:i') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900">{{ number_format($order->total_amount, 0, ',', ' ') }} ₽</p>
                        <p class="text-xs text-gray-500">{{ $order->orderItems->count() }} товаров</p>
                        <a href="{{ route('mobile.warehouse.orders.show', $order) }}" 
                           class="mt-2 inline-block bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-blue-700">
                            Загрузить
                        </a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Low Stock Products -->
    @if($lowStockProducts->count() > 0)
    <div class="p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Низкий запас</h2>
            <a href="{{ route('mobile.warehouse.inventory.index', ['stock_status' => 'low_stock']) }}" class="text-blue-600 text-sm font-medium">
                Все товары
            </a>
        </div>
        <div class="space-y-3">
            @foreach($lowStockProducts as $product)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $product->name }}</p>
                        <p class="text-sm text-gray-500">{{ $product->sku }}</p>
                        @if($product->category)
                        <p class="text-xs text-gray-400">{{ $product->category->name }}</p>
                        @endif
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium text-red-600">{{ $product->stock_quantity }} шт</p>
                        <p class="text-xs text-gray-500">мин: {{ $product->min_stock_level }}</p>
                        <a href="{{ route('mobile.warehouse.inventory.show', $product) }}" 
                           class="mt-2 inline-block bg-yellow-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-yellow-700">
                            Проверить
                        </a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Recent Activity -->
    @if($recentTransactions->count() > 0)
    <div class="p-4">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Последние операции</h2>
        <div class="space-y-3">
            @foreach($recentTransactions->take(5) as $transaction)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $transaction->product->name }}</p>
                        <p class="text-sm text-gray-500">
                            @switch($transaction->transaction_type)
                                @case('sale')
                                    Продажа
                                    @break
                                @case('purchase')
                                    Поступление
                                    @break
                                @case('adjustment')
                                    Корректировка
                                    @break
                                @case('transfer')
                                    Перемещение
                                    @break
                                @case('damage')
                                    Повреждение
                                    @break
                                @case('loss')
                                    Потеря
                                    @break
                                @default
                                    {{ $transaction->transaction_type }}
                            @endswitch
                        </p>
                        <p class="text-xs text-gray-400">{{ $transaction->created_at->format('d.m.Y H:i') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium {{ $transaction->quantity > 0 ? 'text-green-600' : 'text-red-600' }}">
                            {{ $transaction->quantity > 0 ? '+' : '' }}{{ $transaction->quantity }}
                        </p>
                        <p class="text-xs text-gray-500">{{ $transaction->createdBy->name }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.warehouse.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.warehouse.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.warehouse.inventory.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
                <span class="text-xs mt-1">Остатки</span>
            </a>
            <a href="{{ route('mobile.warehouse.products.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
                <span class="text-xs mt-1">Товары</span>
            </a>
        </div>
    </div>
</div>
@endsection 