@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Товары</h1>
                    <p class="text-sm text-gray-600">Просмотр товаров</p>
                </div>
                <a href="{{ route('mobile.warehouse.dashboard') }}" class="text-blue-600 text-sm font-medium">
                    Назад
                </a>
            </div>
        </div>
    </div>

    <!-- Search and Filters -->
    <div class="bg-white border-b">
        <div class="p-4">
            <form method="GET" class="space-y-4">
                <!-- Search -->
                <div>
                    <input type="text" name="search" value="{{ $search }}" 
                           placeholder="Поиск по названию, артикулу или штрихкоду..."
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Stock Status Filter -->
                <div>
                    <select name="stock_status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="all" {{ $stockStatus === 'all' ? 'selected' : '' }}>Все товары</option>
                        <option value="low_stock" {{ $stockStatus === 'low_stock' ? 'selected' : '' }}>Низкий запас</option>
                        <option value="out_of_stock" {{ $stockStatus === 'out_of_stock' ? 'selected' : '' }}>Нет в наличии</option>
                        <option value="in_stock" {{ $stockStatus === 'in_stock' ? 'selected' : '' }}>В наличии</option>
                    </select>
                </div>

                <!-- Category Filter -->
                @if($categories->count() > 0)
                <div>
                    <select name="category_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все категории</option>
                        @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{ $categoryId == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                        @endforeach
                    </select>
                </div>
                @endif

                <!-- Brand Filter -->
                @if($brands->count() > 0)
                <div>
                    <select name="brand_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все бренды</option>
                        @foreach($brands as $brand)
                        <option value="{{ $brand->id }}" {{ $brandId == $brand->id ? 'selected' : '' }}>
                            {{ $brand->name }}
                        </option>
                        @endforeach
                    </select>
                </div>
                @endif

                <!-- Filter Buttons -->
                <div class="flex space-x-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700">
                        Применить
                    </button>
                    <a href="{{ route('mobile.warehouse.products.index') }}" class="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium text-center hover:bg-gray-300">
                        Сбросить
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Products List -->
    @if($products->count() > 0)
        <div class="divide-y divide-gray-200">
            @foreach($products as $product)
            <div class="bg-white">
                <a href="{{ route('mobile.warehouse.products.show', $product) }}" class="block p-4 hover:bg-gray-50">
                    <div class="flex items-center justify-between">
                        <div class="flex-1">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                                        <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-3 flex-1">
                                    <p class="text-sm font-medium text-gray-900">{{ $product->name }}</p>
                                    <p class="text-xs text-gray-500">{{ $product->sku }}</p>
                                    @if($product->category)
                                    <p class="text-xs text-gray-400">{{ $product->category->name }}</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="flex items-center justify-end">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                                    @if($product->stock_quantity <= 0) bg-red-100 text-red-800
                                    @elseif($product->stock_quantity <= $product->min_stock_level) bg-yellow-100 text-yellow-800
                                    @else bg-green-100 text-green-800 @endif">
                                    {{ $product->stock_quantity }} шт
                                </span>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">мин: {{ $product->min_stock_level }}</p>
                            <p class="text-sm font-medium text-gray-900">{{ number_format($product->price, 0, ',', ' ') }} ₽</p>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach
        </div>

        <!-- Pagination -->
        @if($products->hasPages())
        <div class="bg-white px-4 py-3 border-t border-gray-200">
            {{ $products->links() }}
        </div>
        @endif
    @else
        <div class="bg-white p-8 text-center">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
            </svg>
            <h3 class="mt-2 text-sm font-medium text-gray-900">Товары не найдены</h3>
            <p class="mt-1 text-sm text-gray-500">Попробуйте изменить параметры поиска.</p>
        </div>
    @endif

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.warehouse.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.warehouse.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.warehouse.inventory.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
                <span class="text-xs mt-1">Остатки</span>
            </a>
            <a href="{{ route('mobile.warehouse.products.index') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
                <span class="text-xs mt-1">Товары</span>
            </a>
        </div>
    </div>
</div>
@endsection 