<!-- Return Items Modal -->
<div id="returnItemsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-10 mx-auto p-5 border w-11/12 md:w-4/5 lg:w-3/4 shadow-lg rounded-md bg-white max-h-screen overflow-y-auto">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-medium text-gray-900">Возврат товаров</h3>
                <button onclick="closeModal('returnItemsModal')" class="text-gray-400 hover:text-gray-600" title="Закрыть" aria-label="Закрыть модальное окно">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form action="{{ route("mobile.delivery.orders.return-items") }}" method="POST">
                @csrf
                <input type="hidden" id="returnItemsOrderId" name="order_id">
                <div id="returnItemsList" class="mb-4">
                    <!-- Items will be loaded dynamically -->
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeModal('returnItemsModal')" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">Отмена</button>
                    <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">Обработать возврат</button>
                </div>
            </form>
        </div>
    </div>
</div>
