@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Платеж #{{ $payment->id }}</h1>
                    <p class="text-sm text-gray-600">Детали платежа</p>
                </div>
                <a href="{{ route('mobile.delivery.payments.index') }}" class="text-blue-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="mx-4 mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="mx-4 mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {{ session('error') }}
        </div>
    @endif

    <!-- Payment Details -->
    <div class="p-4">
        <div class="bg-white rounded-lg shadow-sm border p-4 mb-4">
            <h2 class="text-lg font-semibold text-gray-900 mb-3">Информация о платеже</h2>
            
            <div class="grid grid-cols-1 gap-3">
                <div>
                    <p class="text-sm font-medium text-gray-500">ID платежа</p>
                    <p class="text-gray-900">#{{ $payment->id }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Сумма</p>
                    <p class="text-xl font-semibold text-green-600">{{ number_format($payment->amount, 0, ',', ' ') }} ₽</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Способ оплаты</p>
                    <p class="text-gray-900">{{ ucfirst($payment->paymentMethod->name ?? 'Наличные') }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Статус</p>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        {{ ucfirst($payment->paymentStatus->name ?? 'Оплачено') }}
                    </span>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Дата платежа</p>
                    <p class="text-gray-900">{{ $payment->payment_date->format('d.m.Y H:i') }}</p>
                </div>
                
                @if($payment->reference_number)
                <div>
                    <p class="text-sm font-medium text-gray-500">Номер ссылки</p>
                    <p class="text-gray-900">{{ $payment->reference_number }}</p>
                </div>
                @endif
                
                @if($payment->notes)
                <div>
                    <p class="text-sm font-medium text-gray-500">Примечания</p>
                    <p class="text-gray-900">{{ $payment->notes }}</p>
                </div>
                @endif
            </div>
        </div>

        <!-- Order Information -->
        <div class="bg-white rounded-lg shadow-sm border p-4 mb-4">
            <h2 class="text-lg font-semibold text-gray-900 mb-3">Информация о заказе</h2>
            
            <div class="grid grid-cols-1 gap-3">
                <div>
                    <p class="text-sm font-medium text-gray-500">Номер заказа</p>
                    <p class="text-gray-900">{{ $payment->order->order_number }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Клиент</p>
                    <p class="text-gray-900">{{ $payment->order->customer->name }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Телефон клиента</p>
                    <p class="text-gray-900">{{ $payment->order->customer->phone }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Адрес доставки</p>
                    <p class="text-gray-900">{{ $payment->order->customer->address }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Общая сумма заказа</p>
                    <p class="text-gray-900">{{ number_format($payment->order->total_amount, 0, ',', ' ') }} ₽</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Оплачено</p>
                    <p class="text-gray-900">{{ number_format($payment->order->paid_amount, 0, ',', ' ') }} ₽</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Остаток к оплате</p>
                    <p class="text-gray-900 {{ $payment->order->remaining_amount > 0 ? 'text-red-600' : 'text-green-600' }}">
                        {{ number_format($payment->order->remaining_amount, 0, ',', ' ') }} ₽
                    </p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Статус заказа</p>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        @if($payment->order->orderStatus && $payment->order->orderStatus->name === 'delivered') bg-green-100 text-green-800
                        @elseif($payment->order->orderStatus && $payment->order->orderStatus->name === 'paid') bg-blue-100 text-blue-800
                        @elseif($payment->order->orderStatus && $payment->order->orderStatus->name === 'loaded') bg-orange-100 text-orange-800
                        @else bg-gray-100 text-gray-800 @endif">
                        @if($payment->order->orderStatus && $payment->order->orderStatus->name === 'delivered') Доставлено
                        @elseif($payment->order->orderStatus && $payment->order->orderStatus->name === 'paid') Оплачено
                        @elseif($payment->order->orderStatus && $payment->order->orderStatus->name === 'loaded') Загружено
                        @else {{ $payment->order->orderStatus ? ucfirst($payment->order->orderStatus->name) : 'Статус' }}
                        @endif
                    </span>
                </div>
            </div>
        </div>

        <!-- Created By Information -->
        @if($payment->createdBy)
        <div class="bg-white rounded-lg shadow-sm border p-4 mb-4">
            <h2 class="text-lg font-semibold text-gray-900 mb-3">Информация о создателе</h2>
            
            <div class="grid grid-cols-1 gap-3">
                <div>
                    <p class="text-sm font-medium text-gray-500">Создал</p>
                    <p class="text-gray-900">{{ $payment->createdBy->name }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Роль</p>
                    <p class="text-gray-900">{{ ucfirst($payment->createdBy->role) }}</p>
                </div>
                
                <div>
                    <p class="text-sm font-medium text-gray-500">Дата создания</p>
                    <p class="text-gray-900">{{ $payment->created_at->format('d.m.Y H:i') }}</p>
                </div>
            </div>
        </div>
        @endif

        <!-- Actions -->
        <div class="bg-white rounded-lg shadow-sm border p-4">
            <h2 class="text-lg font-semibold text-gray-900 mb-3">Действия</h2>
            
            <div class="space-y-3">
                @if($payment->order->remaining_amount > 0)
                <a href="{{ route('mobile.delivery.payments.create', $payment->order) }}" 
                   class="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    Создать дополнительный платеж
                </a>
                @endif
                
                @if($payment->order->customer->latitude && $payment->order->customer->longitude)
                <button onclick="openRoute({{ $payment->order->customer->latitude }}, {{ $payment->order->customer->longitude }})" 
                        class="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m0 0L9 7"></path>
                    </svg>
                    Построить маршрут к клиенту
                </button>
                @endif
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.delivery.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.delivery.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.delivery.debtors.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span class="text-xs mt-1">Должники</span>
            </a>
            <a href="{{ route('mobile.delivery.payments.index') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <span class="text-xs mt-1">Платежи</span>
            </a>
        </div>
    </div>
</div>

<script>
function openRoute(latitude, longitude) {
    const yandexNavUrl = `yandexnavi://build_route_on_map?lat_to=${latitude}&lon_to=${longitude}`;
    const yandexMapsUrl = `https://yandex.ru/maps/?rtext=~${latitude},${longitude}&rtt=auto`;
    
    // Try to open Yandex Navigator app, fallback to Yandex Maps
    window.location.href = yandexNavUrl;
    
    // Fallback to Yandex Maps in case app is not installed
    setTimeout(() => {
        window.open(yandexMapsUrl, '_blank');
    }, 2000);
}
</script>
@endsection 