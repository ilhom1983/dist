@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Создать платеж</h1>
                    <p class="text-sm text-gray-600">Сбор платежа от клиента</p>
                </div>
                <a href="{{ route('mobile.delivery.payments.index') }}" class="text-blue-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="mx-4 mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="mx-4 mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {{ session('error') }}
        </div>
    @endif

    <!-- Payment Form -->
    <div class="p-4">
        <form action="{{ route('mobile.delivery.payments.store') }}" method="POST">
            @csrf
            
            <!-- Order Selection -->
            <div class="bg-white rounded-lg shadow-sm border p-4 mb-4">
                <h2 class="text-lg font-semibold text-gray-900 mb-3">Выбор заказа</h2>
                
                @if($order)
                    <!-- Pre-selected order -->
                    <div class="border rounded-lg p-3 bg-blue-50">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium text-gray-900">{{ $order->order_number }}</p>
                                <p class="text-sm text-gray-600">{{ $order->customer->name }}</p>
                                <p class="text-xs text-gray-500">{{ $order->customer->phone }}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-900">Общая сумма: {{ number_format($order->total_amount, 0, ',', ' ') }} ₽</p>
                                <p class="text-sm text-red-600">К доплате: {{ number_format($order->remaining_amount, 0, ',', ' ') }} ₽</p>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="order_id" value="{{ $order->id }}">
                @else
                    <!-- Order dropdown -->
                    <div class="mb-3">
                        <label for="order_id" class="block text-sm font-medium text-gray-700 mb-2">Заказ</label>
                        <select name="order_id" id="order_id" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="">Выберите заказ</option>
                            @foreach($orders as $orderOption)
                                <option value="{{ $orderOption->id }}" 
                                        data-remaining="{{ $orderOption->remaining_amount }}"
                                        data-customer="{{ $orderOption->customer->name }}">
                                    {{ $orderOption->order_number }} - {{ $orderOption->customer->name }} 
                                    ({{ number_format($orderOption->remaining_amount, 0, ',', ' ') }} ₽)
                                </option>
                            @endforeach
                        </select>
                        @error('order_id')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                @endif
            </div>

            <!-- Payment Details -->
            <div class="bg-white rounded-lg shadow-sm border p-4 mb-4">
                <h2 class="text-lg font-semibold text-gray-900 mb-3">Детали платежа</h2>
                
                <!-- Amount -->
                <div class="mb-4">
                    <label for="amount" class="block text-sm font-medium text-gray-700 mb-2">Сумма платежа</label>
                    <div class="relative">
                        <input type="number" 
                               name="amount" 
                               id="amount" 
                               step="0.01" 
                               min="0.01" 
                               max="{{ $order ? $order->remaining_amount : 999999 }}"
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 pr-12" 
                               placeholder="0.00" 
                               required>
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 sm:text-sm">₽</span>
                        </div>
                    </div>
                    @if($order)
                        <p class="mt-1 text-sm text-gray-500">Максимальная сумма: {{ number_format($order->remaining_amount, 0, ',', ' ') }} ₽</p>
                    @endif
                    @error('amount')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Payment Method -->
                <div class="mb-4">
                    <label for="payment_method_id" class="block text-sm font-medium text-gray-700 mb-2">Способ оплаты</label>
                    <select name="payment_method_id" id="payment_method_id" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                        <option value="">Выберите способ оплаты</option>
                        @foreach($paymentMethods as $method)
                            <option value="{{ $method->id }}">{{ ucfirst($method->name) }}</option>
                        @endforeach
                    </select>
                    @error('payment_method_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Notes -->
                <div class="mb-4">
                    <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">Примечания</label>
                    <textarea name="notes" 
                              id="notes" 
                              rows="3" 
                              class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" 
                              placeholder="Дополнительная информация о платеже"></textarea>
                    @error('notes')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Submit Button -->
            <div class="bg-white rounded-lg shadow-sm border p-4">
                <button type="submit" 
                        class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    Создать платеж
                </button>
            </div>
        </form>
    </div>

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.delivery.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.delivery.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.delivery.debtors.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span class="text-xs mt-1">Должники</span>
            </a>
            <a href="{{ route('mobile.delivery.payments.index') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <span class="text-xs mt-1">Платежи</span>
            </a>
        </div>
    </div>
</div>

<script>
// Auto-fill amount when order is selected
document.getElementById('order_id').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const remainingAmount = selectedOption.getAttribute('data-remaining');
    const amountInput = document.getElementById('amount');
    
    if (remainingAmount) {
        amountInput.value = remainingAmount;
        amountInput.max = remainingAmount;
    }
});

// Validate amount input
document.getElementById('amount').addEventListener('input', function() {
    const maxAmount = this.getAttribute('max');
    if (maxAmount && parseFloat(this.value) > parseFloat(maxAmount)) {
        this.value = maxAmount;
    }
});
</script>
@endsection 