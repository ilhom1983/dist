@extends('layouts.mobile')

@section('title', 'Доставка')
@section('header-title', 'Доставка')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Доставка</h1>
                    <p class="text-sm text-gray-600">{{ auth()->guard('tenant')->user()->name }}</p>
                </div>
                <div class="text-right">
                    <p class="text-xs text-gray-500">{{ now()->format('d.m.Y') }}</p>
                    <p class="text-xs text-gray-500">{{ now()->format('H:i') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="mx-4 mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="mx-4 mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {{ session('error') }}
        </div>
    @endif

    @if(session('info'))
        <div class="mx-4 mt-4 p-4 bg-blue-100 border border-blue-400 text-blue-700 rounded-lg">
            {{ session('info') }}
        </div>
    @endif

    <!-- Quick Stats -->
    <div class="p-4 grid grid-cols-2 gap-4">
        <!-- Orders to Deliver -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">К доставке</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['orders_to_deliver'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <!-- In Transit -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-orange-100 rounded-lg">
                    <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">В пути</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['in_transit'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <!-- Today's Deliveries -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-green-100 rounded-lg">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Доставлено сегодня</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $stats['today_delivered'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <!-- Today's Payments -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center">
                <div class="p-2 bg-purple-100 rounded-lg">
                    <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-500">Сегодня собрано</p>
                    <p class="text-xl font-semibold text-gray-900">{{ number_format($stats['today_payments'] ?? 0, 0, ',', ' ') }} ₽</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Action Buttons -->
    <div class="p-4">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Быстрые действия</h2>
        <div class="grid grid-cols-2 gap-4">
            <!-- Orders -->
            <a href="{{ route('mobile.delivery.orders.index') }}" 
               class="bg-blue-600 text-white p-4 rounded-lg text-center hover:bg-blue-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <p class="font-medium">Заказы</p>
                <p class="text-sm opacity-90">{{ $stats['orders_to_deliver'] ?? 0 }} к доставке</p>
            </a>

            <!-- Route -->
            <button onclick="openYandexNavigator()" 
                    class="bg-green-600 text-white p-4 rounded-lg text-center hover:bg-green-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m0 0L9 7"></path>
                </svg>
                <p class="font-medium">Маршрут</p>
                <p class="text-sm opacity-90">Открыть навигатор</p>
            </button>

            <!-- Debtors -->
            <a href="{{ route('mobile.delivery.debtors.index') }}" 
               class="bg-yellow-600 text-white p-4 rounded-lg text-center hover:bg-yellow-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <p class="font-medium">Должники</p>
                <p class="text-sm opacity-90">{{ $stats['pending_commitments'] ?? 0 }} обязательств</p>
            </a>

            <!-- Payments -->
            <a href="{{ route('mobile.delivery.payments.index') }}" 
               class="bg-purple-600 text-white p-4 rounded-lg text-center hover:bg-purple-700">
                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <p class="font-medium">Платежи</p>
                <p class="text-sm opacity-90">Собрать платежи</p>
            </a>
        </div>
    </div>

    <!-- Orders to Deliver -->
    @if(($ordersToDeliver->count() ?? 0) > 0)
    <div class="p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Заказы к доставке</h2>
            <a href="{{ route('mobile.delivery.orders.index') }}" class="text-blue-600 text-sm font-medium">
                Все заказы
            </a>
        </div>
        <div class="space-y-3">
            @foreach($ordersToDeliver as $order)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $order->order_number }}</p>
                        <p class="text-sm text-gray-500">{{ $order->customer->name }}</p>
                        <p class="text-xs text-gray-400">{{ $order->customer->address }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900">{{ number_format($order->total_amount, 0, ',', ' ') }} ₽</p>
                        <p class="text-xs text-gray-500">{{ $order->orderItems->count() ?? 0 }} товаров</p>
                        <div class="mt-2 space-x-2">
                            <a href="{{ route('mobile.delivery.orders.show', $order) }}" 
                               class="inline-block bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-blue-700">
                                Детали
                            </a>
                            @if(!$order->delivery_user_id)
                            <form action="{{ route('mobile.delivery.orders.start', $order) }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-green-700">
                                    Взять
                                </button>
                            </form>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Recent Debtors -->
    @if(($debtors->count() ?? 0) > 0)
    <div class="p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Должники</h2>
            <a href="{{ route('mobile.delivery.debtors.index') }}" class="text-blue-600 text-sm font-medium">
                Все должники
            </a>
        </div>
        <div class="space-y-3">
            @foreach($debtors as $debtor)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $debtor->name }}</p>
                        <p class="text-sm text-gray-500">{{ $debtor->phone }}</p>
                        <p class="text-xs text-gray-400">{{ $debtor->address }}</p>
                    </div>
                    <div class="text-right">
                        @php $totalDebt = $debtor->commitments->sum('remaining_amount') @endphp
                        <p class="text-sm font-medium text-red-600">{{ number_format($totalDebt, 0, ',', ' ') }} ₽</p>
                        <p class="text-xs text-gray-500">{{ $debtor->commitments->count() ?? 0 }} обязательств</p>
                        <a href="{{ route('mobile.delivery.debtors.show', $debtor) }}" 
                           class="mt-2 inline-block bg-yellow-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-yellow-700">
                            Проверить
                        </a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Recent Payments -->
    @if(($recentPayments->count() ?? 0) > 0)
    <div class="p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Последние платежи</h2>
            <a href="{{ route('mobile.delivery.payments.index') }}" class="text-blue-600 text-sm font-medium">
                Все платежи
            </a>
        </div>
        <div class="space-y-3">
            @foreach($recentPayments as $payment)
            <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center justify-between">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $payment->order->customer->name }}</p>
                        <p class="text-sm text-gray-500">{{ $payment->order->order_number }}</p>
                        <p class="text-xs text-gray-400">{{ $payment->created_at->format('d.m.Y H:i') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-medium text-green-600">{{ number_format($payment->amount, 0, ',', ' ') }} ₽</p>
                        <p class="text-xs text-gray-500">{{ $payment->paymentMethod->name ?? 'Наличные' }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Bottom Navigation -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div class="flex justify-around">
            <a href="{{ route('mobile.delivery.dashboard') }}" class="flex flex-col items-center py-2 px-3 text-blue-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                </svg>
                <span class="text-xs mt-1">Главная</span>
            </a>
            <a href="{{ route('mobile.delivery.orders.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <span class="text-xs mt-1">Заказы</span>
            </a>
            <a href="{{ route('mobile.delivery.debtors.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span class="text-xs mt-1">Должники</span>
            </a>
            <a href="{{ route('mobile.delivery.payments.index') }}" class="flex flex-col items-center py-2 px-3 text-gray-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
                <span class="text-xs mt-1">Платежи</span>
            </a>
        </div>
    </div>
</div>

<script>
function openYandexNavigator() {
    // Check if we have orders with addresses to visit
    @if($ordersToDeliver->count() > 0)
        // Get first order's coordinates
        @php $firstOrder = $ordersToDeliver->first() @endphp
        @if($firstOrder->latitude && $firstOrder->longitude && is_numeric($firstOrder->latitude) && is_numeric($firstOrder->longitude))
            const latitude = {{ $firstOrder->latitude }};
            const longitude = {{ $firstOrder->longitude }};
            
            if (latitude && longitude && !isNaN(latitude) && !isNaN(longitude)) {
                // Try to open Yandex Navigator app
                const yandexNavUrl = `yandexnavi://build_route_on_map?lat_to=${latitude}&lon_to=${longitude}`;
                const yandexMapsUrl = `https://yandex.ru/maps/?rtext=~${latitude},${longitude}&rtt=auto`;
                
                // Try to open Yandex Navigator app, fallback to Yandex Maps
                window.location.href = yandexNavUrl;
                
                // Fallback to Yandex Maps in case app is not installed
                setTimeout(() => {
                    window.open(yandexMapsUrl, '_blank');
                }, 2000);
            } else {
                alert('Некорректные координаты для построения маршрута');
            }
        @else
            alert('Нет доступных адресов для построения маршрута');
        @endif
    @else
        alert('Нет заказов для доставки');
    @endif
}
</script>
@endsection 