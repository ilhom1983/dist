@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b sticky top-0 z-40">
        <div class="px-4 py-3">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-lg font-semibold text-gray-900">Заказ #{{ $order->order_number }}</h1>
                    <p class="text-sm text-gray-600">{{ $order->customer->name ?? 'Неизвестный клиент' }}</p>
                </div>
                <a href="{{ route('mobile.delivery.orders.index') }}" class="text-blue-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Status Dropdown -->
    <div class="bg-white border-b px-4 py-3">
        <label class="block text-sm font-medium text-gray-700 mb-2">Статус заказа</label>
    <select id="statusSelect" onchange="handleStatusChange()" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
        <option value="">Выберите статус</option>
        <option value="delivered">Доставлено</option>
        <option value="paid">Оплачено</option>
        <option value="returned">Возврат</option>
    </select>
    </div>

    <!-- Order Details Section (Default View) -->
    <div id="orderDetailsSection" class="p-4">
        <div class="bg-white rounded-lg shadow-sm p-4 mb-4">
            <div class="flex justify-between items-start mb-3">
                <div>
                    <h2 class="text-lg font-bold text-gray-900">{{ $order->customer->name ?? 'Неизвестный клиент' }}</h2>
                    <p class="text-sm text-gray-600">{{ $order->customer->phone ?? 'Нет телефона' }}</p>
                </div>
                <div class="text-right">
                    <p class="text-lg font-bold text-gray-900">{{ number_format($order->total_amount, 0) }} ₽</p>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3 text-sm">
                <div>
                    <p class="text-gray-500">Дата заказа</p>
                    <p class="font-medium">{{ $order->created_at->format('d.m.Y H:i') }}</p>
                </div>
                <div>
                    <p class="text-gray-500">Дата доставки</p>
                    <p class="font-medium">{{ $order->delivery_date?->format('d.m.Y H:i') ?? 'Не указана' }}</p>
                </div>
            </div>
        </div>

        <!-- Order Items (Read-only) -->
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-3">Товары в заказе</h3>
            <div class="space-y-3">
                @foreach($order->orderItems as $item)
                <div class="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                    <div class="flex-1">
                        <p class="font-medium text-gray-900">{{ $item->product->name ?? 'Неизвестный товар' }}</p>
                        <p class="text-sm text-gray-600">{{ $item->product->sku ?? 'Нет артикула' }}</p>
                    </div>
                    <div class="text-right">
                        <p class="font-medium">{{ $item->quantity }} шт.</p>
                        <p class="text-sm text-gray-600">{{ number_format($item->unit_price, 0) }} ₽</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Commitments Modal Section (Hidden by default) -->
    <div id="commitmentsSection" class="hidden p-4">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Создать обязательство</h3>
            <form id="commitmentsForm" onsubmit="submitCommitment(event)">
                <input type="hidden" id="commitmentsOrderId" name="order_id" value="{{ $order->id }}">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Сумма обязательства</label>
                    <input type="number" name="amount" step="0.01" value="{{ $order->total_amount }}" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Дата выполнения</label>
                    <input type="date" name="due_date" value="{{ date("Y-m-d") }}" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Описание</label>
                    <textarea name="description" rows="3" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>
                
                <div class="flex space-x-3">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700">
                        Создать обязательство
                    </button>
                    <button type="button" onclick="showOrderDetails()" class="flex-1 bg-gray-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-600">
                        Назад
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Payments Modal Section (Hidden by default) -->
    <div id="paymentsSection" class="hidden p-4">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Создать платеж</h3>
            <form id="paymentsForm" onsubmit="submitPayment(event)">
                <input type="hidden" id="paymentsOrderId" name="order_id" value="{{ $order->id }}">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Сумма платежа</label>
                    <input type="number" name="amount" step="0.01" value="{{ $order->total_amount }}" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Дата платежа</label>
                    <input type="date" name="payment_date" value="{{ date("Y-m-d") }}" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Способ оплаты</label>
                    <select name="payment_method" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="cash">Наличные</option>
                        <option value="card">Карта</option>
                        <option value="transfer">Перевод</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Описание</label>
                    <textarea name="description" rows="3" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>
                
                <div class="flex space-x-3">
                    <button type="submit" class="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700">
                        Создать платеж
                    </button>
                    <button type="button" onclick="showOrderDetails()" class="flex-1 bg-gray-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-600">
                        Назад
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Return Items Section (Hidden by default) -->
    <div id="returnItemsSection" class="hidden p-4">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Возврат товаров</h3>
            
            <form id="returnItemsForm" onsubmit="submitReturnItems(event)">
                <input type="hidden" name="order_id" value="{{ $order->id }}">
                
                <!-- Order Level Return Reason -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Причина возврата заказа</label>
                    <select name="return_reason_id" required class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Выберите причину возврата</option>
                        @foreach(\App\Models\ReturnReason::active()->get() as $reason)
                            <option value="{{ $reason->id }}">{{ $reason->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                <!-- Order Items List -->
                <div class="space-y-3 mb-4">
                    @foreach($order->orderItems as $item)
                    <div class="border border-gray-200 rounded-lg p-3">
                        <!-- Product Info -->
                        <div class="mb-3">
                            <h4 class="font-medium text-gray-900">{{ $item->product->name }}</h4>
                            <p class="text-sm text-gray-600">{{ $item->product->sku ?? 'Без SKU' }}</p>
                            <p class="text-sm text-gray-600">Цена: {{ number_format($item->unit_price, 0, ',', ' ') }} ₽</p>
                            <p class="text-sm text-gray-600">Заказано: {{ $item->quantity }} шт.</p>
                        </div>
                        
                        <!-- Return Quantity Input -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Количество для возврата</label>
                            <input type="number" 
                                   name="return_items[{{ $item->id }}][return_quantity]" 
                                   min="0" 
                                   max="{{ $item->quantity - ($item->return_qty ?? 0) }}"
                                   value="0"
                                   class="w-full p-2 border border-gray-300 rounded text-sm">
                        </div>
                    </div>
                    @endforeach
                </div>
                
                <!-- Action Buttons -->
                <div class="flex space-x-3">
                    <button type="submit" class="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-red-700">
                        Обработать возврат
                    </button>
                    <button type="button" onclick="showOrderDetails()" class="flex-1 bg-gray-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-600">
                        Назад
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function handleStatusChange() {
    const status = document.getElementById('statusSelect').value;
    
    // Hide all sections first
    document.getElementById('orderDetailsSection').classList.add('hidden');
    document.getElementById('commitmentsSection').classList.add('hidden');
    document.getElementById('paymentsSection').classList.add('hidden');
    document.getElementById('returnItemsSection').classList.add('hidden');
    
    // Reset return section position to its original location (at the end of the main container)
    const returnSection = document.getElementById('returnItemsSection');
    const mainContainer = document.querySelector('.min-h-screen');
    if (mainContainer && returnSection.parentElement !== mainContainer) {
        mainContainer.appendChild(returnSection);
    }
    
    // Show appropriate section based on status
    if (status === 'delivered') {
        document.getElementById('commitmentsSection').classList.remove('hidden');
    } else if (status === 'paid') {
        document.getElementById('paymentsSection').classList.remove('hidden');
    } else if (status === 'returned') {
        returnSection.classList.remove('hidden');
        
        // Position the return section right after the status dropdown section
        const statusSection = document.querySelector('.bg-white.border-b.px-4.py-3');
        if (statusSection && statusSection.parentElement) {
            statusSection.parentElement.insertBefore(returnSection, statusSection.nextSibling);
        }
        
        // Scroll to the section
        returnSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        document.getElementById('orderDetailsSection').classList.remove('hidden');
    }
}

function showOrderDetails() {
    // Hide all sections
    document.getElementById('commitmentsSection').classList.add('hidden');
    document.getElementById('paymentsSection').classList.add('hidden');
    document.getElementById('returnItemsSection').classList.add('hidden');
    
    // Reset return section position to its original location
    const returnSection = document.getElementById('returnItemsSection');
    const mainContainer = document.querySelector('.min-h-screen');
    if (mainContainer && returnSection.parentElement !== mainContainer) {
        mainContainer.appendChild(returnSection);
    }
    
    // Show order details
    document.getElementById('orderDetailsSection').classList.remove('hidden');
}

function submitCommitment(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    fetch('{{ route("mobile.delivery.commitments.store") }}', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Обязательство создано успешно!');
            showOrderDetails();
        } else {
            alert('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при создании обязательства');
    });
}

function submitPayment(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    fetch('{{ route("mobile.delivery.payments.store") }}', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Платеж создан успешно!');
            showOrderDetails();
        } else {
            alert('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при создании платежа');
    });
}

function submitReturnItems(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    fetch('{{ route("mobile.delivery.orders.return-items") }}', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Возврат обработан успешно!');
            showOrderDetails();
        } else {
            alert('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при обработке возврата');
    });
}
</script>
@endsection
