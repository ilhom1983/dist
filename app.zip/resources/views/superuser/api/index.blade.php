<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление API - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="apiData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление API</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">Last updated: <span x-text="new Date().toLocaleTimeString()"></span></span>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- API Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Интеграций</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $apiStats['total_integrations'] }}</p>
                        <p class="text-sm text-green-600 mt-1">{{ $apiStats['active_integrations'] }} Активных</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-plug"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Запросов Сегодня</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($apiStats['total_requests_today']) }}</p>
                        <p class="text-sm text-green-600 mt-1">{{ $apiStats['success_rate'] }} Успешность</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Среднее Время Ответа</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $apiStats['average_response_time'] }}</p>
                        <p class="text-sm text-red-600 mt-1">{{ $apiStats['error_rate'] }} Ошибок</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Нарушения Лимитов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $rateLimits['violations']['today'] }}</p>
                        <p class="text-sm text-yellow-600 mt-1">Today</p>
                    </div>
                    <div class="text-red-500 text-3xl">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- API Usage Chart -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">API Usage Trends</h3>
            <canvas id="apiUsageChart" width="400" height="200"></canvas>
        </div>

        <!-- API Integrations -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">API Integrations</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenant</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">API Key</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Used</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($integrations as $integration)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                        {{ strtoupper(substr($integration->tenant->name ?? 'N/A', 0, 1)) }}
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900">{{ $integration->tenant->name ?? 'N/A' }}</div>
                                        <div class="text-sm text-gray-500">{{ $integration->tenant->domain ?? 'N/A' }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900 font-mono">{{ substr($integration->api_key, 0, 20) }}...</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    @if($integration->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    @if($integration->is_active) Active @else Inactive @endif
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ number_format($integration->usage_count) }} requests
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $integration->last_used_at ? $integration->last_used_at->diffForHumans() : 'Never' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <button @click="regenerateKey({{ $integration->id }})" class="text-blue-600 hover:text-blue-900">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <button @click="toggleStatus({{ $integration->id }})" class="text-green-600 hover:text-green-900">
                                        <i class="fas fa-power-off"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Error Analysis -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Error Types</h3>
                <div class="space-y-3">
                    @foreach($errors['error_types'] as $type => $count)
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">{{ ucwords(str_replace('_', ' ', $type)) }}</span>
                        <div class="flex items-center space-x-2">
                            <div class="w-16 bg-gray-200 rounded-full h-2">
                                <div class="bg-red-600 h-2 rounded-full" style="width: {{ ($count / max($errors['error_types'])) * 100 }}%"></div>
                            </div>
                            <span class="text-sm font-medium text-gray-900">{{ $count }}</span>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Top API Users</h3>
                <div class="space-y-3">
                    @foreach($topUsers->take(5) as $user)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                {{ strtoupper(substr($user->tenant->name ?? 'N/A', 0, 1)) }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $user->tenant->name ?? 'N/A' }}</p>
                                <p class="text-sm text-gray-600">{{ number_format($user->request_count) }} requests</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-medium text-green-600">{{ $user->success_rate }}%</p>
                            <p class="text-xs text-gray-600">{{ $user->error_count }} errors</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Recent API Activity -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent API Activity</h3>
            <div class="space-y-3" id="apiLogs">
                <!-- API logs will be loaded here -->
            </div>
            <button @click="loadUsageLogs()" class="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                <i class="fas fa-sync-alt mr-2"></i>Refresh Logs
            </button>
        </div>
    </div>

    <script>
        function apiData() {
            return {
                init() {
                    this.initChart();
                    this.loadUsageLogs();
                },
                
                initChart() {
                    const ctx = document.getElementById('apiUsageChart').getContext('2d');
                    const usageData = @json($usageMetrics);
                    
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['Today', 'Yesterday', 'This Week', 'Last Week'],
                            datasets: [{
                                label: 'Requests',
                                data: [
                                    usageData.today.requests,
                                    usageData.yesterday.requests,
                                    usageData.this_week.requests,
                                    usageData.last_week.requests
                                ],
                                borderColor: 'rgb(59, 130, 246)',
                                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                                tension: 0.4
                            }, {
                                label: 'Errors',
                                data: [
                                    usageData.today.errors,
                                    usageData.yesterday.errors,
                                    usageData.this_week.errors,
                                    usageData.last_week.errors
                                ],
                                borderColor: 'rgb(239, 68, 68)',
                                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'top',
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                },
                
                async regenerateKey(id) {
                    if (!confirm('Are you sure you want to regenerate the API key? This will invalidate the current key.')) {
                        return;
                    }
                    
                    try {
                        const response = await fetch(`/superuser/api/regenerate-key/${id}`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert('API key regenerated successfully!');
                            location.reload();
                        } else {
                            alert('Failed to regenerate API key: ' + data.message);
                        }
                    } catch (error) {
                        alert('Error regenerating API key: ' + error.message);
                    }
                },
                
                async toggleStatus(id) {
                    try {
                        const response = await fetch(`/superuser/api/toggle-status/${id}`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Failed to toggle status: ' + data.message);
                        }
                    } catch (error) {
                        alert('Error toggling status: ' + error.message);
                    }
                },
                
                async loadUsageLogs() {
                    try {
                        const response = await fetch('/superuser/api/usage-logs');
                        const logs = await response.json();
                        
                        const logsContainer = document.getElementById('apiLogs');
                        logsContainer.innerHTML = '';
                        
                        logs.forEach(log => {
                            const logElement = document.createElement('div');
                            logElement.className = 'flex items-center justify-between p-3 bg-gray-50 rounded-lg';
                            
                            const statusColor = log.status >= 400 ? 'text-red-600' : 'text-green-600';
                            const statusIcon = log.status >= 400 ? 'fas fa-times-circle' : 'fas fa-check-circle';
                            
                            logElement.innerHTML = `
                                <div class="flex items-center space-x-3">
                                    <i class="${statusIcon} ${statusColor}"></i>
                                    <div>
                                        <p class="font-medium text-gray-800">${log.tenant} - ${log.endpoint}</p>
                                        <p class="text-sm text-gray-600">${log.method} • ${log.ip}</p>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-medium ${statusColor}">${log.status}</p>
                                    <p class="text-xs text-gray-600">${log.response_time}ms</p>
                                </div>
                            `;
                            
                            logsContainer.appendChild(logElement);
                        });
                    } catch (error) {
                        console.error('Error loading API logs:', error);
                    }
                }
            }
        }
    </script>
</body>
</html> 