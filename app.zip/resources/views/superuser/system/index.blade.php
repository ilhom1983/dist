<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Системой - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="systemData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Системой</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">Last updated: <span x-text="new Date().toLocaleTimeString()"></span></span>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- System Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Таблицы Базы Данных</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $databaseStats['total_tables'] }}</p>
                        <p class="text-sm text-gray-600 mt-1">{{ $databaseStats['total_size'] }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-database"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Использование Хранилища</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $storageInfo['usage_percentage'] }}%</p>
                        <p class="text-sm text-gray-600 mt-1">{{ $storageInfo['used_space'] }} / {{ $storageInfo['total_space'] }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-hdd"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Резервные Копии</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $backupStatus['total_backups'] }}</p>
                        <p class="text-sm text-gray-600 mt-1">
                            @if($backupStatus['latest_backup'])
                                Последняя: {{ $backupStatus['latest_backup']['created_at']->diffForHumans() }}
                            @else
                                Нет резервных копий
                            @endif
                        </p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Файлы Логов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $logFiles->count() }}</p>
                        <p class="text-sm text-gray-600 mt-1">Системные логи</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-file-alt"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- System Actions -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Системные Действия</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <button @click="createBackup()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-download mr-2"></i>Создать Резервную Копию
                </button>
                <button @click="clearCache()" class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-broom mr-2"></i>Очистить Кэш
                </button>
                <button @click="optimizeSystem()" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-rocket mr-2"></i>Оптимизировать Систему
                </button>
                <button @click="refreshData()" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-sync-alt mr-2"></i>Обновить Данные
                </button>
            </div>
        </div>

        <!-- System Information -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- System Info -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Информация о Системе</h3>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">PHP Version</span>
                        <span class="text-sm font-medium">{{ $systemInfo['php_version'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Laravel Version</span>
                        <span class="text-sm font-medium">{{ $systemInfo['laravel_version'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Server</span>
                        <span class="text-sm font-medium">{{ $systemInfo['server'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Memory Limit</span>
                        <span class="text-sm font-medium">{{ $systemInfo['memory_limit'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Max Execution Time</span>
                        <span class="text-sm font-medium">{{ $systemInfo['max_execution_time'] }}s</span>
                    </div>
                </div>
            </div>

            <!-- Performance Metrics -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Performance Metrics</h3>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Average Query Time</span>
                        <span class="text-sm font-medium">{{ $performanceMetrics['average_query_time'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Slow Queries</span>
                        <span class="text-sm font-medium">{{ $performanceMetrics['slow_queries'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Cache Hit Rate</span>
                        <span class="text-sm font-medium">{{ $performanceMetrics['cache_hit_rate'] }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Memory Usage</span>
                        <span class="text-sm font-medium">{{ $performanceMetrics['memory_usage']['current'] }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Database Tables -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Largest Database Tables</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Table Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rows</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($databaseStats['largest_tables'] as $table)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $table['name'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $table['size'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $table['rows'] }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Log Files -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">System Log Files</h3>
            <div class="space-y-3">
                @foreach($logFiles->take(10) as $log)
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-file-alt text-blue-500"></i>
                        <div>
                            <p class="font-medium text-gray-800">{{ $log['filename'] }}</p>
                            <p class="text-sm text-gray-600">{{ $log['size'] }}</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-sm text-gray-600">{{ $log['modified']->diffForHumans() }}</span>
                        <button @click="viewLog('{{ $log['filename'] }}')" class="text-blue-600 hover:text-blue-800 text-sm">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <!-- Recent Backups -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Backups</h3>
            @if($backupStatus['backups']->count() > 0)
            <div class="space-y-3">
                @foreach($backupStatus['backups'] as $backup)
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-download text-green-500"></i>
                        <div>
                            <p class="font-medium text-gray-800">{{ $backup['filename'] }}</p>
                            <p class="text-sm text-gray-600">{{ $backup['size'] }}</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-sm text-gray-600">{{ $backup['created_at']->diffForHumans() }}</span>
                        <button class="text-green-600 hover:text-green-800 text-sm">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>
                @endforeach
            </div>
            @else
            <p class="text-gray-600 text-center py-8">No backups found</p>
            @endif
        </div>
    </div>

    <!-- Log Viewer Modal -->
    <div x-show="showLogModal" x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-96 overflow-hidden">
            <div class="flex items-center justify-between p-4 border-b">
                <h3 class="text-lg font-semibold text-gray-800">Log Viewer</h3>
                <button @click="showLogModal = false" class="text-gray-600 hover:text-gray-800">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="p-4 max-h-64 overflow-y-auto">
                <pre x-text="logContent" class="text-sm text-gray-800 whitespace-pre-wrap"></pre>
            </div>
        </div>
    </div>

    <script>
        function systemData() {
            return {
                showLogModal: false,
                logContent: '',
                
                async createBackup() {
                    try {
                        const response = await fetch('/superuser/system/backup', {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert('Backup created successfully!');
                            location.reload();
                        } else {
                            alert('Backup failed: ' + data.message);
                        }
                    } catch (error) {
                        alert('Backup error: ' + error.message);
                    }
                },
                
                async clearCache() {
                    try {
                        const response = await fetch('/superuser/system/clear-cache', {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert('Cache cleared successfully!');
                        } else {
                            alert('Cache clear failed: ' + data.message);
                        }
                    } catch (error) {
                        alert('Cache clear error: ' + error.message);
                    }
                },
                
                async optimizeSystem() {
                    try {
                        const response = await fetch('/superuser/system/optimize', {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert('System optimized successfully!');
                        } else {
                            alert('Optimization failed: ' + data.message);
                        }
                    } catch (error) {
                        alert('Optimization error: ' + error.message);
                    }
                },
                
                async viewLog(filename) {
                    try {
                        const response = await fetch(`/superuser/system/logs/${filename}`);
                        const data = await response.json();
                        
                        if (data.content) {
                            this.logContent = data.content;
                            this.showLogModal = true;
                        } else {
                            alert('Failed to load log file');
                        }
                    } catch (error) {
                        alert('Error loading log: ' + error.message);
                    }
                },
                
                refreshData() {
                    location.reload();
                }
            }
        }
    </script>
</body>
</html> 