<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель Суперпользователя - Система Распределения</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .status-healthy { background-color: #10b981; }
        .status-warning { background-color: #f59e0b; }
        .status-error { background-color: #ef4444; }
    </style>
</head>
<body class="bg-gray-50" x-data="dashboardData()">
    <!-- Navigation Header -->
    <nav class="gradient-bg text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-crown text-2xl"></i>
                    <h1 class="text-2xl font-bold">Панель Суперпользователя</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2">
                        <span class="status-indicator status-healthy"></span>
                        <span class="text-sm">Система Онлайн</span>
                    </div>
                    <div class="text-sm">
                        <span x-text="new Date().toLocaleTimeString()"></span>
                    </div>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Quick Actions -->
        <div class="mb-8">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Быстрые Действия</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                @foreach($quickActions as $action)
                <a href="{{ $action['url'] }}" class="bg-white rounded-lg shadow-md p-4 text-center card-hover">
                    <div class="text-2xl mb-2">
                        <i class="fas fa-{{ $action['icon'] }} text-{{ $action['color'] }}-500"></i>
                    </div>
                    <div class="text-sm font-medium text-gray-700">{{ $action['title'] }}</div>
                </a>
                @endforeach
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Total Tenants -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Арендаторов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_tenants']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $stats['active_tenants'] }} Активных
                        </p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
            </div>

            <!-- Total Revenue -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Общий Доход</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_revenue'], 0) }} Сум</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ number_format($realtimeMetrics['revenue_growth'], 1) }}% в этом месяце
                        </p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>

            <!-- Total Users -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Пользователей</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_users']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ number_format($realtimeMetrics['user_growth'], 1) }}% в этом месяце
                        </p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <!-- Total Orders -->
            <div class="bg-white rounded-lg shadow-md p-6 card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Заказов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($stats['total_orders']) }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $realtimeMetrics['today_orders'] }} сегодня
                        </p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts and Analytics -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Performance Trends Chart -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Тренды Производительности</h3>
                <canvas id="performanceChart" width="400" height="200"></canvas>
            </div>

            <!-- System Health -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Состояние Системы</h3>
                <div class="space-y-4">
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">База Данных</span>
                        <div class="flex items-center">
                            <span class="status-indicator status-healthy"></span>
                            <span class="text-sm text-green-600">{{ $systemHealth['database_status']['response_time'] }}ms</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">API Сервисы</span>
                        <div class="flex items-center">
                            <span class="status-indicator status-healthy"></span>
                            <span class="text-sm text-green-600">Все Активны</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Использование Хранилища</span>
                        <div class="flex items-center">
                            <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: {{ $systemHealth['storage_usage']['percentage'] }}%"></div>
                            </div>
                            <span class="text-sm text-gray-600">{{ $systemHealth['storage_usage']['percentage'] }}%</span>
                        </div>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Время Работы</span>
                        <span class="text-sm text-green-600">{{ $systemHealth['uptime']['current'] }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Tenants and Recent Activity -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Top Performing Tenants -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Лучшие Арендаторы</h3>
                <div class="space-y-3">
                    @foreach($topTenants->take(5) as $tenant)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                {{ strtoupper(substr($tenant->name, 0, 1)) }}
                            </div>
                            <div>
                                <p class="font-medium text-gray-800">{{ $tenant->name }}</p>
                                <p class="text-sm text-gray-600">{{ $tenant->domain }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-medium text-gray-800">{{ number_format($tenant->total_revenue, 0) }} Сум</p>
                            <p class="text-sm text-gray-600">{{ $tenant->total_orders }} заказов</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Последняя Активность</h3>
                <div class="space-y-3">
                    @foreach($recentActivity['recent_orders'] as $order)
                    <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="flex-1">
                            <p class="font-medium text-gray-800">Новый Заказ #{{ $order->id }}</p>
                            <p class="text-sm text-gray-600">{{ $order->tenant->name ?? 'Неизвестный Арендатор' }}</p>
                        </div>
                        <div class="text-right">
                            <p class="text-sm text-gray-600">{{ $order->created_at->diffForHumans() }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Security Alerts and System Events -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Security Alerts -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Система Безопасности</h3>
                <div class="space-y-3">
                    <div class="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-exclamation-triangle text-red-500"></i>
                            <div>
                                <p class="font-medium text-red-800">{{ $securityAlerts['failed_logins']['count'] }} Неудачных Входов</p>
                                <p class="text-sm text-red-600">За последние 24 часа</p>
                            </div>
                        </div>
                        <span class="text-sm text-red-600">{{ $securityAlerts['failed_logins']['suspicious'] }} подозрительных</span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-shield-alt text-yellow-500"></i>
                            <div>
                                <p class="font-medium text-yellow-800">{{ $securityAlerts['api_abuse']['rate_limit_exceeded'] }} Превышен Лимит</p>
                                <p class="text-sm text-yellow-600">Обнаружено злоупотребление API</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Events -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Системные События</h3>
                <div class="space-y-3">
                    @foreach($recentActivity['system_events'] as $event)
                    <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div class="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm
                            @if($event['type'] === 'error') bg-red-500
                            @elseif($event['type'] === 'warning') bg-yellow-500
                            @elseif($event['type'] === 'success') bg-green-500
                            @else bg-blue-500
                            @endif">
                            <i class="fas fa-{{ $event['type'] === 'error' ? 'exclamation-circle' : ($event['type'] === 'warning' ? 'exclamation-triangle' : ($event['type'] === 'success' ? 'check-circle' : 'info-circle')) }}"></i>
                        </div>
                        <div class="flex-1">
                            <p class="font-medium text-gray-800">{{ $event['message'] }}</p>
                            <p class="text-sm text-gray-600">{{ $event['time']->diffForHumans() }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Geographic Distribution -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Географическое Распределение</h3>
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                @foreach($geoDistribution as $location)
                <div class="text-center p-4 bg-gray-50 rounded-lg">
                    <div class="text-2xl font-bold text-blue-600">{{ $location->count }}</div>
                    <div class="text-sm text-gray-600">{{ $location->domain }}</div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <script>
        function dashboardData() {
            return {
                init() {
                    this.initCharts();
                    this.startAutoRefresh();
                },
                
                initCharts() {
                    const ctx = document.getElementById('performanceChart').getContext('2d');
                    const performanceData = @json($performanceTrends);
                    
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: performanceData.map(item => item.month),
                            datasets: [{
                                label: 'Доход (Сум)',
                                data: performanceData.map(item => item.revenue),
                                borderColor: 'rgb(59, 130, 246)',
                                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                                tension: 0.4
                            }, {
                                label: 'Заказы',
                                data: performanceData.map(item => item.orders),
                                borderColor: 'rgb(16, 185, 129)',
                                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'top',
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                },
                
                startAutoRefresh() {
                    setInterval(() => {
                        this.refreshData();
                    }, 30000); // Refresh every 30 seconds
                },
                
                async refreshData() {
                    try {
                        const response = await fetch('/superuser/dashboard/api-stats');
                        const data = await response.json();
                        // Update real-time metrics
                        this.updateMetrics(data);
                    } catch (error) {
                        console.error('Failed to refresh dashboard data:', error);
                    }
                },
                
                updateMetrics(data) {
                    // Update real-time metrics in the UI
                    // This would update the displayed values without page refresh
                }
            }
        }
    </script>
</body>
</html> 