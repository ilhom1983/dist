<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Пользователями - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="userData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Пользователями</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.users.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Добавить Пользователя
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Success Message -->
        @if(session('success'))
            <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                {{ session('success') }}
            </div>
        @endif

        <!-- Analytics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Пользователей</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $users->total() }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Активных Пользователей</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $users->where('is_active', true)->count() }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Администраторов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $users->where('role', 'admin')->count() }}</p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-user-shield"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Новых Регистраций</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $users->where('created_at', '>=', \Carbon\Carbon::now()->subDays(7))->count() }}</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-user-plus"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <div class="relative">
                        <input type="text" x-model="searchTerm" @input="filterUsers()" 
                               placeholder="Поиск пользователей по имени, email или роли..." 
                               class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                    </div>
                </div>
                <div class="flex gap-2">
                    <select x-model="statusFilter" @change="filterUsers()" 
                            class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все Статусы</option>
                        <option value="active">Активные</option>
                        <option value="inactive">Неактивные</option>
                    </select>
                    <select x-model="roleFilter" @change="filterUsers()" 
                            class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все Роли</option>
                        <option value="admin">Администратор</option>
                        <option value="manager">Менеджер</option>
                        <option value="sales">Продавец</option>
                        <option value="warehouse">Склад</option>
                        <option value="delivery">Доставка</option>
                    </select>
                    <select x-model="tenantFilter" @change="filterUsers()" 
                            class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все Арендаторы</option>
                        @foreach($tenants ?? [] as $tenant)
                            <option value="{{ $tenant->id }}">{{ $tenant->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <!-- Users List -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Все Пользователи</h3>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Пользователь</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Арендатор</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Роль</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Статус</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Последний Вход</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Создан</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Действия</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200" id="usersTable">
                        @forelse($users as $user)
                        <tr class="user-row hover:bg-gray-50 transition-colors" data-tenant-id="{{ $user->tenant->id ?? '' }}">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <div class="h-10 w-10 rounded-full bg-gradient-to-r from-green-500 to-blue-600 flex items-center justify-center">
                                            <span class="text-sm font-medium text-white">{{ strtoupper(substr($user->name, 0, 2)) }}</span>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900 user-name">{{ $user->name }}</div>
                                        <div class="text-sm text-gray-500">{{ $user->email }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">{{ $user->tenant->name ?? 'Нет Арендатора' }}</div>
                                <div class="text-sm text-gray-500">{{ $user->tenant->domain ?? 'Нет домена' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    @if($user->role === 'admin') bg-purple-100 text-purple-800
                                    @elseif($user->role === 'manager') bg-blue-100 text-blue-800
                                    @elseif($user->role === 'sales') bg-green-100 text-green-800
                                    @elseif($user->role === 'warehouse') bg-yellow-100 text-yellow-800
                                    @else bg-gray-100 text-gray-800
                                    @endif">
                                    <i class="fas fa-{{ $user->role === 'admin' ? 'user-shield' : ($user->role === 'manager' ? 'user-tie' : ($user->role === 'sales' ? 'user' : 'user-cog')) }} mr-1"></i>
                                    @if($user->role === 'admin') Администратор
                                    @elseif($user->role === 'manager') Менеджер
                                    @elseif($user->role === 'sales') Продавец
                                    @elseif($user->role === 'warehouse') Склад
                                    @elseif($user->role === 'delivery') Доставка
                                    @else {{ ucfirst($user->role) }}
                                    @endif
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    @if($user->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    <span class="w-2 h-2 rounded-full mr-1.5 @if($user->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                                    {{ $user->is_active ? 'Активный' : 'Неактивный' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $user->last_login_at ? $user->last_login_at->diffForHumans() : 'Никогда' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $user->created_at->format('M d, Y') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="{{ route('superuser.users.show', $user) }}" 
                                       class="text-blue-600 hover:text-blue-900 transition-colors" 
                                       title="Просмотр Деталей">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('superuser.users.edit', $user) }}" 
                                       class="text-green-600 hover:text-green-900 transition-colors" 
                                       title="Редактировать Пользователя">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button @click="toggleUserStatus({{ $user->id }}, {{ $user->is_active ? 'false' : 'true' }})" 
                                            class="text-yellow-600 hover:text-yellow-900 transition-colors" 
                                            title="{{ $user->is_active ? 'Деактивировать' : 'Активировать' }}">
                                        <i class="fas fa-{{ $user->is_active ? 'pause' : 'play' }}"></i>
                                    </button>
                                    <button @click="deleteUser({{ $user->id }})" 
                                            class="text-red-600 hover:text-red-900 transition-colors" 
                                            title="Удалить Пользователя">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <div class="text-gray-500">
                                    <i class="fas fa-users text-4xl mb-4"></i>
                                    <p class="text-lg font-medium">Пользователи не найдены</p>
                                    <p class="text-sm">Начните с создания первого пользователя</p>
                                    <a href="{{ route('superuser.users.create') }}" 
                                       class="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                        <i class="fas fa-plus mr-2"></i>Создать Первого Пользователя
                                    </a>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        @if($users->hasPages())
            <div class="mt-6">
                {{ $users->links() }}
            </div>
        @endif
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-exclamation-triangle text-red-500 text-2xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Удалить Пользователя</h3>
                </div>
                <p class="text-gray-600 mb-6">
                    Вы уверены, что хотите удалить этого пользователя? Это действие нельзя отменить и оно навсегда удалит аккаунт пользователя.
                </p>
                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false" 
                            class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                        Отмена
                    </button>
                    <button @click="confirmDelete()" 
                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        Delete User
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function userData() {
            return {
                searchTerm: '',
                statusFilter: '',
                roleFilter: '',
                tenantFilter: '',
                showDeleteModal: false,
                userToDelete: null,
                
                filterUsers() {
                    const rows = document.querySelectorAll('.user-row');
                    rows.forEach(row => {
                        const name = row.querySelector('.user-name').textContent.toLowerCase();
                        const status = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
                        const role = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                        const tenant = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                        
                        const matchesSearch = name.includes(this.searchTerm.toLowerCase());
                        const matchesStatus = !this.statusFilter || status.includes(this.statusFilter);
                        const matchesRole = !this.roleFilter || role.includes(this.roleFilter);
                        const matchesTenant = !this.tenantFilter || row.getAttribute('data-tenant-id') === this.tenantFilter;
                        
                        row.style.display = matchesSearch && matchesStatus && matchesRole && matchesTenant ? '' : 'none';
                    });
                },
                
                toggleUserStatus(userId, newStatus) {
                    if (confirm(`Are you sure you want to ${newStatus ? 'activate' : 'deactivate'} this user?`)) {
                        // In real implementation, this would make an AJAX call
                        window.location.href = `/superuser/users/${userId}/toggle-status`;
                    }
                },
                
                deleteUser(userId) {
                    this.userToDelete = userId;
                    this.showDeleteModal = true;
                },
                
                confirmDelete() {
                    if (this.userToDelete) {
                        const form = document.createElement('form');
                        form.method = 'POST';
                        form.action = `/superuser/users/${this.userToDelete}`;
                        
                        const csrfToken = document.createElement('input');
                        csrfToken.type = 'hidden';
                        csrfToken.name = '_token';
                        csrfToken.value = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                        
                        const methodField = document.createElement('input');
                        methodField.type = 'hidden';
                        methodField.name = '_method';
                        methodField.value = 'DELETE';
                        
                        form.appendChild(csrfToken);
                        form.appendChild(methodField);
                        document.body.appendChild(form);
                        form.submit();
                    }
                }
            }
        }
    </script>
</body>
</html> 