<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $user->name }} - Детали Пользователя - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="userDetails()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.users.index') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Пользователям
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Детали Пользователя</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.users.edit', $user) }}" 
                       class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-edit mr-2"></i>Edit User
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- User Header -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <div class="h-16 w-16 rounded-full bg-gradient-to-r from-green-500 to-blue-600 flex items-center justify-center">
                        <span class="text-2xl font-bold text-white">{{ strtoupper(substr($user->name, 0, 2)) }}</span>
                    </div>
                    <div>
                        <h2 class="text-3xl font-bold text-gray-900">{{ $user->name }}</h2>
                        <p class="text-gray-600">{{ $user->email }}</p>
                        <div class="flex items-center mt-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                @if($user->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                <span class="w-2 h-2 rounded-full mr-1.5 @if($user->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                                {{ $user->is_active ? 'Active' : 'Inactive' }}
                            </span>
                            <span class="ml-4 text-sm text-gray-500">
                                <i class="fas fa-user-shield mr-1"></i>{{ ucfirst($user->role) }}
                            </span>
                            <span class="ml-4 text-sm text-gray-500">
                                <i class="fas fa-building mr-1"></i>{{ $user->tenant->name }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="flex space-x-3">
                    <button @click="toggleUserStatus({{ $user->id }}, {{ $user->is_active ? 'false' : 'true' }})" 
                            class="px-4 py-2 rounded-lg transition-colors
                            @if($user->is_active) bg-yellow-100 text-yellow-800 hover:bg-yellow-200 @else bg-green-100 text-green-800 hover:bg-green-200 @endif">
                        <i class="fas fa-{{ $user->is_active ? 'pause' : 'play' }} mr-2"></i>
                        {{ $user->is_active ? 'Deactivate' : 'Activate' }}
                    </button>
                    <button @click="showDeleteModal = true" 
                            class="px-4 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors">
                        <i class="fas fa-trash mr-2"></i>Delete
                    </button>
                </div>
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Orders</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $user->orders_count ?? 0 }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $user->orders->where('created_at', '>=', \Carbon\Carbon::now()->subDays(30))->count() }} This Month
                        </p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Revenue</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($user->total_revenue ?? 0, 0) }} Сум</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ number_format($user->monthly_revenue ?? 0, 0) }} Сум This Month
                        </p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Last Login</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $user->last_login_at ? $user->last_login_at->format('M d') : 'Never' }}</p>
                        <p class="text-sm text-gray-500 mt-1">
                            <i class="fas fa-clock mr-1"></i>{{ $user->last_login_at ? $user->last_login_at->diffForHumans() : 'No login history' }}
                        </p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-sign-in-alt"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Account Age</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $user->created_at->diffInDays() }}</p>
                        <p class="text-sm text-gray-500 mt-1">
                            <i class="fas fa-calendar mr-1"></i>Days since registration
                        </p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-birthday-cake"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column -->
            <div class="lg:col-span-2 space-y-8">
                <!-- User Information -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">User Information</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Personal Details</h4>
                                <dl class="space-y-3">
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Full Name</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-user mr-2 text-gray-400"></i>
                                            {{ $user->name }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Email Address</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-envelope mr-2 text-gray-400"></i>
                                            {{ $user->email }}
                                            @if($user->email_verified_at)
                                                <span class="ml-2 text-green-600">
                                                    <i class="fas fa-check-circle"></i>
                                                </span>
                                            @endif
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Phone Number</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-phone mr-2 text-gray-400"></i>
                                            {{ $user->phone ?? 'Not provided' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Account Status</dt>
                                        <dd class="text-sm">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                @if($user->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                                <span class="w-2 h-2 rounded-full mr-1.5 @if($user->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                                                {{ $user->is_active ? 'Active' : 'Inactive' }}
                                            </span>
                                        </dd>
                                    </div>
                                </dl>
                            </div>
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Account Details</h4>
                                <dl class="space-y-3">
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">User Role</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-user-shield mr-2 text-gray-400"></i>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                @if($user->role === 'admin') bg-purple-100 text-purple-800
                                                @elseif($user->role === 'manager') bg-blue-100 text-blue-800
                                                @elseif($user->role === 'sales') bg-green-100 text-green-800
                                                @elseif($user->role === 'warehouse') bg-yellow-100 text-yellow-800
                                                @else bg-gray-100 text-gray-800
                                                @endif">
                                                {{ ucfirst($user->role) }}
                                            </span>
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Tenant</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-building mr-2 text-gray-400"></i>
                                            {{ $user->tenant->name }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Created</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-calendar mr-2 text-gray-400"></i>
                                            {{ $user->created_at->format('M d, Y H:i') }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Last Updated</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-clock mr-2 text-gray-400"></i>
                                            {{ $user->updated_at->format('M d, Y H:i') }}
                                        </dd>
                                    </div>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Recent Activity</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-4">
                            @forelse($user->orders->take(5) as $order)
                            <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                                <div class="flex-shrink-0">
                                    <div class="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                                        <i class="fas fa-shopping-cart text-green-600 text-sm"></i>
                                    </div>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900">Order #{{ $order->id }} created</p>
                                    <p class="text-sm text-gray-500">{{ $order->created_at->diffForHumans() }}</p>
                                </div>
                                <div class="text-sm text-gray-500">
                                    ${{ number_format($order->total_amount ?? 0, 2) }}
                                </div>
                            </div>
                            @empty
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-4"></i>
                                <p>No recent activity</p>
                            </div>
                            @endforelse
                        </div>
                    </div>
                </div>

                <!-- Performance Chart -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Performance Overview</h3>
                    </div>
                    <div class="p-6">
                        <canvas id="userPerformanceChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="space-y-8">
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-3">
                            <a href="{{ route('superuser.users.edit', $user) }}" 
                               class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                                <i class="fas fa-edit text-blue-600 mr-3"></i>
                                <span class="text-sm font-medium text-blue-900">Edit User</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                                <i class="fas fa-key text-green-600 mr-3"></i>
                                <span class="text-sm font-medium text-green-900">Reset Password</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                                <i class="fas fa-chart-line text-purple-600 mr-3"></i>
                                <span class="text-sm font-medium text-purple-900">View Reports</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors">
                                <i class="fas fa-envelope text-orange-600 mr-3"></i>
                                <span class="text-sm font-medium text-orange-900">Send Message</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Role Permissions -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Role Permissions</h3>
                    </div>
                    <div class="p-6">
                        @php
                            $rolePermissions = [
                                'superadmin' => ['Full system access', 'Manage all tenants', 'System configuration', 'User management', 'Security settings'],
                                'admin' => ['Manage users', 'Manage products', 'Manage customers', 'Manage orders', 'View reports', 'Manage settings'],
                                'operator' => ['View orders', 'Update order status', 'Manage payments', 'View customers', 'View products'],
                                'manager' => ['View orders', 'Approve orders', 'View reports', 'Manage team', 'View customers'],
                                'sales' => ['Create orders', 'View customers', 'View products', 'Update customer info'],
                                'warehouse' => ['View orders', 'Update inventory', 'Load orders', 'View products'],
                                'delivery' => ['View orders', 'Update delivery status', 'View customers', 'View routes']
                            ];
                            $permissions = $rolePermissions[$user->role] ?? ['No permissions defined'];
                        @endphp
                        <div class="space-y-2">
                            @foreach($permissions as $permission)
                            <div class="flex items-center">
                                <i class="fas fa-check text-green-500 mr-2 text-sm"></i>
                                <span class="text-sm text-gray-700">{{ $permission }}</span>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- Security Status -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Security Status</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-4">
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Email Verified</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                    @if($user->email_verified_at) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    <span class="w-2 h-2 rounded-full mr-1.5 @if($user->email_verified_at) bg-green-400 @else bg-red-400 @endif"></span>
                                    {{ $user->email_verified_at ? 'Verified' : 'Not Verified' }}
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Two-Factor Auth</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <span class="w-2 h-2 rounded-full mr-1.5 bg-gray-400"></span>
                                    Not Enabled
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Last Password Change</span>
                                <span class="text-sm text-gray-500">{{ $user->updated_at->diffForHumans() }}</span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Login Sessions</span>
                                <span class="text-sm text-gray-500">1 Active</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-exclamation-triangle text-red-500 text-2xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Delete User</h3>
                </div>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete <strong>{{ $user->name }}</strong>? This action cannot be undone and will permanently remove the user account.
                </p>
                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false" 
                            class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                        Cancel
                    </button>
                    <form method="POST" action="{{ route('superuser.users.destroy', $user) }}" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" 
                                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            Delete User
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function userDetails() {
            return {
                showDeleteModal: false,
                
                toggleUserStatus(userId, newStatus) {
                    if (confirm(`Are you sure you want to ${newStatus ? 'activate' : 'deactivate'} this user?`)) {
                        // In real implementation, this would make an AJAX call
                        window.location.href = `/superuser/users/${userId}/toggle-status`;
                    }
                }
            }
        }

        // User Performance Chart
        const ctx = document.getElementById('userPerformanceChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Orders',
                    data: [5, 12, 8, 15, 10, 18],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Revenue',
                    data: [500, 1200, 800, 1500, 1000, 1800],
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html> 