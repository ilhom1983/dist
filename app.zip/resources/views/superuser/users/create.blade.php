<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать Нового Пользователя - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="userCreateForm()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.users.index') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Пользователям
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Создать Нового Пользователя</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Progress Steps -->
        <div class="mb-8">
            <div class="flex items-center justify-center">
                <div class="flex items-center">
                    <div class="bg-blue-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                        <i class="fas fa-user text-sm"></i>
                    </div>
                    <div class="ml-2 text-sm font-medium text-blue-600">User Information</div>
                </div>
                <div class="flex-1 h-0.5 bg-gray-300 mx-4"></div>
                <div class="flex items-center">
                    <div class="bg-gray-300 text-gray-500 rounded-full h-8 w-8 flex items-center justify-center">
                        <i class="fas fa-shield-alt text-sm"></i>
                    </div>
                    <div class="ml-2 text-sm font-medium text-gray-500">Permissions</div>
                </div>
                <div class="flex-1 h-0.5 bg-gray-300 mx-4"></div>
                <div class="flex items-center">
                    <div class="bg-gray-300 text-gray-500 rounded-full h-8 w-8 flex items-center justify-center">
                        <i class="fas fa-check text-sm"></i>
                    </div>
                    <div class="ml-2 text-sm font-medium text-gray-500">Complete</div>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">User Information</h3>
                <p class="text-sm text-gray-600 mt-1">Enter the basic information for the new user</p>
            </div>

            <form method="POST" action="{{ route('superuser.users.store') }}" class="p-6 space-y-6">
                @csrf
                
                <!-- Tenant Selection -->
                <div>
                    <label for="tenant_id" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-building mr-2"></i>Select Tenant *
                    </label>
                    <select name="tenant_id" id="tenant_id" required
                            x-model="form.tenant_id" @change="validateField('tenant_id')"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors">
                        <option value="">Choose a tenant...</option>
                        @foreach($tenants as $tenant)
                            <option value="{{ $tenant->id }}" {{ old('tenant_id') == $tenant->id ? 'selected' : '' }}>
                                {{ $tenant->name }} ({{ $tenant->domain ?? 'No domain' }})
                            </option>
                        @endforeach
                    </select>
                    <div x-show="errors.tenant_id" x-text="errors.tenant_id" class="mt-1 text-sm text-red-600"></div>
                    @error('tenant_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Basic Information -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-user mr-2"></i>Full Name *
                        </label>
                        <input type="text" name="name" id="name" value="{{ old('name') }}" required
                               x-model="form.name" @input="validateField('name')"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="Enter full name">
                        <div x-show="errors.name" x-text="errors.name" class="mt-1 text-sm text-red-600"></div>
                        @error('name')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-envelope mr-2"></i>Email Address *
                        </label>
                        <input type="email" name="email" id="email" value="{{ old('email') }}" required
                               x-model="form.email" @input="validateField('email')"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="user@example.com">
                        <div x-show="errors.email" x-text="errors.email" class="mt-1 text-sm text-red-600"></div>
                        @error('email')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-phone mr-2"></i>Phone Number
                        </label>
                        <input type="tel" name="phone" id="phone" value="{{ old('phone') }}"
                               x-model="form.phone"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="+1 (555) 123-4567">
                        @error('phone')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="role" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-user-shield mr-2"></i>User Role *
                        </label>
                        <select name="role" id="role" required
                                x-model="form.role" @change="validateField('role'); updateRoleDescription()"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors">
                            <option value="">Select a role...</option>
                            @foreach($roles as $role)
                                <option value="{{ $role->name }}" {{ old('role') == $role->name ? 'selected' : '' }}>
                                    {{ ucfirst($role->name) }}
                                </option>
                            @endforeach
                        </select>
                        <div x-show="errors.role" x-text="errors.role" class="mt-1 text-sm text-red-600"></div>
                        @error('role')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Role Description -->
                <div x-show="roleDescription" class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle text-blue-400"></i>
                        </div>
                        <div class="ml-3">
                            <h4 class="text-sm font-medium text-blue-800" x-text="roleDescription.title"></h4>
                            <div class="mt-2 text-sm text-blue-700">
                                <p x-text="roleDescription.description"></p>
                                <ul class="mt-2 list-disc list-inside space-y-1">
                                    <template x-for="permission in roleDescription.permissions" :key="permission">
                                        <li x-text="permission"></li>
                                    </template>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Password Section -->
                <div class="border-t border-gray-200 pt-6">
                    <h4 class="text-md font-medium text-gray-800 mb-4">Security Settings</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-lock mr-2"></i>Password *
                            </label>
                            <div class="relative">
                                <input :type="showPassword ? 'text' : 'password'" name="password" id="password" required
                                       x-model="form.password" @input="validateField('password')"
                                       class="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                                       placeholder="Enter password">
                                <button type="button" @click="showPassword = !showPassword" 
                                        class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                    <i class="fas" :class="showPassword ? 'fa-eye-slash' : 'fa-eye'" class="text-gray-400"></i>
                                </button>
                            </div>
                            <div x-show="errors.password" x-text="errors.password" class="mt-1 text-sm text-red-600"></div>
                            @error('password')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-lock mr-2"></i>Confirm Password *
                            </label>
                            <div class="relative">
                                <input :type="showPassword ? 'text' : 'password'" name="password_confirmation" id="password_confirmation" required
                                       x-model="form.password_confirmation" @input="validateField('password_confirmation')"
                                       class="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                                       placeholder="Confirm password">
                                <button type="button" @click="showPassword = !showPassword" 
                                        class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                    <i class="fas" :class="showPassword ? 'fa-eye-slash' : 'fa-eye'" class="text-gray-400"></i>
                                </button>
                            </div>
                            <div x-show="errors.password_confirmation" x-text="errors.password_confirmation" class="mt-1 text-sm text-red-600"></div>
                        </div>
                    </div>
                </div>

                <!-- User Settings -->
                <div class="border-t border-gray-200 pt-6">
                    <h4 class="text-md font-medium text-gray-800 mb-4">User Settings</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="flex items-center">
                            <input type="checkbox" name="is_active" id="is_active" value="1" 
                                   {{ old('is_active', true) ? 'checked' : '' }}
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label for="is_active" class="ml-2 block text-sm text-gray-700">
                                <i class="fas fa-check-circle mr-2"></i>Active User
                            </label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" name="send_welcome_email" id="send_welcome_email" value="1" 
                                   {{ old('send_welcome_email', true) ? 'checked' : '' }}
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label for="send_welcome_email" class="ml-2 block text-sm text-gray-700">
                                <i class="fas fa-envelope mr-2"></i>Send Welcome Email
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                    <div class="text-sm text-gray-600">
                        <i class="fas fa-info-circle mr-2"></i>
                        Fields marked with * are required
                    </div>
                    <div class="flex space-x-3">
                        <a href="{{ route('superuser.users.index') }}" 
                           class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" 
                                :disabled="!isFormValid()"
                                class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
                            <i class="fas fa-plus mr-2"></i>Create User
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Help Card -->
        <div class="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-lightbulb text-blue-400"></i>
                </div>
                <div class="ml-3">
                    <h3 class="text-sm font-medium text-blue-800">Creating a New User</h3>
                    <div class="mt-2 text-sm text-blue-700">
                        <ul class="list-disc list-inside space-y-1">
                            <li>User will be assigned to the selected tenant</li>
                            <li>Role determines access permissions and features</li>
                            <li>Welcome email will be sent if enabled</li>
                            <li>User can change password on first login</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function userCreateForm() {
            return {
                form: {
                    tenant_id: '{{ old("tenant_id") }}',
                    name: '{{ old("name") }}',
                    email: '{{ old("email") }}',
                    phone: '{{ old("phone") }}',
                    role: '{{ old("role") }}',
                    password: '',
                    password_confirmation: ''
                },
                errors: {
                    tenant_id: '',
                    name: '',
                    email: '',
                    role: '',
                    password: '',
                    password_confirmation: ''
                },
                showPassword: false,
                roleDescription: null,
                
                roleDescriptions: {
                    'admin': {
                        title: 'Administrator',
                        description: 'Full access to manage the tenant, including users, products, orders, and settings.',
                        permissions: [
                            'Manage all users and roles',
                            'Configure system settings',
                            'View all reports and analytics',
                            'Manage products and inventory',
                            'Process orders and payments',
                            'Access admin dashboard'
                        ]
                    },
                    'manager': {
                        title: 'Manager',
                        description: 'Oversee operations and manage team members with limited administrative access.',
                        permissions: [
                            'View and manage team members',
                            'Approve orders and transactions',
                            'View reports and analytics',
                            'Manage customer relationships',
                            'Monitor performance metrics'
                        ]
                    },
                    'sales': {
                        title: 'Sales Representative',
                        description: 'Handle customer interactions, create orders, and manage sales processes.',
                        permissions: [
                            'Create and manage orders',
                            'View customer information',
                            'Access product catalog',
                            'Update customer details',
                            'View sales reports'
                        ]
                    },
                    'warehouse': {
                        title: 'Warehouse Staff',
                        description: 'Manage inventory, process orders, and handle warehouse operations.',
                        permissions: [
                            'View and update inventory',
                            'Process order fulfillment',
                            'Manage product stock',
                            'View warehouse reports',
                            'Update order status'
                        ]
                    },
                    'delivery': {
                        title: 'Delivery Personnel',
                        description: 'Handle delivery operations and update delivery status.',
                        permissions: [
                            'View delivery orders',
                            'Update delivery status',
                            'View customer addresses',
                            'Access delivery routes',
                            'Mark orders as delivered'
                        ]
                    }
                },
                
                validateField(field) {
                    this.errors[field] = '';
                    
                    if (field === 'tenant_id') {
                        if (!this.form.tenant_id) {
                            this.errors.tenant_id = 'Please select a tenant';
                        }
                    }
                    
                    if (field === 'name') {
                        if (!this.form.name) {
                            this.errors.name = 'Name is required';
                        } else if (this.form.name.length < 2) {
                            this.errors.name = 'Name must be at least 2 characters';
                        }
                    }
                    
                    if (field === 'email') {
                        if (!this.form.email) {
                            this.errors.email = 'Email is required';
                        } else if (!this.isValidEmail(this.form.email)) {
                            this.errors.email = 'Please enter a valid email address';
                        }
                    }
                    
                    if (field === 'role') {
                        if (!this.form.role) {
                            this.errors.role = 'Please select a role';
                        }
                    }
                    
                    if (field === 'password') {
                        if (!this.form.password) {
                            this.errors.password = 'Password is required';
                        } else if (this.form.password.length < 8) {
                            this.errors.password = 'Password must be at least 8 characters';
                        }
                    }
                    
                    if (field === 'password_confirmation') {
                        if (!this.form.password_confirmation) {
                            this.errors.password_confirmation = 'Please confirm your password';
                        } else if (this.form.password !== this.form.password_confirmation) {
                            this.errors.password_confirmation = 'Passwords do not match';
                        }
                    }
                },
                
                updateRoleDescription() {
                    if (this.form.role && this.roleDescriptions[this.form.role]) {
                        this.roleDescription = this.roleDescriptions[this.form.role];
                    } else {
                        this.roleDescription = null;
                    }
                },
                
                isValidEmail(email) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    return emailRegex.test(email);
                },
                
                isFormValid() {
                    return this.form.tenant_id && this.form.name && this.form.email && 
                           this.form.role && this.form.password && this.form.password_confirmation &&
                           this.form.password === this.form.password_confirmation &&
                           !this.errors.tenant_id && !this.errors.name && !this.errors.email && 
                           !this.errors.role && !this.errors.password && !this.errors.password_confirmation;
                }
            }
        }
    </script>
</body>
</html> 