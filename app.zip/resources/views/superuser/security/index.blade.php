<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мониторинг Безопасности - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="securityData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Мониторинг Безопасности</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2">
                        <span class="status-indicator status-healthy"></span>
                        <span class="text-sm text-green-600">System Secure</span>
                    </div>
                    <span class="text-sm text-gray-600">Last updated: <span x-text="new Date().toLocaleTimeString()"></span></span>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Security Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Failed Logins</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $securityStats['failed_logins_today'] }}</p>
                        <p class="text-sm text-red-600 mt-1">Today</p>
                    </div>
                    <div class="text-red-500 text-3xl">
                        <i class="fas fa-user-times"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Suspicious Activities</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $securityStats['suspicious_activities'] }}</p>
                        <p class="text-sm text-yellow-600 mt-1">Last 24h</p>
                    </div>
                    <div class="text-yellow-500 text-3xl">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Blocked IPs</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $securityStats['blocked_ips'] }}</p>
                        <p class="text-sm text-blue-600 mt-1">Active blocks</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Security Alerts</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $securityStats['security_alerts'] }}</p>
                        <p class="text-sm text-orange-600 mt-1">Active alerts</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-bell"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Security Actions -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Security Actions</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <button @click="runSecurityScan()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-search mr-2"></i>Run Security Scan
                </button>
                <button @click="updateFirewall()" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-shield-alt mr-2"></i>Update Firewall
                </button>
                <button @click="checkSslCertificates()" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-lock mr-2"></i>Check SSL Certificates
                </button>
                <button @click="generateSecurityReport()" class="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-file-alt mr-2"></i>Generate Report
                </button>
            </div>
        </div>

        <!-- Failed Logins -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Failed Login Attempts</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IP Address</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Attempts</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Attempt</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($failedLogins as $login)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $login['ip'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $login['user'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $login['attempts'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $login['location'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $login['last_attempt']->diffForHumans() }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button @click="blockIp('{{ $login['ip'] }}')" class="text-red-600 hover:text-red-900 mr-2">
                                    <i class="fas fa-ban"></i>
                                </button>
                                <button @click="investigateIp('{{ $login['ip'] }}')" class="text-blue-600 hover:text-blue-900">
                                    <i class="fas fa-search"></i>
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Suspicious Activities -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Suspicious Activities</h3>
            <div class="space-y-3">
                @foreach($suspiciousActivities as $activity)
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border-l-4 
                    @if($activity['severity'] === 'high') border-red-500
                    @elseif($activity['severity'] === 'medium') border-yellow-500
                    @else border-blue-500
                    @endif">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-white
                            @if($activity['severity'] === 'high') bg-red-500
                            @elseif($activity['severity'] === 'medium') bg-yellow-500
                            @else bg-blue-500
                            @endif">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-800">{{ ucwords(str_replace('_', ' ', $activity['type'])) }}</p>
                            <p class="text-sm text-gray-600">{{ $activity['details'] }}</p>
                            <p class="text-xs text-gray-500">{{ $activity['ip'] }} • {{ $activity['user'] }}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-600">{{ $activity['timestamp']->diffForHumans() }}</p>
                        <p class="text-xs text-gray-500">{{ $activity['action_taken'] }}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <!-- SSL Certificates -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">SSL Certificates</h3>
                <div class="space-y-3">
                    @foreach($sslCertificates as $cert)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-lock text-green-500"></i>
                            <div>
                                <p class="font-medium text-gray-800">{{ $cert['domain'] }}</p>
                                <p class="text-sm text-gray-600">{{ $cert['issuer'] }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-medium 
                                @if($cert['status'] === 'expiring_soon') text-yellow-600 @else text-green-600 @endif">
                                {{ $cert['status'] === 'expiring_soon' ? 'Expiring Soon' : 'Valid' }}
                            </p>
                            <p class="text-xs text-gray-600">{{ $cert['expires_at']->format('M d, Y') }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Firewall Events -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Firewall Events</h3>
                <div class="space-y-3">
                    @foreach($firewallEvents as $event)
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-shield-alt 
                                @if($event['event_type'] === 'blocked') text-red-500 @else text-green-500 @endif"></i>
                            <div>
                                <p class="font-medium text-gray-800">{{ $event['ip'] }}</p>
                                <p class="text-sm text-gray-600">{{ $event['reason'] }}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                @if($event['event_type'] === 'blocked') bg-red-100 text-red-800 @else bg-green-100 text-green-800 @endif">
                                {{ ucfirst($event['event_type']) }}
                            </span>
                            <p class="text-xs text-gray-600 mt-1">{{ $event['timestamp']->diffForHumans() }}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Security Alerts -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Security Alerts</h3>
            <div class="space-y-3">
                @foreach($securityAlerts as $alert)
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border-l-4 
                    @if($alert['severity'] === 'high') border-red-500
                    @elseif($alert['severity'] === 'medium') border-yellow-500
                    @else border-blue-500
                    @endif">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-white
                            @if($alert['severity'] === 'high') bg-red-500
                            @elseif($alert['severity'] === 'medium') bg-yellow-500
                            @else bg-blue-500
                            @endif">
                            <i class="fas fa-bell"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-800">{{ $alert['title'] }}</p>
                            <p class="text-sm text-gray-600">{{ $alert['message'] }}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-600">{{ $alert['timestamp']->diffForHumans() }}</p>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                            @if($alert['severity'] === 'high') bg-red-100 text-red-800
                            @elseif($alert['severity'] === 'medium') bg-yellow-100 text-yellow-800
                            @else bg-blue-100 text-blue-800
                            @endif">
                            {{ ucfirst($alert['severity']) }}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <script>
        function securityData() {
            return {
                async blockIp(ip) {
                    if (!confirm(`Are you sure you want to block IP address ${ip}?`)) {
                        return;
                    }
                    
                    try {
                        const response = await fetch(`/superuser/security/block-ip/${ip}`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                                'Content-Type': 'application/json',
                            }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            alert(`IP address ${ip} has been blocked successfully!`);
                            location.reload();
                        } else {
                            alert('Failed to block IP: ' + data.message);
                        }
                    } catch (error) {
                        alert('Error blocking IP: ' + error.message);
                    }
                },
                
                investigateIp(ip) {
                    alert(`Opening investigation for IP: ${ip}`);
                    // In real implementation, this would open a detailed investigation panel
                },
                
                runSecurityScan() {
                    alert('Security scan initiated. This may take a few minutes.');
                    // In real implementation, this would trigger a security scan
                },
                
                updateFirewall() {
                    alert('Firewall rules updated successfully.');
                    // In real implementation, this would update firewall rules
                },
                
                checkSslCertificates() {
                    alert('SSL certificate check completed.');
                    // In real implementation, this would check SSL certificates
                },
                
                generateSecurityReport() {
                    alert('Security report generation started. You will receive it via email.');
                    // In real implementation, this would generate and send a security report
                }
            }
        }
    </script>
</body>
</html> 