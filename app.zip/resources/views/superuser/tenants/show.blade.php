<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $tenant->name }} - Детали Арендатора - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="tenantDetails()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.tenants.index') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Арендаторам
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Детали Арендатора</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.tenants.edit', $tenant) }}" 
                       class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-edit mr-2"></i>Edit Tenant
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Tenant Header -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <div class="h-16 w-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                        <span class="text-2xl font-bold text-white">{{ strtoupper(substr($tenant->name, 0, 2)) }}</span>
                    </div>
                    <div>
                        <h2 class="text-3xl font-bold text-gray-900">{{ $tenant->name }}</h2>
                        <p class="text-gray-600">{{ $tenant->domain ?? 'No domain configured' }}</p>
                        <div class="flex items-center mt-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                @if($tenant->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                <span class="w-2 h-2 rounded-full mr-1.5 @if($tenant->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                                {{ $tenant->is_active ? 'Active' : 'Inactive' }}
                            </span>
                            <span class="ml-4 text-sm text-gray-500">
                                <i class="fas fa-calendar mr-1"></i>Created {{ $tenant->created_at->format('M d, Y') }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="flex space-x-3">
                    <button @click="toggleTenantStatus({{ $tenant->id }}, {{ $tenant->is_active ? 'false' : 'true' }})" 
                            class="px-4 py-2 rounded-lg transition-colors
                            @if($tenant->is_active) bg-yellow-100 text-yellow-800 hover:bg-yellow-200 @else bg-green-100 text-green-800 hover:bg-green-200 @endif">
                        <i class="fas fa-{{ $tenant->is_active ? 'pause' : 'play' }} mr-2"></i>
                        {{ $tenant->is_active ? 'Deactivate' : 'Activate' }}
                    </button>
                    <button @click="showDeleteModal = true" 
                            class="px-4 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors">
                        <i class="fas fa-trash mr-2"></i>Delete
                    </button>
                </div>
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Users</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenant->users_count ?? 0 }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $tenant->users->where('is_active', true)->count() }} Active
                        </p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Orders</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenant->orders_count ?? 0 }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $tenant->orders->where('created_at', '>=', \Carbon\Carbon::now()->subDays(30))->count() }} This Month
                        </p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Revenue</p>
                        <p class="text-3xl font-bold text-gray-900">{{ number_format($tenant->total_revenue ?? 0, 0) }} Сум</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ number_format($tenant->monthly_revenue ?? 0, 0) }} Сум This Month
                        </p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Products</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenant->products_count ?? 0 }}</p>
                        <p class="text-sm text-green-600 mt-1">
                            <i class="fas fa-arrow-up mr-1"></i>{{ $tenant->products->where('is_active', true)->count() }} Active
                        </p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-box"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column -->
            <div class="lg:col-span-2 space-y-8">
                <!-- Tenant Information -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Tenant Information</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Basic Details</h4>
                                <dl class="space-y-3">
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Domain</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-globe mr-2 text-gray-400"></i>
                                            {{ $tenant->domain ?? 'Not configured' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Subdomain</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-link mr-2 text-gray-400"></i>
                                            {{ $tenant->subdomain ?? 'Not configured' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Email</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-envelope mr-2 text-gray-400"></i>
                                            {{ $tenant->email ?? 'Not provided' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Phone</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-phone mr-2 text-gray-400"></i>
                                            {{ $tenant->phone ?? 'Not provided' }}
                                        </dd>
                                    </div>
                                </dl>
                            </div>
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Company Details</h4>
                                <dl class="space-y-3">
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Company Name</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-building mr-2 text-gray-400"></i>
                                            {{ $tenant->company_name ?? 'Not provided' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Address</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-map-marker-alt mr-2 text-gray-400"></i>
                                            {{ $tenant->address ?? 'Not provided' }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Created</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-calendar mr-2 text-gray-400"></i>
                                            {{ $tenant->created_at->format('M d, Y H:i') }}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500">Last Updated</dt>
                                        <dd class="text-sm text-gray-900 flex items-center">
                                            <i class="fas fa-clock mr-2 text-gray-400"></i>
                                            {{ $tenant->updated_at->format('M d, Y H:i') }}
                                        </dd>
                                    </div>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Recent Activity</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-4">
                            @forelse($tenant->orders->take(5) as $order)
                            <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                                <div class="flex-shrink-0">
                                    <div class="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                                        <i class="fas fa-shopping-cart text-green-600 text-sm"></i>
                                    </div>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900">New Order #{{ $order->id }}</p>
                                    <p class="text-sm text-gray-500">{{ $order->created_at->diffForHumans() }}</p>
                                </div>
                                <div class="text-sm text-gray-500">
                                    ${{ number_format($order->total_amount ?? 0, 2) }}
                                </div>
                            </div>
                            @empty
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-4"></i>
                                <p>No recent activity</p>
                            </div>
                            @endforelse
                        </div>
                    </div>
                </div>

                <!-- Performance Chart -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Performance Overview</h3>
                    </div>
                    <div class="p-6">
                        <canvas id="performanceChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="space-y-8">
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-3">
                            <a href="{{ route('superuser.users.create') }}?tenant_id={{ $tenant->id }}" 
                               class="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                                <i class="fas fa-user-plus text-blue-600 mr-3"></i>
                                <span class="text-sm font-medium text-blue-900">Add User</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                                <i class="fas fa-chart-line text-green-600 mr-3"></i>
                                <span class="text-sm font-medium text-green-900">View Reports</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                                <i class="fas fa-cog text-purple-600 mr-3"></i>
                                <span class="text-sm font-medium text-purple-900">Settings</span>
                            </a>
                            <a href="#" class="flex items-center p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors">
                                <i class="fas fa-download text-orange-600 mr-3"></i>
                                <span class="text-sm font-medium text-orange-900">Export Data</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Recent Users -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">Recent Users</h3>
                    </div>
                    <div class="p-6">
                        @if($tenant->users->count() > 0)
                        <div class="space-y-4">
                            @foreach($tenant->users->take(5) as $user)
                            <div class="flex items-center space-x-3">
                                <div class="flex-shrink-0">
                                    <div class="h-8 w-8 rounded-full bg-gradient-to-r from-green-500 to-blue-600 flex items-center justify-center">
                                        <span class="text-xs font-medium text-white">{{ strtoupper(substr($user->name, 0, 2)) }}</span>
                                    </div>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900">{{ $user->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $user->email }}</p>
                                </div>
                                <div class="flex-shrink-0">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                        @if($user->role === 'admin') bg-purple-100 text-purple-800
                                        @elseif($user->role === 'manager') bg-blue-100 text-blue-800
                                        @else bg-gray-100 text-gray-800
                                        @endif">
                                        {{ ucfirst($user->role) }}
                                    </span>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        @else
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-users text-4xl mb-4"></i>
                            <p>No users found</p>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- System Status -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800">System Status</h3>
                    </div>
                    <div class="p-6">
                        <div class="space-y-4">
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Database</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <span class="w-2 h-2 rounded-full bg-green-400 mr-1"></span>Online
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Storage</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <span class="w-2 h-2 rounded-full bg-green-400 mr-1"></span>Normal
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">API</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <span class="w-2 h-2 rounded-full bg-green-400 mr-1"></span>Active
                                </span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600">Backup</span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <span class="w-2 h-2 rounded-full bg-yellow-400 mr-1"></span>Pending
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-exclamation-triangle text-red-500 text-2xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Delete Tenant</h3>
                </div>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete <strong>{{ $tenant->name }}</strong>? This action cannot be undone and will permanently remove all tenant data including users, orders, and products.
                </p>
                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false" 
                            class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                        Cancel
                    </button>
                    <form method="POST" action="{{ route('superuser.tenants.destroy', $tenant) }}" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" 
                                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            Delete Tenant
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function tenantDetails() {
            return {
                showDeleteModal: false,
                
                toggleTenantStatus(tenantId, newStatus) {
                    if (confirm(`Are you sure you want to ${newStatus ? 'activate' : 'deactivate'} this tenant?`)) {
                        // In real implementation, this would make an AJAX call
                        window.location.href = `/superuser/tenants/${tenantId}/toggle-status`;
                    }
                }
            }
        }

        // Performance Chart
        const ctx = document.getElementById('performanceChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Orders',
                    data: [12, 19, 3, 5, 2, 3],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Revenue',
                    data: [1200, 1900, 300, 500, 200, 300],
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html> 