<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление Арендаторами - Панель Суперпользователя</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="tenantData()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.dashboard') }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Назад к Панели
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Управление Арендаторами</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.tenants.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Добавить Арендатора
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Выйти
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Success Message -->
        @if(session('success'))
            <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                {{ session('success') }}
            </div>
        @endif

        <!-- Analytics Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Арендаторов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenants->total() }}</p>
                    </div>
                    <div class="text-blue-500 text-3xl">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Активных Арендаторов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenants->where('is_active', true)->count() }}</p>
                    </div>
                    <div class="text-green-500 text-3xl">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Пользователей</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenants->sum('users_count') }}</p>
                    </div>
                    <div class="text-purple-500 text-3xl">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Всего Заказов</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $tenants->sum('orders_count') }}</p>
                    </div>
                    <div class="text-orange-500 text-3xl">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <div class="relative">
                        <input type="text" x-model="searchTerm" @input="filterTenants()" 
                               placeholder="Поиск арендаторов по имени, домену или email..." 
                               class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                    </div>
                </div>
                <div class="flex gap-2">
                    <select x-model="statusFilter" @change="filterTenants()" 
                            class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Все Статусы</option>
                        <option value="active">Активные</option>
                        <option value="inactive">Неактивные</option>
                    </select>
                    <select x-model="sortBy" @change="filterTenants()" 
                            class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="name">Сортировать по Имени</option>
                        <option value="created_at">Сортировать по Дате</option>
                        <option value="users_count">Сортировать по Пользователям</option>
                        <option value="orders_count">Сортировать по Заказам</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Tenants List -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Все Арендаторы</h3>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Арендатор</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Домен</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Статус</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Пользователи</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Заказы</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Создан</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Действия</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200" id="tenantsTable">
                        @forelse($tenants as $tenant)
                        <tr class="tenant-row hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <div class="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                                            <span class="text-sm font-medium text-white">{{ strtoupper(substr($tenant->name, 0, 2)) }}</span>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900 tenant-name">{{ $tenant->name }}</div>
                                        <div class="text-sm text-gray-500">{{ $tenant->email ?? 'Нет email' }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">{{ $tenant->domain ?? 'Нет домена' }}</div>
                                <div class="text-sm text-gray-500">{{ $tenant->subdomain ?? 'Нет поддомена' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    @if($tenant->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                                    <span class="w-2 h-2 rounded-full mr-1.5 @if($tenant->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                                    {{ $tenant->is_active ? 'Активный' : 'Неактивный' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <div class="flex items-center">
                                    <i class="fas fa-users text-gray-400 mr-2"></i>
                                    {{ $tenant->users_count ?? 0 }}
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <div class="flex items-center">
                                    <i class="fas fa-shopping-cart text-gray-400 mr-2"></i>
                                    {{ $tenant->orders_count ?? 0 }}
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $tenant->created_at->format('M d, Y') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="{{ route('superuser.tenants.show', $tenant) }}" 
                                       class="text-blue-600 hover:text-blue-900 transition-colors" 
                                       title="Просмотр Деталей">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('superuser.tenants.edit', $tenant) }}" 
                                       class="text-green-600 hover:text-green-900 transition-colors" 
                                       title="Редактировать Арендатора">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button @click="toggleTenantStatus({{ $tenant->id }}, {{ $tenant->is_active ? 'false' : 'true' }})" 
                                            class="text-yellow-600 hover:text-yellow-900 transition-colors" 
                                            title="{{ $tenant->is_active ? 'Деактивировать' : 'Активировать' }}">
                                        <i class="fas fa-{{ $tenant->is_active ? 'pause' : 'play' }}"></i>
                                    </button>
                                    <button @click="deleteTenant({{ $tenant->id }})" 
                                            class="text-red-600 hover:text-red-900 transition-colors" 
                                            title="Удалить Арендатора">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <div class="text-gray-500">
                                    <i class="fas fa-building text-4xl mb-4"></i>
                                    <p class="text-lg font-medium">Арендаторы не найдены</p>
                                    <p class="text-sm">Начните с создания первого арендатора</p>
                                    <a href="{{ route('superuser.tenants.create') }}" 
                                       class="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                        <i class="fas fa-plus mr-2"></i>Создать Первого Арендатора
                                    </a>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        @if($tenants->hasPages())
            <div class="mt-6">
                {{ $tenants->links() }}
            </div>
        @endif
    </div>

    <!-- Delete Confirmation Modal -->
    <div x-show="showDeleteModal" x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-exclamation-triangle text-red-500 text-2xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Удалить Арендатора</h3>
                </div>
                <p class="text-gray-600 mb-6">
                    Вы уверены, что хотите удалить этого арендатора? Это действие нельзя отменить и оно навсегда удалит все данные арендатора, включая пользователей, заказы и продукты.
                </p>
                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false" 
                            class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                        Отмена
                    </button>
                    <button @click="confirmDelete()" 
                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        Удалить Арендатора
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function tenantData() {
            return {
                searchTerm: '',
                statusFilter: '',
                sortBy: 'name',
                showDeleteModal: false,
                tenantToDelete: null,
                
                filterTenants() {
                    const rows = document.querySelectorAll('.tenant-row');
                    rows.forEach(row => {
                        const name = row.querySelector('.tenant-name').textContent.toLowerCase();
                        const status = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                        
                        const matchesSearch = name.includes(this.searchTerm.toLowerCase());
                        const matchesStatus = !this.statusFilter || status.includes(this.statusFilter);
                        
                        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
                    });
                },
                
                toggleTenantStatus(tenantId, newStatus) {
                    if (confirm(`Are you sure you want to ${newStatus ? 'activate' : 'deactivate'} this tenant?`)) {
                        // In real implementation, this would make an AJAX call
                        window.location.href = `/superuser/tenants/${tenantId}/toggle-status`;
                    }
                },
                
                deleteTenant(tenantId) {
                    this.tenantToDelete = tenantId;
                    this.showDeleteModal = true;
                },
                
                confirmDelete() {
                    if (this.tenantToDelete) {
                        const form = document.createElement('form');
                        form.method = 'POST';
                        form.action = `/superuser/tenants/${this.tenantToDelete}`;
                        
                        const csrfToken = document.createElement('input');
                        csrfToken.type = 'hidden';
                        csrfToken.name = '_token';
                        csrfToken.value = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                        
                        const methodField = document.createElement('input');
                        methodField.type = 'hidden';
                        methodField.name = '_method';
                        methodField.value = 'DELETE';
                        
                        form.appendChild(csrfToken);
                        form.appendChild(methodField);
                        document.body.appendChild(form);
                        form.submit();
                    }
                }
            }
        }
    </script>
</body>
</html> 