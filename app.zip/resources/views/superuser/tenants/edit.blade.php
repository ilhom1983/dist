<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit {{ $tenant->name }} - Superuser Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50" x-data="tenantEditForm()">
    <!-- Navigation Header -->
    <nav class="bg-white shadow-lg border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <a href="{{ route('superuser.tenants.show', $tenant) }}" class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Tenant
                    </a>
                    <h1 class="text-2xl font-bold text-gray-900">Edit {{ $tenant->name }}</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Tenant Info Header -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex items-center space-x-4">
                <div class="h-12 w-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                    <span class="text-lg font-bold text-white">{{ strtoupper(substr($tenant->name, 0, 2)) }}</span>
                </div>
                <div>
                    <h2 class="text-xl font-semibold text-gray-900">{{ $tenant->name }}</h2>
                    <p class="text-gray-600">{{ $tenant->domain ?? 'No domain configured' }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                            @if($tenant->is_active) bg-green-100 text-green-800 @else bg-red-100 text-red-800 @endif">
                            <span class="w-2 h-2 rounded-full mr-1.5 @if($tenant->is_active) bg-green-400 @else bg-red-400 @endif"></span>
                            {{ $tenant->is_active ? 'Active' : 'Inactive' }}
                        </span>
                        <span class="ml-4 text-sm text-gray-500">
                            <i class="fas fa-calendar mr-1"></i>Created {{ $tenant->created_at->format('M d, Y') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Edit Tenant Information</h3>
                <p class="text-sm text-gray-600 mt-1">Update the tenant's basic information and settings</p>
            </div>

            <form method="POST" action="{{ route('superuser.tenants.update', $tenant) }}" class="p-6 space-y-6">
                @csrf
                @method('PUT')
                
                <!-- Basic Information -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-building mr-2"></i>Tenant Name *
                        </label>
                        <input type="text" name="name" id="name" value="{{ old('name', $tenant->name) }}" required
                               x-model="form.name" @input="validateField('name')"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="Enter tenant name">
                        <div x-show="errors.name" x-text="errors.name" class="mt-1 text-sm text-red-600"></div>
                        @error('name')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="company_name" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-briefcase mr-2"></i>Company Name
                        </label>
                        <input type="text" name="company_name" id="company_name" value="{{ old('company_name', $tenant->company_name ?? '') }}"
                               x-model="form.company_name"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="Enter company name">
                        @error('company_name')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Domain Information -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="domain" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-globe mr-2"></i>Domain *
                        </label>
                        <div class="relative">
                            <input type="text" name="domain" id="domain" value="{{ old('domain', $tenant->domain) }}" required
                                   x-model="form.domain" @input="validateDomain()"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                                   placeholder="example.com">
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <span class="text-gray-400 text-sm">.com</span>
                            </div>
                        </div>
                        <div x-show="errors.domain" x-text="errors.domain" class="mt-1 text-sm text-red-600"></div>
                        @error('domain')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="subdomain" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-link mr-2"></i>Subdomain
                        </label>
                        <div class="relative">
                            <input type="text" name="subdomain" id="subdomain" value="{{ old('subdomain', $tenant->subdomain ?? '') }}"
                                   x-model="form.subdomain"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                                   placeholder="shop">
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <span class="text-gray-400 text-sm">.yourdomain.com</span>
                            </div>
                        </div>
                        @error('subdomain')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-envelope mr-2"></i>Email Address *
                        </label>
                        <input type="email" name="email" id="email" value="{{ old('email', $tenant->email ?? '') }}" required
                               x-model="form.email" @input="validateField('email')"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="admin@example.com">
                        <div x-show="errors.email" x-text="errors.email" class="mt-1 text-sm text-red-600"></div>
                        @error('email')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-phone mr-2"></i>Phone Number
                        </label>
                        <input type="tel" name="phone" id="phone" value="{{ old('phone', $tenant->phone ?? '') }}"
                               x-model="form.phone"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                               placeholder="+1 (555) 123-4567">
                        @error('phone')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Address -->
                <div>
                    <label for="address" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-map-marker-alt mr-2"></i>Address
                    </label>
                    <textarea name="address" id="address" rows="3"
                              x-model="form.address"
                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                              placeholder="Enter full address">{{ old('address', $tenant->address ?? '') }}</textarea>
                    @error('address')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Settings -->
                <div class="border-t border-gray-200 pt-6">
                    <h4 class="text-md font-medium text-gray-800 mb-4">Tenant Settings</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="flex items-center">
                            <input type="checkbox" name="is_active" id="is_active" value="1" 
                                   {{ old('is_active', $tenant->is_active) ? 'checked' : '' }}
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label for="is_active" class="ml-2 block text-sm text-gray-700">
                                <i class="fas fa-check-circle mr-2"></i>Active Tenant
                            </label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" name="send_notification" id="send_notification" value="1" 
                                   {{ old('send_notification', true) ? 'checked' : '' }}
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label for="send_notification" class="ml-2 block text-sm text-gray-700">
                                <i class="fas fa-bell mr-2"></i>Send Update Notification
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Advanced Settings -->
                <div class="border-t border-gray-200 pt-6">
                    <h4 class="text-md font-medium text-gray-800 mb-4">Advanced Settings</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="timezone" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-clock mr-2"></i>Timezone
                            </label>
                            <select name="timezone" id="timezone" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors">
                                <option value="UTC" {{ ($tenant->timezone ?? 'UTC') === 'UTC' ? 'selected' : '' }}>UTC</option>
                                <option value="Asia/Tashkent" {{ ($tenant->timezone ?? 'Asia/Tashkent') === 'Asia/Tashkent' ? 'selected' : '' }}>Ташкент (UZT)</option>
                                <option value="Asia/Almaty" {{ ($tenant->timezone ?? '') === 'Asia/Almaty' ? 'selected' : '' }}>Алматы (ALMT)</option>
                                <option value="Asia/Bishkek" {{ ($tenant->timezone ?? '') === 'Asia/Bishkek' ? 'selected' : '' }}>Бишкек (KGT)</option>
                                <option value="Europe/Moscow" {{ ($tenant->timezone ?? '') === 'Europe/Moscow' ? 'selected' : '' }}>Москва (MSK)</option>
                                <option value="America/New_York" {{ ($tenant->timezone ?? '') === 'America/New_York' ? 'selected' : '' }}>Eastern Time</option>
                                <option value="Europe/London" {{ ($tenant->timezone ?? '') === 'Europe/London' ? 'selected' : '' }}>London</option>
                                <option value="Asia/Tokyo" {{ ($tenant->timezone ?? '') === 'Asia/Tokyo' ? 'selected' : '' }}>Tokyo</option>
                            </select>
                        </div>
                        <div>
                            <label for="currency" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-dollar-sign mr-2"></i>Currency
                            </label>
                            <select name="currency" id="currency" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors">
                                <option value="UZS" {{ ($tenant->currency ?? 'UZS') === 'UZS' ? 'selected' : '' }}>UZS (Сум)</option>
                                <option value="USD" {{ ($tenant->currency ?? '') === 'USD' ? 'selected' : '' }}>USD ($)</option>
                                <option value="EUR" {{ ($tenant->currency ?? '') === 'EUR' ? 'selected' : '' }}>EUR (€)</option>
                                <option value="RUB" {{ ($tenant->currency ?? '') === 'RUB' ? 'selected' : '' }}>RUB (₽)</option>
                                <option value="KZT" {{ ($tenant->currency ?? '') === 'KZT' ? 'selected' : '' }}>KZT (₸)</option>
                                <option value="KGS" {{ ($tenant->currency ?? '') === 'KGS' ? 'selected' : '' }}>KGS (с)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                    <div class="text-sm text-gray-600">
                        <i class="fas fa-info-circle mr-2"></i>
                        Fields marked with * are required
                    </div>
                    <div class="flex space-x-3">
                        <a href="{{ route('superuser.tenants.show', $tenant) }}" 
                           class="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" 
                                :disabled="!isFormValid()"
                                class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
                            <i class="fas fa-save mr-2"></i>Update Tenant
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Help Card -->
        <div class="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-lightbulb text-blue-400"></i>
                </div>
                <div class="ml-3">
                    <h3 class="text-sm font-medium text-blue-800">Editing Tenant Information</h3>
                    <div class="mt-2 text-sm text-blue-700">
                        <ul class="list-disc list-inside space-y-1">
                            <li>Changes will be applied immediately</li>
                            <li>Domain changes may require DNS updates</li>
                            <li>Timezone affects all date/time displays (default: Asia/Tashkent)</li>
                            <li>Currency changes affect pricing displays (default: UZS Сум)</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function tenantEditForm() {
            return {
                form: {
                    name: '{{ old("name", $tenant->name) }}',
                    company_name: '{{ old("company_name", $tenant->company_name ?? "") }}',
                    domain: '{{ old("domain", $tenant->domain) }}',
                    subdomain: '{{ old("subdomain", $tenant->subdomain ?? "") }}',
                    email: '{{ old("email", $tenant->email ?? "") }}',
                    phone: '{{ old("phone", $tenant->phone ?? "") }}',
                    address: '{{ old("address", $tenant->address ?? "") }}'
                },
                errors: {
                    name: '',
                    domain: '',
                    email: ''
                },
                
                validateField(field) {
                    this.errors[field] = '';
                    
                    if (field === 'name') {
                        if (!this.form.name) {
                            this.errors.name = 'Tenant name is required';
                        } else if (this.form.name.length < 2) {
                            this.errors.name = 'Tenant name must be at least 2 characters';
                        }
                    }
                    
                    if (field === 'email') {
                        if (!this.form.email) {
                            this.errors.email = 'Email is required';
                        } else if (!this.isValidEmail(this.form.email)) {
                            this.errors.email = 'Please enter a valid email address';
                        }
                    }
                },
                
                validateDomain() {
                    this.errors.domain = '';
                    
                    if (!this.form.domain) {
                        this.errors.domain = 'Domain is required';
                    } else if (!this.isValidDomain(this.form.domain)) {
                        this.errors.domain = 'Please enter a valid domain name';
                    }
                },
                
                isValidEmail(email) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    return emailRegex.test(email);
                },
                
                isValidDomain(domain) {
                    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
                    return domainRegex.test(domain);
                },
                
                isFormValid() {
                    return this.form.name && this.form.domain && this.form.email && 
                           !this.errors.name && !this.errors.domain && !this.errors.email;
                }
            }
        }
    </script>
</body>
</html> 