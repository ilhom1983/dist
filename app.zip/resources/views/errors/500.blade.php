@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50 flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-md p-8 text-center">
        <div class="mb-6">
            <svg class="mx-auto h-16 w-16 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </div>
        
        <h1 class="text-2xl font-bold text-gray-900 mb-4">500</h1>
        <h2 class="text-lg font-semibold text-gray-700 mb-2">Внутренняя ошибка сервера</h2>
        <p class="text-gray-600 mb-6">
            Произошла непредвиденная ошибка. Пожалуйста, попробуйте позже или обратитесь к администратору.
        </p>
        
        <div class="space-y-3">
            <a href="{{ route('mobile.sales.dashboard') }}" 
               class="block w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700">
                Вернуться на главную
            </a>
            <button onclick="location.reload()" 
                    class="block w-full bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-300">
                Обновить страницу
            </button>
        </div>
    </div>
</div>
@endsection 