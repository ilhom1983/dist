@extends('layouts.mobile')

@section('content')
<div class="min-h-screen bg-gray-50 flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-md p-8 text-center">
        <div class="mb-6">
            <svg class="mx-auto h-16 w-16 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47-.881-6.08-2.33"></path>
            </svg>
        </div>
        
        <h1 class="text-2xl font-bold text-gray-900 mb-4">404</h1>
        <h2 class="text-lg font-semibold text-gray-700 mb-2">Страница не найдена</h2>
        <p class="text-gray-600 mb-6">
            Запрашиваемая страница не существует или была перемещена.
        </p>
        
        <div class="space-y-3">
            <a href="{{ route('mobile.sales.dashboard') }}" 
               class="block w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700">
                Вернуться на главную
            </a>
            <a href="{{ url()->previous() }}" 
               class="block w-full bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-300">
                Назад
            </a>
        </div>
    </div>
</div>
@endsection 